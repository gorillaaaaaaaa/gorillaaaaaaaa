/*! ----------------------------------------------------------------------------
 *  @file    instance.c
 *  @brief   DecaWave application level message exchange for ranging demo
 *
 * @attention
 *
 * Copyright 2013 (c) DecaWave Ltd, Dublin, Ireland.
 *
 * All rights reserved.
 *
 * @author DecaWave
 */
#include "compiler.h"
#include "port.h"
#include "deca_device_api.h"
#include "deca_spi.h"
#include "deca_regs.h"

#include "lib.h"
#include "LPS22HB.h"
#include "instance.h"
// -------------------------------------------------------------------------------------------------------------------
extern double inst_idist;
uint8 nxn_flag = 0;
uint8 bs_flag = 0;
uint8 data_buf[1024];
uint16 shortadd = 0;
uint32 test_data = 0;
uint16 anc_cnt = 0;
uint16 anc_list_len = 0;
uint16 repot_cnt = 0;
uint32 anc_distance[3];
uint8 anc_mode = 0;
extern uint8 search_flag;
uint8 baro_data_ss[10];
uint8 ran_ack_flag = 0;
uint8 route_ack_flag = 0;
uint8 dest_flag = 0;
uint8 second_flag = 0;
uint32 tof_distance = 0;

int RSS1 = 0, RSS2 = 0;
uint16 rss;
extern lps22hb_ctx_t dev_ctx; //at LPS22HB.h?
extern axis1bit32_t data_raw_pressure; //at LPS22HB.h?

uint64 owr_poll_tx_time = 0;
uint64 owr_response_tx_time = 0;
uint64 owr_poll_rx_time = 0;
uint64 owr_response_rx_time = 0;


uint64 poll_tx_time = 0;
uint64 response_tx_time = 0;
uint64 final_tx_time = 0;
uint64 final_rx_time = 0;

uint8 anc_std_distance = 0;
uint64 start_tx_time = 0;
uint64 start_rx_time = 0;
uint64 start_ack_tx_time = 0;
uint64 start_ack_rx_time = 0;

extern volatile unsigned int Timer2_Counter;
extern volatile unsigned int Timer4_Counter;
uint8 timer_flag = 0;
uint8 ran_tag_flag = 0;
// -------------------------------------------------------------------------------------------------------------------
//      Data Definitions
// -------------------------------------------------------------------------------------------------------------------

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// NOTE: the maximum RX timeout is ~ 65ms
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
extern uint16 anchoraddress;
extern uint16 tagaddress;

extern uint8_t UserRxBufferFS[1000];

uint16 shortaddress = 0;
// -------------------------------------------------------------------------------------------------------------------
// Functions
// -------------------------------------------------------------------------------------------------------------------
uint32_t  pollcnt=0;
// -------------------------------------------------------------------------------------------------------------------
//
// function to construct the message/frame header bytes
//
// -------------------------------------------------------------------------------------------------------------------
//
void rfid_read(void)
{
	uint8 ble_data[10];

	ble_data[0] = 0x31;
	//uart2init();
	rfid_start = 1;
	//USART_SendData(USART2,ble_data[0]);

	Timer4_Counter = 0;
	rfid_timeout = 1;
}

void instancerxon(instance_data_t *inst, int delayed, uint64 delayedReceiveTime)
{
    if (delayed)
    {
        uint32 dtime;
        dtime =  (uint32) (delayedReceiveTime>>8);
        dwt_setdelayedtrxtime(dtime) ;
    }

    inst->lateRX -= dwt_rxenable(delayed) ;  //- as when fails -1 is returned             // turn receiver on, immediate/delayed

} // end instancerxon()

void instanceconfigframeheader16(instance_data_t *inst)
{
    //set frame type (0-2), SEC (3), Pending (4), ACK (5), PanIDcomp(6)
    inst->msg.frameCtrl[0] = 0x1 /*frame type 0x1 == data*/ | 0x40 /*PID comp*/;

	//source/dest addressing modes and frame version
	inst->msg.frameCtrl[1] = 0x8 /*dest extended address (16bits)*/ | 0x80 /*src extended address (16bits)*/;

	inst->msg.panID[0] = (inst->panID) & 0xff;
	inst->msg.panID[1] = inst->panID >> 8;
    inst->msg.seqNum = inst->frameSN++;
}


// -------------------------------------------------------------------------------------------------------------------
//
// Turn on the receiver with/without delay
//


int instancesendpacket(instance_data_t *inst, int delayedTx)
{
    int result = 0;

    dwt_writetxfctrl(inst->psduLength, 0, 1);
    if(delayedTx)
    {
        uint32 dtime;
        dtime = (uint32) (inst->delayedReplyTime>>8);
        dwt_setdelayedtrxtime(dtime) ;
    }

    //begin delayed TX of frame
    if (dwt_starttx(delayedTx | inst->wait4ack))  // delayed start was too late
    {
        result = 1; //late/error
        inst->lateTX++;
    }


    return result;                                              // state changes
    // after sending we should return to TX ON STATE ?
}
//int instancesendpacket(uint16 length, uint8 txmode, uint32 dtime)
//{
//    int result = 0;
//
//    dwt_writetxfctrl(length, 0, 1);
//    if(txmode & DWT_START_TX_DELAYED)
//    {
//        dwt_setdelayedtrxtime(dtime) ;
//    }
//
//    //begin delayed TX of frame
//    if (dwt_starttx(txmode))  // delayed start was too late
//    {
//        result = 1; //late/error
//    }
//
//    return result;                                              // state changes
//
//}
void ranging_dest(instance_data_t *inst)
{
	if(nxn_flag == 1)
	{
		inst->msg.destAddr[0] = anc.anc_add[(anc_cnt*2)];
		inst->msg.destAddr[1] = anc.anc_add[(anc_cnt*2)+1];

		if(anc_cnt >=3)
		{
			anc.list_len = 7;
			if(anc_mode == ANC_HIGH)
			{
				if(anc_cnt >=5)
				{
					inst->msg.destAddr[0] = anc.anc_add[((anc_cnt+1)*2)];
					inst->msg.destAddr[1] = anc.anc_add[((anc_cnt+1)*2)+1];
				}
				else
				{
				inst->msg.destAddr[0] = anc.anc_add[(anc_cnt*2)];
				inst->msg.destAddr[1] = anc.anc_add[(anc_cnt*2)+1];
				}
			}
			else if(anc_mode == ANC_LOW)
			{
				if(anc_cnt >= 4 && anc_cnt < 6)
				{
					inst->msg.destAddr[0] = anc.anc_add[((anc_cnt+1)*2)];
					inst->msg.destAddr[1] = anc.anc_add[((anc_cnt+1)*2)+1];
				}
				else if(anc_cnt >= 6)
				{
					inst->msg.destAddr[0] = anc.anc_add[((anc_cnt+2)*2)];
					inst->msg.destAddr[1] = anc.anc_add[((anc_cnt+2)*2)+1];
				}
				else
				{
					inst->msg.destAddr[0] = anc.anc_add[(anc_cnt*2)];
					inst->msg.destAddr[1] = anc.anc_add[(anc_cnt*2)+1];
				}
			}
		}
	}
	else
	{
		inst->msg.destAddr[0] = anc.anc_add[(anc_cnt*2)];
		inst->msg.destAddr[1] = anc.anc_add[(anc_cnt*2)+1];
	}
}
// -------------------------------------------------------------------------------------------------------------------
//
// function to configure the frame data, prior to writing the frame to the TX buffer
//
// -------------------------------------------------------------------------------------------------------------------
//
void setupmacframedata(instance_data_t *inst, int len, int framectrllen, int fcode)
{
	inst->msg.messageData[FCODE] = fcode; //message function code (specifies if message is a poll, response or other...)
    inst->psduLength = len + framectrllen;

	instanceconfigframeheader16(inst);
}
// -------------------------------------------------------------------------------------------------------------------
//
// the main instance state machine (all the instance modes Tag, Anchor or Listener use the same statemachine....)
//
// -------------------------------------------------------------------------------------------------------------------
//
int testapprun(instance_data_t *inst, int message)
{
	int n = 0;
    //int done = INST_NOT_DONE_YET;
//#ifdef USB_SUPPORT //this is set in the port.h file
//    if(UserRxBufferFS[0]==0x20)
//	   {
//		dwt_forcetrxoff();
//		dwt_rxreset();
//
//		data_buf[0] = 0x30;
//
//		UserRxBufferFS[0] = 0;
//	   }
//#endif
#ifdef USB_SUPPORT		//marker
switch (UserRxBufferFS[0])
{
	case 0x31:
	{
		dwt_forcetrxoff();
		dwt_rxreset();
		data_buf[0] = 0x31;
		UserRxBufferFS[0] = 0;
	}
	break;
	case 0x32:
	{
		dwt_forcetrxoff();
		dwt_rxreset();
		data_buf[0] = 0x32;
		UserRxBufferFS[0] = 0;
	}
	break;
	case 0x33:
	{
		dwt_forcetrxoff();
		dwt_rxreset();
		data_buf[0] = 0x33;
		UserRxBufferFS[0] = 0;
	}
	break;
	case 0x34:
	{
		dwt_forcetrxoff();
		dwt_rxreset();
		data_buf[0] = 0x34;
		UserRxBufferFS[0] = 0;
	}
	break;
}
#endif
#ifdef USB_SUPPORT
    switch (data_buf[0]){

    	case 0x31:  //route down
		{
			rfid_read();
		}
        break;

    	case 0x32 :
//		else if(data_buf[0] == 0x30)  //tag_address
		{
			send_usbmessage(rfid_data,11);
			usb_run();
			ch4_cnt = 0;
			memset(rfid_data,0,100);
			rfid_state = 0;
		}
		break;

    	case 0x33 :
		//else if(data_buf[0] == 0x10)  //tag_address
		{
			uint16 route_len, tag_len = 0;

			dwt_forcetrxoff();
			dwt_rxreset();

			inst->testAppState = TA_TXE_WAIT;
			inst->nextState = TA_TX_ORAN;

		}
		break;

    	case 0x34 :
		//else if(data_buf[0] == 0x31)  //tag_address
		{
			uint16 route_len, tag_len = 0;
			uint8 ahrs_send[1];
			ahrs_send[0] = 0x2a;

			send_usbmessage(&ahrs[0], 10);
			usb_run();
			memset(ahrs,0,10);
			//USART_SendData(USART3,ahrs_send[0]);

			dwt_forcetrxoff();
			dwt_rxreset();

			inst->testAppState = TA_RXE_WAIT;
		}
		break;
    }
#endif

	if(sensor_flag == 1)
		{
			dwt_forcetrxoff();
			dwt_rxreset();

			if(sensor_mode == 1)
			{
		    	lps22hb_pressure_raw_get(&dev_ctx, data_raw_pressure.u8bit);
		    	pha = (uint32)(LPS22HB_FROM_LSB_TO_hPa(data_raw_pressure.i32bit)*1000);

				if(Timer2_Counter >= 1000)
				{
					Timer2_Counter = 0;
					rfid_state = 0;
					sensor_flag = 0;
					rfid_read();

					inst->testAppState = TA_RXE_WAIT;
				}
				else
				{
					if(rfid_start == 0)
					{
						delay_ms(10);

						inst->testAppState = TA_TXE_WAIT;
						inst->nextState = TA_TX_SENSOR;
						sensor_flag = 0;
					}
					else{
						if(rfid_fn == 1)
						{
							delay_ms(8);
							inst->testAppState = TA_TXE_WAIT;
							inst->nextState = TA_TX_SENSOR;
							sensor_flag = 0;
							rfid_start = 0;
							rfid_fn = 0;
						}
						else {
							inst->testAppState = TA_RXE_WAIT;
						}
					}
				}
			}
			else
			{
				delay_ms(10);

				inst->testAppState = TA_TXE_WAIT;
				inst->nextState = TA_TX_SENSOR;
				sensor_flag = 0;
			}

		}


    switch (inst->testAppState)
    {
        case TA_INIT :
            // printf("TA_INIT") ;
            switch (inst->mode)
            {
                case TAG:
                {
                	uint16 mode = 0;
                	uint16 shortadd = 0;

                    dwt_enableframefilter(DWT_FF_DATA_EN | DWT_FF_ACK_EN); //allow data, ACK frames;
                    //inst->frameFilteringEnabled = 1 ;
                    dwt_setpanid(inst->panID);

                    memcpy(inst->eui64, &tagaddress, ADDR_BYTE_SIZE_S);
                    dwt_seteui(inst->eui64);

                    inst->newRangeTagAddress = inst->eui64[0] + (inst->eui64[1] << 8);

                    //set source address into the message structure
                    inst->msg.sourceAddr[0] = inst->eui64[0];
                    shortadd = inst->msg.sourceAddr[1] = inst->eui64[1];
                    shortadd = (shortadd << 8) + inst->msg.sourceAddr[0];
                    dwt_setaddress16(shortadd);

                    //Start off by Sleeping 1st...
                    inst->nextState = TA_TXPOLL_WAIT_SEND;
                    inst->testAppState = TA_TXE_WAIT;
                    inst->instToSleep = 0 ;

                    inst->rangeNum = 0;
                    inst->pollNum = 0;
                    inst->tagSleepCorrection = 0;

                    mode = (DWT_LOADUCODE|DWT_PRESRV_SLEEP|DWT_CONFIG|DWT_TANDV);

                    lps22hb_xl();


					if((dwt_getldotune() != 0)) //if we need to use LDO tune value from OTP kick it after sleep
							mode |= DWT_LOADLDO;
                    if(inst->configData.txPreambLength == DWT_PLEN_64)  //if using 64 length preamble then use the corresponding OPSet
                    {
                        mode |= DWT_LOADOPSET;
                    }
#if (DEEP_SLEEP == 1)
                    if (inst->sleepingEabled)
                        dwt_configuresleep(mode, DWT_WAKE_WK|DWT_WAKE_CS|DWT_SLP_EN); //configure the on wake parameters (upload the IC config settings)
#endif
                    inst->instancewaketime = portGetTickCnt();
                }
                break;
                case ANCHOR:
                {
        			dwt_forcetrxoff();
        			dwt_rxreset();

                    memcpy(inst->eui64, &anchoraddress, ADDR_BYTE_SIZE_S);
                    dwt_seteui(inst->eui64);

                    dwt_setpanid(inst->panID);

                    //set source address into the message structure
                    inst->msg.sourceAddr[0] = inst->eui64[0];
                    shortadd = inst->msg.sourceAddr[1] = inst->eui64[1];
                    shortadd = (shortadd << 8) + inst->msg.sourceAddr[0];
                    dwt_setaddress16(shortadd);

                	//if address = 0x8000
                	if(shortadd == GATEWAY_ANCHOR_ADDR)
                	{
                		inst->gatewayAnchor = TRUE;
                        dwt_enableframefilter(DWT_FF_NOTYPE_EN); //allow data, ack frames;
                	}
                	else //other anchors have filtering enabled - they only report their ranges with each tag
                	{
                		inst->gatewayAnchor = FALSE;
                        dwt_enableframefilter(DWT_FF_DATA_EN | DWT_FF_ACK_EN); //allow data, ack frames;
                	}
                    // First time anchor listens we don't do a delayed RX
                    dwt_setrxaftertxdelay(0);
                    //change to next state - wait to receive a message
                    inst->testAppState = TA_RXE_WAIT ;

                }
                break;
                case LISTENER:
                {
                    dwt_enableframefilter(DWT_FF_NOTYPE_EN); //disable frame filtering
					dwt_setrxaftertxdelay(0); //no delay of turning on of RX
                    dwt_setrxtimeout(0);
                    //change to next state - wait to receive a message
                    inst->testAppState = TA_RXE_WAIT ;
                }
                break ; // end case TA_INIT
                default:
                break;
            }
            break; // end case TA_INIT

        case TA_SLEEP_DONE :
        {
            event_data_t* dw_event = instance_getevent(10); //clear the event from the queue
            // waiting for timout from application to wakup IC
            if (dw_event->type != DWT_SIG_RX_TIMEOUT)
            {
                // if no pause and no wake-up timeout continu waiting for the sleep to be done.
            	inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //wait here for sleep timeout
                break;
            }

            inst->done = INST_NOT_DONE_YET;
            inst->instToSleep = 0;
            inst->testAppState = inst->nextState;
            inst->nextState = 0; //clear
            inst->instanceTimerTimeSaved = inst->instanceTimerTime = portGetTickCnt(); //set timer base

#if (DEEP_SLEEP == 1)
            {
            	uint32 x = 0;

                //wake up device from low power mode
                //NOTE - in the ARM  code just drop chip select for 200us
            	led_on(LED_PC9);
                port_SPIx_clear_chip_select();  //CS low
                instance_data[0].dwIDLE = 0; //reset DW1000 IDLE flag

                setup_DW1000RSTnIRQ(1); //enable RSTn IRQ

                Sleep(2);   //200 us to wake up - need 2 as Sleep(1) is ~ 175 us
                //then wait 5ms for DW1000 XTAL to stabilise - instead of wait we wait for RSTn to go high
                //Sleep(5);

                //need to poll to check when the DW1000 is in IDLE, the CPLL interrupt is not reliable
                //when RSTn goes high the DW1000 is in INIT, it will enter IDLE after PLL lock (in 5 us)
                while(instance_data[0].dwIDLE == 0) // this variable will be sent in the IRQ (process_dwRSTn_irq)
                {
                	 //wait for DW1000 to go to IDLE state RSTn pin to go high
                	x++;
                }
                setup_DW1000RSTnIRQ(0); //disable RSTn IRQ
                port_SPIx_set_chip_select();  //CS high

                //!!! NOTE it takes ~35us for the DW1000 to download AON and lock the PLL and be in IDLE state
                //do some dummy reads of the dev ID register to make sure DW1000 is in IDLE before setting LEDs
            	x = dwt_readdevid(); //dummy read... need to wait for 5 us to exit INIT state (5 SPI bytes @ ~18 MHz)
            	x = dwt_readdevid(); //dummy read... need to wait for 5 us to exit INIT state (5 SPI bytes @ ~18 MHz)
            	x = dwt_readdevid(); //dummy read... need to wait for 5 us to exit INIT state (5 SPI bytes @ ~18 MHz)
            	x = dwt_readdevid(); //dummy read... need to wait for 5 us to exit INIT state (5 SPI bytes @ ~18 MHz)

            	x = dwt_readdevid(); //dummy read... need to wait for 5 us to exit INIT state (5 SPI bytes @ ~18 MHz)
                /*if(x != DWT_DEVICE_ID)
                {
                	x = dwt_readdevid(); //dummy read... need to wait for 5 us to exit INIT state (5 SPI bytes @ ~18 MHz)
                }*/
                led_off(LED_PC9);
                //this is platform dependent - only program if DW EVK/EVB
                dwt_setleds(1);

                //MP bug - TX antenna delay needs reprogramming as it is not preserved (only RX)
                dwt_settxantennadelay(inst->txantennaDelay) ;

                //set EUI as it will not be preserved unless the EUI is programmed and loaded from NVM
				dwt_setpanid(inst->panid);
				dwt_seteui(inst->eui64);
            }
#else
            Sleep(3); //to approximate match the time spent in the #if above
#endif
            instancesetantennadelays(); //this will update the antenna delay if it has changed
            instancesettxpower(); //configure TX power if it has changed
        }
            break;

        case TA_TXE_WAIT : //either go to sleep or proceed to TX a message
            // printf("TA_TXE_WAIT") ;
            //if we are scheduled to go to sleep before next transmission then sleep first.
            if((inst->nextState == TA_TXPOLL_WAIT_SEND)
                    && (inst->instToSleep)  //go to sleep before sending the next poll/ starting new ranging exchange
                    )
            {
            	inst->rangeNum++; //increment the range number before going to sleep
            	inst->pollNum = 0; //reset the poll number
                //the app should put chip into low power state and wake up after tagSleepTime_ms time...
                //the app could go to *_IDLE state and wait for uP to wake it up...
                inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT_TO; //don't sleep here but kick off the Sleep timer countdown
                inst->testAppState = TA_SLEEP_DONE;

#if (DEEP_SLEEP == 1)
                //put device into low power mode
                dwt_entersleep(); //go to sleep

#endif
            }
            else //proceed to configuration and transmission of a frame
            {
                inst->testAppState = inst->nextState;
                inst->nextState = 0; //clear
            }
            break ; // end case TA_TXE_WAIT


        case TA_TX_ORAN :
        {
        	uint8 len = 0;

			inst->msg.destAddr[0] = 0xff;
			inst->msg.destAddr[1] = 0xff;

            setupmacframedata(inst, 1, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_ONE_RAN);
            dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

			//set the delayed rx on time (the response message will be sent after this delay)
			dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
			dwt_setrxtimeout(10);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)

			//response is expected
			inst->wait4ack = DWT_RESPONSE_EXPECTED;

			dwt_writetxfctrl(inst->psduLength, 0,1);

			dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);


            inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
            inst->previousState = TA_TX_ORAN ;
            inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)
        }
            break;

        case TA_TX_RAN_START :
        {
        	uint8 anc_len = 0;

    		inst->msg.destAddr[0] = result.tag_add[0];
    		inst->msg.destAddr[1] = result.tag_add[1];

    		anc_len = anc.list_len;
    		anc_len = anc_len*2;

    		memcpy(&inst->msg.messageData[1],&anc.list_len,1);
    		memcpy(&inst->msg.messageData[2],&anc.anc_add[0],anc_len);

    		anc_len = anc_len + 2;

    		setupmacframedata(inst, anc_len, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_RAN_START);
            dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

			//set the delayed rx on time (the response message will be sent after this delay)
			dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
			dwt_setrxtimeout((uint16)inst->fwtoTime_sy);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)

			//response is expected
			inst->wait4ack = DWT_RESPONSE_EXPECTED;

			dwt_writetxfctrl(inst->psduLength, 0,1);

			dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);


            inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
            inst->previousState = TA_TX_RAN_START ;
            inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)

        }
        break;

        case TA_TX_RAN_START_ACK :
            {
            	ran_tag_flag = 1;

            	setupmacframedata(inst, 1, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_RAN_START_ACK);
            	dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

            	//set the delayed rx on time (the response message will be sent after this delay)
            	dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
            	dwt_setrxtimeout(0);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)

            	//response is expected
            	inst->wait4ack = DWT_RESPONSE_EXPECTED;

            	dwt_writetxfctrl(inst->psduLength, 0,1);

            	dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);


            	inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
            	inst->previousState = TA_TX_RAN_START_ACK ;
            	inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)
            }
            break;

        case TA_TX_SENSOR :
            {
            	uint8 len = 0;
            	static axis1bit32_t data_raw_pressure;

				inst->msg.destAddr[0] = sync_anc[0];
				inst->msg.destAddr[1] = sync_anc[1];
				memset(rfid_result,0,100);
        		memcpy(&inst->msg.messageData[1],&pha,4);
        		memcpy(&inst->msg.messageData[5],&rfid_result[0],1);
        		memcpy(&inst->msg.messageData[6],&rfid_result[1],(rfid_result[0]*4));


        		len = rfid_result[0]*4 + 6;
                setupmacframedata(inst, len, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_SENSOR);
                dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

				//set the delayed rx on time (the response message will be sent after this delay)
				dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
				dwt_setrxtimeout(0);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)

				//response is expected
				inst->wait4ack = DWT_RESPONSE_EXPECTED;

				dwt_writetxfctrl(inst->psduLength, 0, 1);

				dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

                inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
                inst->previousState = TA_TX_SENSOR ;
                inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)
    			memset(rfid_result,0,100);

            }
            break;

        case TA_TXPOLL_WAIT_SEND :
			{

				inst->pollNum &= 0x1;

				ranging_dest(inst); // Set Anchor Address to poll next

				anc_cnt++;
				inst->msg.messageData[POLL_RNUM] = inst->rangeNum;
				inst->msg.messageData[POLL_PNUM] = inst->pollNum;
				setupmacframedata(inst, TAG_POLL_MSG_LEN, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_TAG_POLL);
				dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

				inst->pollNum++;

				//set the delayed rx on time (the response message will be sent after this delay)
				dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
				dwt_setrxtimeout((uint16)inst->fwtoTime_sy);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)

				//response is expected
				inst->wait4ack = DWT_RESPONSE_EXPECTED;

				dwt_writetxfctrl(inst->psduLength, 0,1);

				dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);


				inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
				inst->previousState = TA_TXPOLL_WAIT_SEND ;
				inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)

			}
            break;

        case TA_TXRESPONSE_WAIT_SEND :
        {
			inst->msg.messageData[RES_R1] = inst->tagSleepCorrection & 0xFF;
			inst->msg.messageData[RES_R2] = (inst->tagSleepCorrection >> 8) & 0xFF;

			setupmacframedata(inst, ANCH_RESPONSE_MSG_LEN, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_ANCH_RESP);
			dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data
			dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)

			dwt_setrxtimeout(0);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)

			//response is expected
			inst->wait4ack = DWT_RESPONSE_EXPECTED;

			dwt_writetxfctrl(inst->psduLength, 0,1);

			dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

            inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
            inst->previousState = TA_TXRESPONSE_WAIT_SEND ;
            inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)
        }
        break;

        case TA_TXFINAL_WAIT_SEND :
        {
			setupmacframedata(inst, 1, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_TAG_FINAL);
			dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

			//turn on the receiver to receive the report... as it is coming after the final
			inst->wait4ack = DWT_RESPONSE_EXPECTED;
			dwt_setrxaftertxdelay(0); //the report will not come sooner than 200 us after the final... this is platform dependent

			dwt_writetxfctrl(inst->psduLength, 0, 1);

			dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

			dwt_setrxtimeout((uint16)inst->fwtoTime_sy*10); //

            inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
            inst->previousState = TA_TXFINAL_WAIT_SEND ;
            inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)

        }
        break;

        case TA_TXREPORT_WAIT_SEND : //the frame is loaded and sent from the RX callback
            {
				// Write calculated TOF into report message
				memcpy(&(inst->msg.messageData[TOFR]), &inst->tof, 5);

				inst->msg.messageData[TOFRN] = inst->rangeNum;

				setupmacframedata(inst, RANGINGINIT_MSG_LEN, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_ANCH_TOFR);

				dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

				//set the delayed rx on time (the ranging init will be sent after this delay)
				//subtract 1ms to make sure the receiver is on before the message comes in
				dwt_setrxaftertxdelay(0);  //units are ~us - wait for wait4respTIM before RX on (delay RX)

				//response is expected
				inst->wait4ack = DWT_RESPONSE_EXPECTED;
				//anchor - we don't use timeout

				dwt_writetxfctrl(inst->psduLength, 0,1);

				dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

				inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
				inst->previousState = TA_TXREPORT_WAIT_SEND ;

				//use anchor rx timeout to timeout and re-send the ToF report
				inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT_TO;

				inst->newRange = 1;

            }
            break;

        case TA_TX_WAIT_CONF :
        {
        	event_data_t* dw_event = instance_getevent(11); //get and clear this event

        	//NOTE: Can get the ACK before the TX confirm event for the frame requesting the ACK
        	//this happens because if polling the ISR the RX event will be processed 1st and then the TX event
        	//thus the reception of the ACK will be processed before the TX confirmation of the frame that requested it.
        	if(dw_event->type != DWT_SIG_TX_DONE) //wait for TX done confirmation
        	{
        		if(dw_event->type == DWT_SIG_RX_TIMEOUT) //got RX timeout - i.e. did not get the response (e.g. ACK)
        		{
        			//printf("RX timeout in TA_TX_WAIT_CONF (%d)\n", inst->previousState);
        			//we need to wait for SIG_TX_DONE and then process the timeout and re-send the frame if needed
        			inst->gotTO = 1;
        		}
        		if(dw_event->type == SIG_RX_ACK)
        		{
        			inst->wait4ack = 0 ; //clear the flag as the ACK has been received
        			//printf("RX ACK in TA_TX_WAIT_CONF... wait for TX confirm before changing state (%d)\n", inst->previousState);
        		}

        		inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT;
        		break;
        	}

        	inst->done = INST_NOT_DONE_YET;

        	if (inst->gotTO) //timeout
        	{
        		//printf("got TO in TA_TX_WAIT_CONF\n");
        		inst_processrxtimeout(inst);
        		inst->gotTO = 0;
        		inst->wait4ack = 0 ; //clear this
        		break;
        	}
        	else
        	{
        		if(inst->previousState == TA_TX_RAN_START)
        		{
        			owr_poll_tx_time = dw_event->timeStamp;

        		}
        		else if(inst->previousState == TA_TX_RAN_START_ACK)
        		{
        			owr_response_tx_time = dw_event->timeStamp;

        		}
        		if(inst->previousState == TA_TXPOLL_WAIT_SEND)
        		{
        			inst->txu.txTimeStamp = dw_event->timeStamp;
        			poll_tx_time = dw_event->timeStamp;
        		}
        		else if(inst->previousState == TA_TXRESPONSE_WAIT_SEND)
        		{
        			response_tx_time = dw_event->timeStamp;
        		}
        		else if(inst->previousState == TA_TXFINAL_WAIT_SEND)
        		{
        			final_tx_time = dw_event->timeStamp;
        		}

        		inst->testAppState = TA_RXE_WAIT ;                      // After sending, tag expects response/report, anchor waits to receive a final/new poll
        		//fall into the next case (turn on the RX)
        		message = 0;
        	}

        }
        break ; // end case TA_TX_WAIT_CONF


        case TA_RXE_WAIT :
        // printf("TA_RXE_WAIT") ;
        {
            if(inst->wait4ack == 0) //if this is set the RX will turn on automatically after TX
            {
                //turn RX on
                //instancerxon(inst, 0, 0) ;   // turn RX on, with/without delay
            	dwt_rxenable(0) ;  // turn RX on, without delay
            }
            else
            {
                inst->wait4ack = 0 ; //clear the flag, the next time we want to turn the RX on it might not be auto
            }

            if (inst->mode != LISTENER)
            {
            	if (inst->previousState != TA_TXREPORT_WAIT_SEND) //we are going to use anchor timeout and re-send the report
                //we are going to use anchor/tag timeout
            		inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //using RX FWTO
            }

            inst->testAppState = TA_RX_WAIT_DATA;   // let this state handle it

            // end case TA_RXE_WAIT, don't break, but fall through into the TA_RX_WAIT_DATA state to process it immediately.
            if(message == 0) break;
        }

        case TA_RX_WAIT_DATA :                                                                     // Wait RX data
           //printf("TA_RX_WAIT_DATA %d", message) ;

            switch (message)
            {

				case SIG_RX_ACK :
				{
					//event_data_t* dw_event = instance_getevent(14); //get and clear this event
					instance_getevent(14); //get and clear this event
					//else we did not expect this ACK turn the RX on again
					inst->testAppState = TA_RXE_WAIT ;              // wait for next frame
					inst->done = INST_NOT_DONE_YET;
				}
				break;

                //if we have received a DWT_SIG_RX_OKAY event - this means that the message is IEEE data type - need to check frame control to know which addressing mode is used
                case DWT_SIG_RX_OKAY :
                {
                    event_data_t* dw_event = instance_getevent(15); //get and clear this event
                    uint8  srcAddr[8] = {0,0,0,0,0,0,0,0};
					uint8  dstAddr[8] = {0,0,0,0,0,0,0,0};
                    int fcode = 0;
                    int fn_code = 0;
                    uint8 *messageData;

					//dwt_forcetrxoff();
					inst->stoptimer = 0; //clear the flag, as we have received a message

                    // 16 or 64 bit addresses
                    switch(dw_event->msgu.frame[1]&0xCC)
                    {
                        case 0xCC: //
                            memcpy(&srcAddr[0], &(dw_event->msgu.rxmsg_ll.sourceAddr[0]), ADDR_BYTE_SIZE_L);
							memcpy(&dstAddr[0], &(dw_event->msgu.rxmsg_ll.destAddr[0]), ADDR_BYTE_SIZE_L);
                            fn_code = dw_event->msgu.rxmsg_ll.messageData[FCODE];
                            messageData = &dw_event->msgu.rxmsg_ll.messageData[0];
                            break;
                        case 0xC8: //
                            memcpy(&srcAddr[0], &(dw_event->msgu.rxmsg_sl.sourceAddr[0]), ADDR_BYTE_SIZE_L);
							memcpy(&dstAddr[0], &(dw_event->msgu.rxmsg_sl.destAddr[0]), ADDR_BYTE_SIZE_S);
                            fn_code = dw_event->msgu.rxmsg_sl.messageData[FCODE];
                            messageData = &dw_event->msgu.rxmsg_sl.messageData[0];
                            break;
                        case 0x8C: //
                            memcpy(&srcAddr[0], &(dw_event->msgu.rxmsg_ls.sourceAddr[0]), ADDR_BYTE_SIZE_S);
							memcpy(&dstAddr[0], &(dw_event->msgu.rxmsg_ls.destAddr[0]), ADDR_BYTE_SIZE_L);
                            fn_code = dw_event->msgu.rxmsg_ls.messageData[FCODE];
                            messageData = &dw_event->msgu.rxmsg_ls.messageData[0];
                            break;
                        case 0x88: //
                            memcpy(&srcAddr[0], &(dw_event->msgu.rxmsg_ss.sourceAddr[0]), ADDR_BYTE_SIZE_S);
							memcpy(&dstAddr[0], &(dw_event->msgu.rxmsg_ss.destAddr[0]), ADDR_BYTE_SIZE_S);
                            fn_code = dw_event->msgu.rxmsg_ss.messageData[FCODE];
                            messageData = &dw_event->msgu.rxmsg_ss.messageData[0];
                            break;
                    }

                    {
                    	fcode = fn_code;

                        switch(fcode)
                        {
                        	dwt_forcetrxoff();
                    	case RTLS_DEMO_MSG_RAN_START:
						{
							int n = 0;
							double tag_pos_x;
							double tag_pos_y;
							double tag_pos_z;
							uint32 dop;
							uint32 tag_pos_t;
							dwt_setrxtimeout(0);

							dop = 011;
							inst->msg.destAddr[0] = srcAddr[0];
							inst->msg.destAddr[1] = srcAddr[1];
							memcpy(&result.tag_Position[0],&messageData[1],8);
							memcpy(&result.tag_pos_time[0],&messageData[9],4);
							if(result.tag_Position[0] == 0) // plus
							{
								tag_pos_x = result.tag_Position[1] + (result.tag_Position[2] << 8) + (result.tag_Position[3] << 16);
								tag_pos_x = tag_pos_x/10;
							}
							else
							{
								tag_pos_x = result.tag_Position[1] + (result.tag_Position[2] << 8) + (result.tag_Position[3] << 16);
								tag_pos_x = tag_pos_x/10;
								tag_pos_x = (tag_pos_x * -1);
							}
							if(result.tag_Position[4] == 0) // plus
							{
								tag_pos_y = result.tag_Position[5] + (result.tag_Position[6] << 8) + (result.tag_Position[7] << 16);
								tag_pos_y = tag_pos_y/10;
							}
							else
							{
								tag_pos_y = result.tag_Position[5] + (result.tag_Position[6] << 8) + (result.tag_Position[7] << 16);
								tag_pos_y = tag_pos_y/10;
								tag_pos_y = (tag_pos_y * -1);
							}
							owr_poll_rx_time = dw_event->timeStamp;

							tag_pos_z = 123.45;
							tag_pos_t = result.tag_pos_time[0] + (result.tag_pos_time[1] << 8) + (result.tag_pos_time[2] << 16) + (result.tag_pos_time[3] << 24);
							/*
							n = sprintf((char*)&usbVCOMout[0], "@,%04d,%+06.0lf,%+06.0lf,%03d,%d,#", shortadd, tag_pos_x, tag_pos_y, dop, tag_pos_t);
							send_usbmessage(&usbVCOMout[0], n);
							usb_run();
							*/

							memset(result.tag_Position,0,10);
							inst->testAppState = TA_TXE_WAIT;
							inst->nextState = TA_TX_RAN_START_ACK;
						}
						break;

                    	case RTLS_DEMO_MSG_RAN_START_ACK:
						{
							dwt_setrxtimeout(0);
							inst->testAppState = TA_RXE_WAIT;
						}

						break;

                    	case RTLS_DEMO_MSG_SYNC:
						{
							uint8 len = 0;
							uint64 aRxT, aTxT ;
							uint64 anc_txpoll = 0;
							uint64 anc_rxrespone = 0;
							uint64 pollRespRTD  = 0;
							uint16 tag_flag = 0;
							uint8 route_distance = 0;
							if(shortadd <= 0x8000)
							{

								if(ran_tag_flag == 1)
								{
									sync_anc[0] = srcAddr[0];
									sync_anc[1] = srcAddr[1];

									len = messageData[1]*2;
									memcpy(&anc_txpoll,&messageData[2+len],5);
									memcpy(&anc_rxrespone,&messageData[7+len],5);
									route_distance = messageData[12+len];
									aRxT = (anc_rxrespone - anc_txpoll) & MASK_40BIT;
									aTxT = (owr_response_tx_time - owr_poll_rx_time) & MASK_40BIT;
									pollRespRTD = (aRxT - aTxT) & MASK_40BIT;

									inst->tof = ((pollRespRTD) & MASK_40BIT);

									reportTOF_s(inst);
/*
									if((uint16)inst_idist >= route_distance)
									{
										dwt_setrxtimeout(0);
										inst->testAppState = TA_RXE_WAIT;
									}
									else
									{
										inst->testAppState = TA_TXE_WAIT;
										inst->nextState = TA_TX_ORAN;
									}
									*/

									inst->testAppState = TA_TXE_WAIT;
									inst->nextState = TA_TX_ORAN;
								}
								else
								{
									dwt_setrxtimeout(0);
									inst->testAppState = TA_RXE_WAIT;
								}
								ran_tag_flag = 0;
								/*

								sync_anc[0] = srcAddr[0];
								sync_anc[1] = srcAddr[1];

								inst->testAppState = TA_TXE_WAIT;
								inst->nextState = TA_TX_ORAN;
								*/
							}

							memset(anc.owr_anc_add,0,2);

						}
						break;

                    	case RTLS_DEMO_MSG_TAG_POLL:
						{
							int currentSlotTime = 0;
							int expectedSlotTime = 0;


							inst->newrangepolltime = dw_event->uTimeStamp;
							inst->rangeNum = messageData[POLL_RNUM];
							inst->pollNum = messageData[POLL_PNUM];

							inst->tagSleepCorrection = 0;

							inst->tagPollRxTime = dw_event->timeStamp ; //Poll's Rx time

							inst->testAppState = TA_TXRESPONSE_WAIT_SEND ; // send our response


							inst->msg.destAddr[0] = srcAddr[0];
							inst->msg.destAddr[1] = srcAddr[1];

						}
						break; //RTLS_DEMO_MSG_TAG_POLL

						case RTLS_DEMO_MSG_ANCH_RESP:
						{

							inst->tagSleepRnd = 0; // once we have initial response from Anchor #0 the slot correction acts and we don't need this anymore

							inst->anchorRespRxTime = dw_event->timeStamp ; //Response's Rx time

							inst->testAppState = TA_TXFINAL_WAIT_SEND ; // send our response / the final

							/*
							inst->relpyAddress[0] = srcAddr[0];
							inst->relpyAddress[1] = srcAddr[1];
							*/
							inst->msg.destAddr[0] = srcAddr[0];
							inst->msg.destAddr[1] = srcAddr[1];

						}
						break; //RTLS_DEMO_MSG_ANCH_RESP

						case RTLS_DEMO_MSG_TAG_FINAL:
						{
							uint64 tagFinalRxTime  = 0;

							tagFinalRxTime = dw_event->timeStamp ;
							final_rx_time = tagFinalRxTime;

							inst->msg.destAddr[0] = srcAddr[0];
							inst->msg.destAddr[1] = srcAddr[1];

							inst->testAppState = TA_TXREPORT_WAIT_SEND ; // send the report with the calculated time of flight
						}
						break; //RTLS_DEMO_MSG_TAG_FINAL

						case RTLS_DEMO_MSG_ANCH_TOFR:
						{

							uint64 tRxT, tTxT, aRxT, aTxT ;
							uint64 tagFinalTxTime  = 0;
							uint64 tagFinalRxTime  = 0;
							uint64 tagPollRxTime  = 0;
							uint64 anchorRespTxTime  = 0;
							uint64 pollRespRTD  = 0;
							uint64 respFinalRTD  = 0;

							dwt_rxdiag_t scanlog;
							double_t f1,f2,f3,PA,CIR;
							uint8 anc_barodata[6];

							//printf("FinalRx Timestamp: %4.15e\n", convertdevicetimetosecu(dw_event.timeStamp));
							inst->delayedReplyTime = 0 ;

							// times measured at Tag extracted from the message buffer
							// extract 40bit times
							memcpy(&tagPollRxTime, &(messageData[1]), 5);
							memcpy(&anchorRespTxTime, &(messageData[7]), 5);
							memcpy(&tagFinalRxTime, &(messageData[12]), 5);

							aRxT = (inst->anchorRespRxTime - poll_tx_time) & MASK_40BIT;
							aTxT = (anchorRespTxTime - tagPollRxTime) & MASK_40BIT;
							pollRespRTD = (aRxT - aTxT) & MASK_40BIT;

							tRxT = (tagFinalRxTime - anchorRespTxTime) & MASK_40BIT;
							tTxT = (final_tx_time - inst->anchorRespRxTime) & MASK_40BIT;
							respFinalRTD = (tRxT - tTxT) & MASK_40BIT;
							inst->tof = ((pollRespRTD + respFinalRTD) & MASK_40BIT);

							reportTOF(inst);
							if(nxn_flag == 1) anchor_select();
							dwt_readdiagnostics(&scanlog);
							f1 = scanlog.firstPathAmp1;
							f2 = scanlog.firstPathAmp2;
							f3 = scanlog.firstPathAmp3;
							PA = scanlog.rxPreamCount;
							CIR = scanlog.maxGrowthCIR;

							RSS1 = (int)((10 * (log10((pow(f1,2)+pow(f2,2)+pow(f3,2))/pow(PA,2)))- 113.77)*100);
							RSS2 = (int)((10 * (log10(CIR * pow(2,17)/pow(PA,2)))-113.77)*100);
							rss = (uint16)(-1*RSS1);

							memcpy(&anc_barodata[0], &(messageData[17]), 4);

							result.anc_data[((repot_cnt)*14)] = srcAddr[0];
							result.anc_data[((repot_cnt)*14)+1] = srcAddr[1];
							result.anc_data[((repot_cnt)*14)+2] = tof_distance & 0xff; //distance
							result.anc_data[((repot_cnt)*14)+3] = (tof_distance & 0xff00) >> 8;
							result.anc_data[((repot_cnt)*14)+4] = (tof_distance & 0xff0000) >> 16;
							result.anc_data[((repot_cnt)*14)+5] = (tof_distance & 0xff000000) >> 24;
							result.anc_data[((repot_cnt)*14)+6] = rss & 0xff; //RSS
							result.anc_data[((repot_cnt)*14)+7] = (rss & 0xff00) >> 8;
							result.anc_data[((repot_cnt)*14)+8] = anc_barodata[0];
							result.anc_data[((repot_cnt)*14)+9] = anc_barodata[1];
							result.anc_data[((repot_cnt)*14)+10] = anc_barodata[2];
							result.anc_data[((repot_cnt)*14)+11] = anc_barodata[3];
							result.anc_data[((repot_cnt)*14)+12] = anc_barodata[4];
							result.anc_data[((repot_cnt)*14)+13] = anc_barodata[5];

							repot_cnt++;

							if(anc_cnt >= anc.list_len)
							{
								inst->testAppState = TA_TXE_WAIT;
								inst->nextState = TA_TX_UP ; // send next poll
								anc_cnt = 0;

							}
							else
							{
								inst->testAppState = TA_TXE_WAIT;
								inst->nextState = TA_TXPOLL_WAIT_SEND ; // send next poll
							}
						}
						break; //RTLS_DEMO_MSG_ANCH_TOFR

                            default:
                            {
                                inst->testAppState = TA_RXE_WAIT ;              // wait for next frame
                                dwt_setrxaftertxdelay(0);

                            }
                            break;
                        } //end switch (fcode)
						if(dw_event->msgu.frame[0] & 0x20)
						{
							//as we only pass the received frame with the ACK request bit set after the ACK has been sent
							instance_getevent(16); //get and clear the ACK sent event
						}


                    } //end else

                    if((inst->instToSleep == 0) && (inst->mode == LISTENER) /*|| (inst->mode == ANCHOR)*/)//update received data, and go back to receiving frames
                    {

                        inst->testAppState = TA_RXE_WAIT ;              // wait for next frame

                        dwt_setrxaftertxdelay(0);
                    }

                }
                break ; //end of DWT_SIG_RX_OKAY

                case DWT_SIG_RX_TIMEOUT :
                    instance_getevent(17); //get and clear this event
                    //printf("PD_DATA_TIMEOUT %d\n", inst->previousState) ;
                    inst_processrxtimeout(inst);
                    message = 0; //clear the message as we have processed the event
                break ;

                case DWT_SIG_TX_AA_DONE: //ignore this event - just process the rx frame that was received before the ACK response
                case 0:
                default :
                {
                    //if(DWT_SIG_TX_AA_DONE == message) printf("Got SIG_TX_AA_DONE in RX wait - ignore\n");
                    if(inst->done == INST_NOT_DONE_YET) inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT;
                }
                break;

            }
            break ; // end case TA_RX_WAIT_DATA
            default:
                //printf("\nERROR - invalid state %d - what is going on??\n", inst->testAppState) ;
            break;
    } // end switch on testAppState

    return inst->done;
} // end testapprun()

// -------------------------------------------------------------------------------------------------------------------
#if NUM_INST != 1
#error These functions assume one instance only
#else


// -------------------------------------------------------------------------------------------------------------------
// function to initialise instance structures
//
//// Returns 0 on success and -1 on error
int instance_init_s(int mode)
{
    instance_data_t* inst = instance_get_local_structure_ptr(0);

    inst->mode =  mode;                                // assume anchor,
    inst->testAppState = TA_INIT ;

    // if using auto CRC check (DWT_INT_RFCG and DWT_INT_RFCE) are used instead of DWT_INT_RDFR flag
    // other errors which need to be checked (as they disable receiver) are
    //dwt_setinterrupt(DWT_INT_TFRS | DWT_INT_RFCG | (DWT_INT_SFDT | DWT_INT_RFTO /*| DWT_INT_RXPTO*/), 1);
    dwt_setinterrupt(DWT_INT_TFRS | DWT_INT_RFCG | (DWT_INT_ARFE | DWT_INT_RFSL | DWT_INT_SFDT | DWT_INT_RPHE | DWT_INT_RFCE | DWT_INT_RFTO /*| DWT_INT_RXPTO*/), 1);

    //this is platform dependent - only program if DW EVK/EVB
    dwt_setleds(3) ; //configure the GPIOs which control the LEDs on EVBs

    dwt_setcallbacks(instance_txcallback, instance_rxgoodcallback, instance_rxtimeoutcallback, instance_rxerrorcallback);

    inst->anchorListIndex = 0 ;

    return 0 ;
}

extern uint8 dwnsSFDlen[];

// Pre-compute frame lengths, timeouts and delays needed in ranging process.
// /!\ This function assumes that there is no user payload in the frame.
void instance_init_timings(void)
{
    instance_data_t* inst = instance_get_local_structure_ptr(0);
    uint32 pre_len;
    int sfd_len;
    static const int data_len_bytes[FRAME_TYPE_NB] = {
        BLINK_FRAME_LEN_BYTES, RNG_INIT_FRAME_LEN_BYTES, POLL_FRAME_LEN_BYTES,
        RESP_FRAME_LEN_BYTES, FINAL_FRAME_LEN_BYTES};
    int i;
    // Margin used for timeouts computation.
    const int margin_sy = 10 + CUBEMX_DELAY; //For ST's HAL/Cube Mx need bigger margin/longer timout as "immediate" response comes later

    // All internal computations are done in tens of picoseconds before
    // conversion into microseconds in order to ensure that we keep the needed
    // precision while not having to use 64 bits variables.

    // Compute frame lengths.
    // First step is preamble plus SFD length.
    sfd_len = dwnsSFDlen[inst->configData.dataRate];
    switch (inst->configData.txPreambLength)
    {
    case DWT_PLEN_4096:
        pre_len = 4096;
        break;
    case DWT_PLEN_2048:
        pre_len = 2048;
        break;
    case DWT_PLEN_1536:
        pre_len = 1536;
        break;
    case DWT_PLEN_1024:
        pre_len = 1024;
        break;
    case DWT_PLEN_512:
        pre_len = 512;
        break;
    case DWT_PLEN_256:
        pre_len = 256;
        break;
    case DWT_PLEN_128:
        pre_len = 128;
        break;
    case DWT_PLEN_64:
    default:
        pre_len = 64;
        break;
    }
    pre_len += sfd_len;
    // Convert preamble length from symbols to time. Length of symbol is defined
    // in IEEE 802.15.4 standard.
    if (inst->configData.prf == DWT_PRF_16M)
        pre_len *= 99359;
    else
        pre_len *= 101763;
    // Second step is data length for all frame types.
    for (i = 0; i < FRAME_TYPE_NB; i++)
    {
        // Compute the number of symbols for the given length.
        inst->frameLengths_us[i] = data_len_bytes[i] * 8
                         + CEIL_DIV(data_len_bytes[i] * 8, 330) * 48;
        // Convert from symbols to time and add PHY header length.
        if(inst->configData.dataRate == DWT_BR_110K)
        {
            inst->frameLengths_us[i] *= 820513;
            inst->frameLengths_us[i] += 17230800;
        }
        else if (inst->configData.dataRate == DWT_BR_850K)
        {
            inst->frameLengths_us[i] *= 102564;
            inst->frameLengths_us[i] += 2153900;
        }
        else
        {
            inst->frameLengths_us[i] *= 12821;
            inst->frameLengths_us[i] += 2153900;
        }
        // Last step: add preamble length and convert to microseconds.
        inst->frameLengths_us[i] += pre_len;
        inst->frameLengths_us[i] = CEIL_DIV(inst->frameLengths_us[i], 100000);
    }
    // Final frame wait timeout time.
    inst->fwtoTime_sy = US_TO_SY_INT(inst->frameLengths_us[FINAL])
                        + RX_START_UP_SY + margin_sy;
    // Ranging init frame wait timeout time.
    inst->fwtoTimeB_sy = US_TO_SY_INT(inst->frameLengths_us[RNG_INIT])
                         + RX_START_UP_SY + margin_sy;
    // Delay between blink transmission and ranging init reception.
    inst->rnginitW4Rdelay_sy =
        US_TO_SY_INT((RNG_INIT_REPLY_DLY_MS * 1000) - inst->frameLengths_us[BLINK])
        - RX_START_UP_SY;
    // Delay between anchor's response transmission and final reception.
    inst->txToRxDelayAnc_sy = US_TO_SY_INT(TAG_TURN_AROUND_TIME_US) - RX_START_UP_SY - CUBEMX_DELAY;

    // No need to init txToRxDelayTag_sy here as it will be set upon reception
    // of ranging init message.

    // Delay between blink reception and ranging init message transmission.
    inst->rnginitReplyDelay = convertmicrosectodevicetimeu(RNG_INIT_REPLY_DLY_MS * 1000);
    // Delay between poll reception and response transmission. Computed from
    // poll reception timestamp to response transmission timestamp so you have
    // to add poll frame length to delay that must be respected between frames.
#if (IMMEDIATE_RESPONSE == 0)
    inst->responseReplyDelay = convertmicrosectodevicetimeu(ANC_TURN_AROUND_TIME_US + inst->frameLengths_us[POLL]);
#else
    inst->responseReplyDelay = 0 ;
#endif

    // Smart Power is automatically applied by DW chip for frame of which length
    // is < 1 ms. Let the application know if it will be used depending on the
    // length of the longest frame.
    if (inst->frameLengths_us[FINAL] <= 1000)
        inst->smartPowerEn = 1;
    else
        inst->smartPowerEn = 0;
}
uint64 instance_get_addr(void) //get own address
{
    instance_data_t* inst = instance_get_local_structure_ptr(0);
    uint64 x = (uint64) inst->eui64[0];
    x |= (uint64) inst->eui64[1] << 8;
    x |= (uint64) inst->eui64[2] << 16;
    x |= (uint64) inst->eui64[3] << 24;
    x |= (uint64) inst->eui64[4] << 32;
    x |= (uint64) inst->eui64[5] << 40;
    x |= (uint64) inst->eui64[6] << 48;
    x |= (uint64) inst->eui64[7] << 56;


    return (x);
}

uint64 instance_get_tagaddr(void) //get own address
{
    instance_data_t* inst = instance_get_local_structure_ptr(0);
    uint64 x = (uint64) inst->tagList[0][0];
    x |= (uint64) inst->tagList[0][1] << 8;
    x |= (uint64) inst->tagList[0][2] << 16;
    x |= (uint64) inst->tagList[0][3] << 24;
    x |= (uint64) inst->tagList[0][4] << 32;
    x |= (uint64) inst->tagList[0][5] << 40;
    x |= (uint64) inst->tagList[0][6] << 48;
    x |= (uint64) inst->tagList[0][7] << 56;


    return (x);
}

uint64 instance_get_anchaddr(void) //get anchor address (that sent the ToF)
{
    instance_data_t* inst = instance_get_local_structure_ptr(0);
    uint64 x = (uint64) inst->relpyAddress[0];
    x |= (uint64) inst->relpyAddress[1] << 8;
    x |= (uint64) inst->relpyAddress[2] << 16;
    x |= (uint64) inst->relpyAddress[3] << 24;
    x |= (uint64) inst->relpyAddress[4] << 32;
    x |= (uint64) inst->relpyAddress[5] << 40;
    x |= (uint64) inst->relpyAddress[6] << 48;
    x |= (uint64) inst->relpyAddress[7] << 56;
    return (x);
}

//void instancesetreplydelay(int delayms) //delay in ms
//{
//    int instance = 0;
//
//    int margin = 3000; //2000 symbols
//
//	//configure the rx delay receive delay time, it is dependent on the message length
//	float msgdatalen = 0;
//	float preamblelen = 0;
//	int sfdlen = 0;
//	int x = 0;
//
//	//Set the RX timeouts based on the longest expected message - the Final message
//	//Poll = 14, Response = 15, Final = 27, Report = 18 bytes
//	msgdatalen = TAG_FINAL_MSG_LEN + FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC;
//
//	x = (int) ceil(msgdatalen*8/330.0f);
//
//	msgdatalen = msgdatalen*8 + x*48;
//
//	margin = (TAG_FINAL_MSG_LEN - TAG_POLL_MSG_LEN);
//
//	x = (int) ceil(margin*8/330.0f);
//
//	margin = margin*8 + x*48;
//
//	//assume PHR length is 172308us for 110k and 21539us for 850k/6.81M
//	if(instance_data[instance].configData.dataRate == DWT_BR_110K)
//    {
//		msgdatalen *= 8205.13f;
//		msgdatalen += 172308; // PHR length in microseconds
//
//		margin *= 8205.13f;
//
//    }
//	else if(instance_data[instance].configData.dataRate == DWT_BR_850K)
//    {
//		msgdatalen *= 1025.64f;
//		msgdatalen += 21539; // PHR length in microseconds
//
//		margin *= 1025.64f;
//    }
//	else
//    {
//		msgdatalen *= 128.21f;
//		msgdatalen += 21539; // PHR length in microseconds
//
//		margin *= 128.21f;
//	}
//
//	//SFD length is 64 for 110k (always)
//	//SFD length is 8 for 6.81M, and 16 for 850k, but can vary between 8 and 16 bytes
//	sfdlen = dwnsSFDlen[instance_data[instance].configData.dataRate];
//
//	switch (instance_data[instance].configData.txPreambLength)
//    {
//    case DWT_PLEN_4096 : preamblelen = 4096.0f; break;
//    case DWT_PLEN_2048 : preamblelen = 2048.0f; break;
//    case DWT_PLEN_1536 : preamblelen = 1536.0f; break;
//    case DWT_PLEN_1024 : preamblelen = 1024.0f; break;
//    case DWT_PLEN_512  : preamblelen = 512.0f; break;
//    case DWT_PLEN_256  : preamblelen = 256.0f; break;
//    case DWT_PLEN_128  : preamblelen = 128.0f; break;
//    case DWT_PLEN_64   : preamblelen = 64.0f; break;
//            }
//
//	//preamble  = plen * (994 or 1018) depending on 16 or 64 PRF
//	if(instance_data[instance].configData.prf == DWT_PRF_16M)
//	{
//		preamblelen = (sfdlen + preamblelen) * 0.99359f;
//	}
//	else
//	{
//		preamblelen = (sfdlen + preamblelen) * 1.01763f;
//	}
//
//
//	//set the frame wait timeout time - total time the frame takes in symbols
//	instance_data[instance].fwtoTime_sy = 16 + (int)((preamblelen + ((msgdatalen + margin)/1000.0))/ 1.0256);
//
//	//this is the delay used for the delayed transmit (when sending the ranging init, response, and final messages)
//	instance_data[instance].fixedReplyDelay = convertmicrosectodevicetimeu (delayms * 1e3) ;
//
//	instance_data[instance].fixedReplyDelay_ms = (int) delayms ;
//
//	//this it the delay used for configuring the receiver on delay (wait for response delay),
//	instance_data[instance].fixedReplyDelay_sy = (int) (delayms * 1000 / 1.0256) - 16 - (int)((preamblelen + (msgdatalen/1000.0))/ 1.0256); //subtract 16 symbols, as receiver has a 16 symbol start up time
//
//}
void instancesetaddresses(instanceAddressConfig_t *plconfig)
{
    int instance = 0 ;

    instance_data[instance].payload = *plconfig ;       // copy configurations
}

void instance_readaccumulatordata(void)
{
#if DECA_SUPPORT_SOUNDING==1
    instance_data_t* inst = instance_get_local_structure_ptr(0);
    uint16 len = 992 ; //default (16M prf)

    if (inst->configData.prf == DWT_PRF_64M)  // Figure out length to read
        len = 1016 ;

    inst->buff.accumLength = len ;                                       // remember Length, then read the accumulator data

    len = len*4+1 ;   // extra 1 as first byte is dummy due to internal memory access delay

    dwt_readaccdata((uint8*)&(inst->buff.accumData->dummy), len, 0);
#endif  // support_sounding
}

#endif


/* ==========================================================

Notes:

Previously code handled multiple instances in a single console application

Now have changed it to do a single instance only. With minimal code changes...(i.e. kept [instance] index but it is always 0.

Windows application should call instance_init() once and then in the "main loop" call instance_run().

*/
