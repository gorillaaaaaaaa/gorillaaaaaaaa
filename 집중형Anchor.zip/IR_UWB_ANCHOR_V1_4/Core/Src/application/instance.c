/*! ----------------------------------------------------------------------------
 *  @file    instance.c
 *  @brief   DecaWave application level message exchange for ranging demo
 *
 * @attention
 *
 * Copyright 2013 (c) DecaWave Ltd, Dublin, Ireland.
 *
 * All rights reserved.
 *
 * @author DecaWave
 */
#include "compiler.h"
#include "port.h"
#include "deca_device_api.h"
#include "deca_spi.h"
#include "deca_regs.h"

#include "lib.h"
#include "LPS22HB.h"
#include "instance.h"
extern volatile unsigned int Timer2_Counter;
extern volatile unsigned int Timer4_Counter;


// -------------------------------------------------------------------------------------------------------------------
uint8 one_anc_cnt = 0;
uint8 result_cnt = 0;
uint8 bs_flag = 0;
uint64 test_data = 0;
uint16 anc_cnt = 0;
uint16 repot_cnt = 0;
uint8 anc_mode = 0;

extern double inst_idist_s;
extern double inst_idist;
extern uint8 search_flag;
extern uint8 baro_dataxl;
extern uint8 baro_datal;
extern uint8 baro_datah;

uint8 route_ack_flag = 0;
uint8 dest_flag = 0;
uint8 second_flag = 0;
uint32 tof_distance = 0;


uint64 owr_poll_tx_time = 0;
uint64 owr_response_tx_time = 0;
uint64 owr_poll_rx_time = 0;
uint64 owr_response_rx_time = 0;

uint64 poll_tx_time = 0;
uint64 response_tx_time = 0;
uint64 poll_rx_time = 0;
uint64 response_rx_time = 0;
uint64 final_tx_time = 0;
uint64 final_rx_time = 0;

uint8 anc_distance = 0;
uint64 sync_tx_time = 0;
uint64 sync_rx_time = 0;
uint64 pt_tag_rx_time = 0;
uint64 one_ran_rx_time = 0;
uint64 max_timestamp = 0xffffffffff;
uint8 section[2];

uint64 anc_rx_sync[6];
uint64 anc_rx_ran[6];
uint8 timer_flag = 0;
uint8 ran_tag_flag = 0;

extern uint32 pressure_hpa;
extern uint16 temperature;
// -------------------------------------------------------------------------------------------------------------------
//      Data Definitions
// -------------------------------------------------------------------------------------------------------------------

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// NOTE: the maximum RX timeout is ~ 65ms
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

extern uint16 anchoraddress;
extern uint16 tagaddress;

extern uint8_t UserRxBufferFS[1000];

uint16 shortaddress = 0;
// -------------------------------------------------------------------------------------------------------------------
// Functions
// -------------------------------------------------------------------------------------------------------------------
uint32_t  pollcnt=0;
// -------------------------------------------------------------------------------------------------------------------
//
// function to construct the message/frame header bytes
//
// -------------------------------------------------------------------------------------------------------------------
//
void rfid_read(void)
{
    uint8 read_cmd[10];
	uint8 read_tag_id[7];
	if(rfid_state == 0)
	{
		memset(rfid_buf,0,100);
/*
		if(rfid_tog == 1) rfid_tog = 0;
		else if(rfid_tog == 0)
			{
				memset(rfid_data,0,100);
			}
*/
		read_cmd[0] = 0x0a;
		read_cmd[1] = 0xFF;
		read_cmd[2] = 0x02;
		read_cmd[3] = 0x80;
		read_cmd[4] = 0x75;

		for(int k = 0;k<5;k++)
		{
			//USART_SendData(UART4,read_cmd[k]);
			Sleep(1);
		}
		rfid_try = 0;
	}

	if(rfid_state == 1)
	{
		//memset(rfid_buf,0,100);
    	read_tag_id[0] = 0x0a;
    	read_tag_id[1] = 0xFF;
    	read_tag_id[2] = 0x03;
    	read_tag_id[3] = 0x41;
    	read_tag_id[4] = 0x10;
    	read_tag_id[5] = 0xA3;

        rfid_state = 1;
    	rfid_tog = 1;

        for(int k = 0;k<6;k++)
        {
        	//USART_SendData(UART4,read_tag_id[k]);
        	Sleep(1);
        }


	}
    return 0;
}

void instanceconfigframeheader16(instance_data_t *inst)
{
    //set frame type (0-2), SEC (3), Pending (4), ACK (5), PanIDcomp(6)
    inst->msg.frameCtrl[0] = 0x1 /*frame type 0x1 == data*/ | 0x40 /*PID comp*/;

	//source/dest addressing modes and frame version
	inst->msg.frameCtrl[1] = 0x8 /*dest extended address (16bits)*/ | 0x80 /*src extended address (16bits)*/;

	inst->msg.panID[0] = (inst->panID) & 0xff;
	inst->msg.panID[1] = inst->panID >> 8;
    inst->msg.seqNum = inst->frameSN++;
//    inst->msg.panID[0] = (inst->panID) & 0xff;
//    inst->msg.panID[1] = inst->panID >> 8;
//
//    //set frame type (0-2), SEC (3), Pending (4), ACK (5), PanIDcomp(6)
//    inst->msg.frameCtrl[0] = 0x1 /*frame type 0x1 == data*/ | 0x40 /*PID comp*/;
//#if (USING_64BIT_ADDR==1)
//    //source/dest addressing modes and frame version
//    inst->msg.frameCtrl[1] = 0xC /*dest extended address (64bits)*/ | 0xC0 /*src extended address (64bits)*/;
//#else
//    inst->msg.frameCtrl[1] = 0x8 /*dest short address (16bits)*/ | 0x80 /*src short address (16bits)*/;
//#endif
}


// -------------------------------------------------------------------------------------------------------------------
//
// Turn on the receiver with/without delay
//
void instancerxon(instance_data_t *inst, int delayed, uint64 delayedReceiveTime)
{
    if (delayed)
    {
        uint32 dtime;
        dtime =  (uint32) (delayedReceiveTime>>8);
        dwt_setdelayedtrxtime(dtime) ;
    }

    inst->lateRX -= dwt_rxenable(delayed) ;  //- as when fails -1 is returned             // turn receiver on, immediate/delayed

} // end instancerxon()

int instancesendpacket(instance_data_t *inst, int delayedTx)
{
    int result = 0;

    dwt_writetxfctrl(inst->psduLength, 0, 1);
    if(delayedTx)
    {
        uint32 dtime;
        dtime = (uint32) (inst->delayedReplyTime>>8);
        dwt_setdelayedtrxtime(dtime) ;
    }

    //begin delayed TX of frame
    if (dwt_starttx(delayedTx | inst->wait4ack))  // delayed start was too late
    {
        result = 1; //late/error
        inst->lateTX++;
    }


    return result;                                              // state changes
    // after sending we should return to TX ON STATE ?
}
//int instancesendpacket(uint16 length, uint8 txmode, uint32 dtime)
//{
//    int result = 0;
//
//    dwt_writetxfctrl(length, 0, 1);
//    if(txmode & DWT_START_TX_DELAYED)
//    {
//        dwt_setdelayedtrxtime(dtime) ;
//    }
//
//    //begin delayed TX of frame
//    if (dwt_starttx(txmode))  // delayed start was too late
//    {
//        result = 1; //late/error
//    }
//
//    return result;                                              // state changes
//
//}

int destaddress(instance_data_t *inst)
{
	 int getnext = 1;
	    //set destination address (Tag will cycle though the list of anchor addresses)

	    //go to sleep after second poll
	    if(inst->pollNum == 0)
	    {
			while(getnext)
			{
				if(inst->anchorListIndex < MAX_ANCHOR_LIST_SIZE) //Tag will always Poll 4 anchors
				{
					inst->msg.destAddr[0] = inst->anchorListIndex & 0xff;
					inst->msg.destAddr[1] = (GATEWAY_ANCHOR_ADDR >> 8);

					getnext = 0;
				}

				inst->anchorListIndex++ ;
			}
	    }

	    if(inst->anchorListIndex < MAX_ANCHOR_LIST_SIZE)
	    {
	    	return 0;
	    }
	    else
	    {
	        //if we got this far means that we are just about to poll the last anchor in the list for the 2nd time
	        inst->instToSleep = 0 ; //we'll sleep after this poll
	        inst->anchorListIndex = 0; //start from the first anchor in the list after sleep finishes
		}

	    return 0;
//	inst->msg.destAddr[0] = 0x00;
//	inst->msg.destAddr[1] = 0x80;
//
//    return 0;
}
void init_dest(instance_data_t *inst)
{
	uint8 down_check = 0;
	uint8 up_check = 0;
	uint8 add_flag = 0;
	uint16 route_len = 0;
	uint8 my_hop = 1;

	if(shortadd == 0x6000)
	{
		inst->msg.destAddr[0] = 0x01;
		inst->msg.destAddr[1] = 0x80;
	}
	else
	{
		if(inst->testAppState == TA_TX_ROUTE)
		{
			while(add_flag != 1)
			{

				if(shortadd == (route.route_add[down_check] + route.route_add[down_check+1]*256))
				{
					if(route.route_len[0] == my_hop)
					{
						inst->msg.destAddr[0] = route.route_dsr[0];
						inst->msg.destAddr[1] = route.route_dsr[1];
						add_flag = 1;
					}
					else
					{
						inst->msg.destAddr[0] = route.route_add[down_check+2];
						inst->msg.destAddr[1] = route.route_add[down_check+3];
						add_flag = 1;
					}

				}
				else
				{
					down_check = down_check + 2;
					my_hop++;
				}
			}
		}
		else if(inst->testAppState == TA_TX_ANC_REPORT || inst->testAppState == TA_TX_UP || inst->testAppState == TA_TX_ROUTE_ACK)
		{
				up_check = (route.route_len[0] + (route.route_len[1]*256))*2; //data_buf[3] + data_buf[4]*256;

				while(add_flag != 1)
				{
					if(shortadd == (route.route_dsr[0] + route.route_dsr[1]*256))
					{
						inst->msg.destAddr[0] = route.route_add[up_check-2];
						inst->msg.destAddr[1] = route.route_add[up_check-1];
						add_flag = 1;
					}
					else if(shortadd == (route.route_add[up_check-2] + route.route_add[up_check-1]*256))
					{
						inst->msg.destAddr[0] = route.route_add[up_check-4];
						inst->msg.destAddr[1] = route.route_add[up_check-3];
						add_flag = 1;
					}
					else up_check = up_check - 2;
				}

		}
	}

}
int ranging_msg(instance_data_t *inst)
{
	if(bs_anc == 1)
	{

		inst->msg.destAddr[0] = result.srcanc_add[0];
		inst->msg.destAddr[1] = result.srcanc_add[1];

	}
	else
	{
		if(dest_flag == 0)
		{
			inst->msg.destAddr[0] = route.dsr_add[0];
			inst->msg.destAddr[1] = route.dsr_add[1];
		}
		else if(dest_flag == 1)
		{
			inst->msg.destAddr[0] = route.second_add[0];
			inst->msg.destAddr[1] = route.second_add[1];
			second_flag = 1;
			dest_flag = 0;
		}
	}
}
void ranging_dest(instance_data_t *inst)
{

	inst->msg.destAddr[0] = anc.anc_add[(anc_cnt*2)];
	inst->msg.destAddr[1] = anc.anc_add[(anc_cnt*2)+1];

}
// -------------------------------------------------------------------------------------------------------------------
//
// function to configure the frame data, prior to writing the frame to the TX buffer
//
// -------------------------------------------------------------------------------------------------------------------
//
void setupmacframedata(instance_data_t *inst, int len, int framectrllen, int fcode)
{
	inst->msg.messageData[FCODE] = fcode; //message function code (specifies if message is a poll, response or other...)
    inst->psduLength = len + framectrllen;

	instanceconfigframeheader16(inst);
}
// -------------------------------------------------------------------------------------------------------------------
//
// the main instance state machine (all the instance modes Tag, Anchor or Listener use the same statemachine....)
//
// -------------------------------------------------------------------------------------------------------------------
//
int testapprun(instance_data_t *inst, int message)
{
	int n = 0;
    //int done = INST_NOT_DONE_YET;
#ifdef USB_SUPPORT //this is set in the port.h file
    if(UserRxBufferFS[0]==0x30)
	   {
		dwt_forcetrxoff();
		dwt_rxreset();

		data_buf[0] = 0x30;

		UserRxBufferFS[0] = 0;
	   }
#endif
#ifdef USB_SUPPORT		//marker
	if(read_USB())
	{
		if(data_buf[0] == 0x20)  //route down
		{
			uint16 route_len, anc_len = 0;
			bs_anc = 1;
			dwt_forcetrxoff();
			dwt_rxreset();

			memcpy(&route.route_dsr[0],&data_buf[1],2);
			memcpy(&route.route_len[0],&data_buf[3],1);
			route_len = route.route_len[0];
			route_len = route_len*2;
			memcpy(&route.route_add[0],&data_buf[4],route_len);
			anc_cnt = 0;
			if(shortadd == (route.route_dsr[0] + route.route_dsr[1]*256))
			{
				route_ack_flag = 1;

    			memcpy(&route.src_add[0],&data_buf[4+route_len],2);
    			memcpy(&route.dsr_add[0],&data_buf[6+route_len],2);
    			memcpy(&route.second_add[0],&data_buf[8+route_len],2);

    			anc_distance = data_buf[10+route_len];

    			memcpy(&anc.list_len,&data_buf[11+route_len],1);
    			anc_len = anc.list_len;
    			anc_len = anc_len*2;
    			memcpy(&anc.anc_add[0],&data_buf[12+route_len],anc_len);

				inst->testAppState = TA_TXE_WAIT;
				inst->nextState = TA_TXPOLL_WAIT_SEND;

			}
			else
			{
				inst->testAppState = TA_TXE_WAIT;
				inst->nextState = TA_TX_ROUTE;
			}
		}
		else if(data_buf[0] == 0x30)  //tag_address
		{
			uint16 route_len, tag_len = 0;

			dwt_forcetrxoff();
			dwt_rxreset();
			bs_anc = 1;
			result.tag_fail_cnt = 0;
			result.tag_cnt = 0;
			memset(result.one_anc_data,0,256);
			memset(section,0,2);
			result.data_len = 0;
			result.tag_suc_cnt = 0;
			result.tag_fail_cnt = 0;
			result.tag_cnt = 0;
			memset(result.result_total,0,1024);
        	result_cnt = 0;
        	memset(tag_pos,0,8);
        	memset(tag_pos_time,0,4);

			memcpy(&result.srcanc_add[0], &data_buf[1],2);

			memcpy(&result.tag_list_len[0],&data_buf[3],1);
			tag_len = result.tag_list_len[0];
			tag_len = (tag_len*2);
			memcpy(&result.tag_add[0], &data_buf[4],tag_len);
			memcpy(&tag_pos, &data_buf[6],8);
			memcpy(&tag_pos_time, &data_buf[14],4);

			if(shortadd == result.srcanc_add[0] + result.srcanc_add[1]*256)
			{
				inst->testAppState = TA_TXE_WAIT;
				inst->nextState = TA_TX_RAN_START;
			}
			else
			{
				inst->testAppState = TA_TXE_WAIT;
				inst->nextState = TA_TX_RAN_MSG;
			}

		}
		else if(data_buf[0] == 0x10)  //tag_address
		{
			if(data_buf[1] == 0x12)anc_reboot = 1;

		}
		else if(data_buf[0] == 0x31)  //tag_address
		{
			uint16 route_len, tag_len = 0;

			dwt_forcetrxoff();
			dwt_rxreset();

			anc.list_len = 5;

			anc.anc_add[0] = 0x02;
			anc.anc_add[1] = 0x80;
			anc.anc_add[2] = 0x03;
			anc.anc_add[3] = 0x80;
			anc.anc_add[4] = 0x04;
			anc.anc_add[5] = 0x80;
			anc.anc_add[6] = 0x05;
			anc.anc_add[7] = 0x80;
			anc.anc_add[8] = 0x06;
			anc.anc_add[9] = 0x80;

			inst->testAppState = TA_TXE_WAIT;
			inst->nextState = TA_TX_SYNC;
		}

	}
#endif

	if(sensor_flag == 1)
	{
		dwt_forcetrxoff();
		dwt_rxreset();

		if(sensor_mode == 1)
		{
			delay_ms(10);

			inst->testAppState = TA_TXE_WAIT;
			inst->nextState = TA_TX_SENSOR;
		}
		else
		{
			delay_ms(7);

			inst->testAppState = TA_TXE_WAIT;
			inst->nextState = TA_TX_SENSOR;
		}
		sensor_flag = 0;
	}

	if(Timer2_Counter >= 30)//50
	{
		dwt_forcetrxoff();
		dwt_rxreset();
		timer_flag = 0;
		Timer2_Counter = 0;

		result.data_len = (((result.tag_suc_cnt-1)*9)+10)+(result_cnt*10);
		result.result_total[((result.tag_suc_cnt-1)*9)+((result_cnt-one_anc_cnt)*10)+3] = one_anc_cnt+1;

		if(result.tag_cnt >= result.tag_list_len[0])
		{
			if(result.tag_suc_cnt >= result.tag_list_len[0])
			{
				//inst->testAppState = TA_TXE_WAIT;
				//inst->nextState = TA_TX_UP;
				inst->testAppState = TA_RXE_WAIT;
			}
			else
			{
				inst->testAppState = TA_TXE_WAIT;
				inst->nextState = TA_TX_RAN_MSG;
			}
		}
		else
		{
			inst->testAppState = TA_TXE_WAIT;
			inst->nextState = TA_TX_SYNC;
		}
	}
    switch (inst->testAppState)
    {
        case TA_INIT :
            // printf("TA_INIT") ;
            switch (inst->mode)
            {
                case TAG:
                {
                    int mode = 0;
                    tagaddress = 1;
                    dwt_enableframefilter(DWT_FF_DATA_EN | DWT_FF_ACK_EN); //allow data, ACK frames;
                    inst->frameFilteringEnabled = 1 ;

                    dwt_setpanid(inst->panID);

                    memcpy(inst->eui64, &tagaddress, ADDR_BYTE_SIZE_S);
                    dwt_seteui(inst->eui64);

#if (USING_64BIT_ADDR==0)
                    //the short address is assigned by the anchor
                    uint16 addr = inst->eui64[0] + (inst->eui64[1] << 8);
                    dwt_setaddress16(addr);
                    memcpy(&inst->msg.sourceAddr[0], &inst->eui64, ADDR_BYTE_SIZE_S);
#else
                    //set source address into the message structure
                    memcpy(&inst->msg.sourceAddr[0], inst->eui64, ADDR_BYTE_SIZE_L);
#endif

                    //change to next state - send a Poll message to 1st anchor in the list
                    //inst->mode = TAG_TDOA ;
                    //inst->testAppState = TA_TXBLINK_WAIT_SEND;
                    //inst->testAppState = TA_TXPOLL_WAIT_SEND;
                    inst->testAppState = TA_RXE_WAIT;
                    inst->instToSleep = 0 ;

                    inst->rangeNum = 0;
                    inst->pollNum = 0;
                    inst->tagSleepCorrection = 0;

                    mode = (DWT_PRESRV_SLEEP|DWT_CONFIG|DWT_TANDV);
					//mode = (DWT_LOADUCODE|DWT_PRESRV_SLEEP|DWT_CONFIG|DWT_TANDV);
					//

                    if(inst->configData.txPreambLength == DWT_PLEN_64)  //if using 64 length preamble then use the corresponding OPSet
                    {
                        mode |= DWT_LOADOPSET;
                    }
#if (DEEP_SLEEP == 1)
                    if (inst->sleepingEabled)
                        dwt_configuresleep(mode, DWT_WAKE_WK|DWT_WAKE_CS|DWT_SLP_EN); //configure the on wake parameters (upload the IC config settings)
#endif
                    inst->instancewaketime = portGetTickCnt();
                }
                break;
                case ANCHOR:
                {
                    dwt_enableframefilter(DWT_FF_NOTYPE_EN); //disable frame filtering
                    inst->frameFilteringEnabled = 0 ;
                    memcpy(inst->eui64, &anchoraddress, ADDR_BYTE_SIZE_S);
                    dwt_seteui(inst->eui64);
                    dwt_setpanid(inst->panID);
                    dwt_enableframefilter(DWT_FF_DATA_EN | DWT_FF_ACK_EN);
                    lps22hb_xl();

#if (USING_64BIT_ADDR==0)
                    {
                        uint16 addr = inst->eui64[0] + (inst->eui64[1] << 8);
                        dwt_setaddress16(addr);
                        //set source address into the message structure
                        memcpy(&inst->msg.sourceAddr[0], inst->eui64, ADDR_BYTE_SIZE_S);
                        //set source address into the message structure
                        memcpy(&inst->rng_initmsg.sourceAddr[0], inst->eui64, ADDR_BYTE_SIZE_S);
                    }
#else
                    //set source address into the message structure
                    memcpy(&inst->msg.sourceAddr[0], inst->eui64, ADDR_BYTE_SIZE_L);
                    //set source address into the message structure
                    memcpy(&inst->rng_initmsg.sourceAddr[0], inst->eui64, ADDR_BYTE_SIZE_L);
#endif
					inst->gatewayAnchor = FALSE;
					dwt_enableframefilter(DWT_FF_DATA_EN | DWT_FF_ACK_EN); //allow data, ack frames;
                    // First time anchor listens we don't do a delayed RX
                    dwt_setrxaftertxdelay(0);
                    //change to next state - wait to receive a message
                    //inst->testAppState = TA_RXE_WAIT ;
                    inst->testAppState = TA_RXE_WAIT ;

                    dwt_setrxtimeout(0);
                    //inst->canPrintInfo = 1;
                }
                break;
                case LISTENER:
                {
                    dwt_enableframefilter(DWT_FF_NOTYPE_EN); //disable frame filtering
                    inst->frameFilteringEnabled = 0 ;
                    // First time anchor listens we don't do a delayed RX
                    dwt_setrxaftertxdelay(0);
                    //change to next state - wait to receive a message
                    inst->testAppState = TA_RXE_WAIT ;

                    dwt_setrxtimeout(0);

                }
                break ; // end case TA_INIT
                default:
                break;
            }
            break; // end case TA_INIT

        case TA_SLEEP_DONE :
        {
            event_data_t* dw_event = instance_getevent(10); //clear the event from the queue
            // waiting for timout from application to wakup IC
            if (dw_event->type != DWT_SIG_RX_TIMEOUT)
            {
                // if no pause and no wake-up timeout continu waiting for the sleep to be done.
            	inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //wait here for sleep timeout
                break;
            }

            inst->done = INST_NOT_DONE_YET;
            inst->instToSleep = 0;
            inst->testAppState = inst->nextState;
            inst->nextState = 0; //clear
            inst->instanceTimerTimeSaved = inst->instanceTimerTime = portGetTickCnt(); //set timer base

#if (DEEP_SLEEP == 1)
            if (inst->sleepingEabled)
            {
                //wake up device from low power mode
                led_on(LED_PC9);

                port_wakeup_dw1000_fast();

                led_off(LED_PC9);

                //this is platform dependent - only program if DW EVK/EVB
                dwt_setleds(1);

                //MP bug - TX antenna delay needs reprogramming as it is not preserved after DEEP SLEEP
                dwt_settxantennadelay(inst->txAntennaDelay) ;
            }
#endif

            instancesetantennadelays(); //this will update the antenna delay if it has changed
            instancesettxpower(); //configure TX power if it has changed
        }
            break;

        case TA_TXE_WAIT : //either go to sleep or proceed to TX a message
        {
                inst->testAppState = inst->nextState;
                inst->nextState = 0; //clear
		}
		break ; // end case TA_TXE_WAIT


        case TA_TX_ROUTE :
            {
            	uint16 len = 0;
            	memset(inst->msg.messageData,0,1024);
            	len = (route.route_len[0])*2 + 40; // change point
            	init_dest(inst);

            	memcpy(&inst->msg.messageData[1],&data_buf[0],len);
            	len = len + 1;
        		test_data = inst->msg.destAddr[0] + inst->msg.destAddr[1]*256;
                setupmacframedata(inst, len, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_ROUTE);
                dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

				//set the delayed rx on time (the response message will be sent after this delay)
				dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
				dwt_setrxtimeout(0);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)

				//response is expected
				inst->wait4ack = DWT_RESPONSE_EXPECTED;

				dwt_writetxfctrl(inst->psduLength, 0, 1);

				dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

				inst->newrangepolltime = portGetTickCnt();

                inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
                inst->previousState = TA_TX_ROUTE ;
                inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)

            }
            break;


        case TA_TX_ROUTE_ACK :
            {
            	uint8 len = 0;
            	if(route_ack_flag == 1)
            	{
            		inst->msg.messageData[1] = 0x21;
            		inst->msg.messageData[2] = 0x77;
            		memcpy(&inst->msg.messageData[3],&shortadd,2);
            		memcpy(&inst->msg.messageData[5],&repot_cnt,1);
            		len = repot_cnt * 6;
            		memcpy(&inst->msg.messageData[6],&result.anc_data[0],len);
            		len = len + 6;
            	}
            	else
            	{
            		len = ((data_buf[4]*6) + 6);
            		memcpy(&inst->msg.messageData[1],&data_buf[0],len);
				}
            	init_dest(inst); // Set Anchor Address to poll next

                setupmacframedata(inst, len, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_ROUTE_ACK);
                dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

				//set the delayed rx on time (the response message will be sent after this delay)
				dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
				dwt_setrxtimeout(0);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)

				//response is expected
				inst->wait4ack = DWT_RESPONSE_EXPECTED;

				dwt_writetxfctrl(inst->psduLength, 0, 1);

				dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

				inst->newrangepolltime = portGetTickCnt();

                inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
                inst->previousState = TA_TX_ROUTE_ACK ;
                inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)

				memset(route.route_dsr,0,2);
				memset(route.route_len,0,2);
				memset(route.route_add,0,256);
				memset(result.one_anc_data,0,256);
				route_ack_flag = 0;
				repot_cnt = 0;
            }
            break;
        case TA_TX_RAN_MSG :
            {
            	uint8 len = 0;
            	memset(inst->msg.messageData,0,1024);
            	ranging_msg(inst);
            	if(result.tag_fail_cnt >= 1)
            	{
            		len = (result.tag_fail_cnt * 12);
                	memcpy(&inst->msg.messageData[1],&result.tag_fail_cnt,1);
                	memcpy(&inst->msg.messageData[2],&result.tag_fail_address[0],len);
                	memset(result.tag_fail_address,0,50);
            	}
            	else
            	{
                	len = (result.tag_list_len[0] * 2);
                	test_data = inst->msg.destAddr[0] + (inst->msg.destAddr[1]*256);

                	memcpy(&inst->msg.messageData[1],&result.tag_list_len[0],1);
                	memcpy(&inst->msg.messageData[2],&result.tag_add[0],len);
                	memcpy(&inst->msg.messageData[4],&tag_pos,8);
                	memcpy(&inst->msg.messageData[12],&tag_pos_time,4);

            	}

            	test_data = inst->msg.destAddr[0] + inst->msg.destAddr[1]*256;
                 setupmacframedata(inst, len+15, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_RAN_MSG);
                dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

				dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
				//dwt_setrxtimeout((uint16)inst->fwtoTime_sy);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)
				dwt_setrxtimeout(3000);
				//response is expected
				inst->wait4ack = DWT_RESPONSE_EXPECTED;

				dwt_writetxfctrl(inst->psduLength, 0, 1);

				dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

				inst->newrangepolltime = portGetTickCnt();

                inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
                inst->previousState = TA_TX_RAN_MSG ;
                inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)
            }
            break;

        case TA_TX_RAN_MSG_ACK :
            {
            	result_cnt = 0;
                setupmacframedata(inst, 1, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_RAN_MSG_ACK);
                dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

				//set the delayed rx on time (the response message will be sent after this delay)
				dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
				//dwt_setrxtimeout((uint16)inst->fwtoTime_sy);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)
				dwt_setrxtimeout(1);
				//response is expected
				inst->wait4ack = DWT_RESPONSE_EXPECTED;

				dwt_writetxfctrl(inst->psduLength, 0, 1);

				dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

				inst->newrangepolltime = portGetTickCnt();

                inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
                inst->previousState = TA_TX_RAN_MSG_ACK ;
                inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)
            }
            break;

        case TA_TX_SYNC :
            {
            	uint8 len = 0;

				timer_flag = 0;
				Timer2_Counter = 0;
        		inst->msg.destAddr[0] = 0xff;
        		inst->msg.destAddr[1] = 0xff;
        		memset(inst->msg.messageData,0,1024);
        		one_anc_cnt = 0;
        		test_data = result.result_total[0];
        		memcpy(&inst->msg.messageData[1],&anc.list_len,1);
        		len = (anc.list_len*2);
        		memcpy(&inst->msg.messageData[2],&anc.anc_add[0],len);
        		memcpy(&inst->msg.messageData[2+len],(uint8 *)&owr_poll_tx_time, 5);
        		memcpy(&inst->msg.messageData[7+len],(uint8 *)&owr_response_rx_time, 5);
        		memcpy(&inst->msg.messageData[12+len],(uint8 *)&anc_distance,1);

        		result.tag_cnt++;

                setupmacframedata(inst, (len + 13), FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_SYNC);
                dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

				//set the delayed rx on time (the response message will be sent after this delay)
				dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
				//dwt_setrxtimeout((uint16)inst->fwtoTime_sy);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)
				dwt_setrxtimeout(0);
				//response is expected
				inst->wait4ack = DWT_RESPONSE_EXPECTED;

				dwt_writetxfctrl(inst->psduLength, 0, 1);

				dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

				inst->newrangepolltime = portGetTickCnt();

                inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
                inst->previousState = TA_TX_SYNC ;
                inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)
/*
				memset(result.one_anc_data,0,256);
				memset(section,0,2);
				result.data_len = 0;
				result.tag_suc_cnt = 0;
				result.tag_fail_cnt = 0;
				result.tag_cnt = 0;
				memset(result.result_total,0,1024);
            	result_cnt = 0;
*/
                dest_flag = 0;

            }
            break;

        case TA_TX_ORAN :
            {
            	uint8 len = 0;

        		inst->msg.destAddr[0] = 0xff;
        		inst->msg.destAddr[1] = 0xff;

                setupmacframedata(inst, 1, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_ONE_RAN);
                dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

				//set the delayed rx on time (the response message will be sent after this delay)
				dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
				dwt_setrxtimeout(1);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)

				//response is expected
				inst->wait4ack = DWT_RESPONSE_EXPECTED;

				dwt_writetxfctrl(inst->psduLength, 0, 1);

				dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

				inst->newrangepolltime = portGetTickCnt();

                inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
                inst->previousState = TA_TX_ORAN ;
                inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)

            }
            break;

        case TA_TX_ORAN_RESULT :
            {
				uint64 result_time = 0;
            	delay_ms((section[1]));
				test_data = section[0];
				test_data = section[1];
				inst->msg.destAddr[0] = result.sync_anc[0];
				inst->msg.destAddr[1] = result.sync_anc[1];
				memset(inst->msg.messageData,0,1024);
				if(sync_rx_time > one_ran_rx_time)
				{
					result_time = (max_timestamp - sync_rx_time) + 1 + one_ran_rx_time;
				}
				else
				{
					result_time = one_ran_rx_time - sync_rx_time;
				}

				inst->msg.messageData[1] = 0x31;
				inst->msg.messageData[2] = result.tag_add[0];
				inst->msg.messageData[3] = result.tag_add[1];
        		memcpy(&inst->msg.messageData[4],&result_time,4);
        		memcpy(&inst->msg.messageData[8],&pressure_hpa,4);

	        	test_data = inst->msg.destAddr[0] + inst->msg.destAddr[1]*256;
                setupmacframedata(inst, 13, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_ONE_RAN_RESULT);
                dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame d ata

				//set the delayed rx on time (the response message will be sent after this delay)
				dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
				dwt_setrxtimeout(0);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)

				//response is expected
				inst->wait4ack = DWT_RESPONSE_EXPECTED;

				dwt_writetxfctrl(inst->psduLength, 0, 1);

				dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

				inst->newrangepolltime = portGetTickCnt();

                inst->testAppState = TA_TX_WAIT_CONF;                                               // wait confirmation
                inst->previousState = TA_TX_ORAN_RESULT;
                inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)
                memset(section,0,2);
                memset(result.tag_add,0,2);
            }
            break;

		case TA_TX_UP :
			{
				uint16 len = 0;
				uint8 no_search[3];
				timer_flag = 0;
				Timer2_Counter = 0;

				if(bs_flag == 0)
				{
					inst->msg.destAddr[0] = route.src_add[0];
					inst->msg.destAddr[1] = route.src_add[1];
				}
				else
				{
					inst->msg.destAddr[0] = 0x00;
					inst->msg.destAddr[1] = 0x70;
					bs_flag = 0;
				}
				test_data = result.result_total[0];
				memset(inst->msg.messageData,0,1024);
				//result.data_len = (((result.tag_suc_cnt-1)*15)+16)+(result_cnt*12);
				if(up_flag == 1)
				{
					memcpy(&inst->msg.messageData[1],&result.data_len,2);
					memcpy(&inst->msg.messageData[3],&result.result_total[0],result.data_len);
				}
				else{

					result.data_len = result.data_len + 6;
					memcpy(&inst->msg.messageData[1],&result.data_len,2);
					memcpy(&inst->msg.messageData[3],&result.result_total[0],3);
					memcpy(&inst->msg.messageData[6],&tag_baro,4);
					memcpy(&inst->msg.messageData[10],&ble_state,2);
					memcpy(&inst->msg.messageData[12],&result.result_total[3],(result.data_len-3));

				}
				len = result.data_len + 4;
				test_data = inst->msg.destAddr[0] + inst->msg.destAddr[1]*256;
				setupmacframedata(inst, len, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_UP);
				dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

				//set the delayed rx on time (the response message will be sent after this delay)
				dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
				dwt_setrxtimeout(0);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)

				//response is expected
				inst->wait4ack = DWT_RESPONSE_EXPECTED;

				dwt_writetxfctrl(inst->psduLength, 0, 1);

				dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

				inst->newrangepolltime = portGetTickCnt();

				inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
				inst->previousState = TA_TX_UP ;
				inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)

				memset(result.one_anc_data,0,256);
				memset(section,0,2);
				result.data_len = 0;
				result.tag_suc_cnt = 0;
				result.tag_fail_cnt = 0;
				result.tag_cnt = 0;
				memset(result.result_total,0,1024);
				memset(&anc_rec_rfid[0],0,5);
            	result_cnt = 0;
            	up_flag = 0;
			}
			break;

        case TA_TX_ERR :
            {

				if(bs_flag == 0)
				{
					inst->msg.destAddr[0] = route.src_add[0];
					inst->msg.destAddr[1] = route.src_add[1];
				}
				else
				{
					inst->msg.destAddr[0] = 0x00;
					inst->msg.destAddr[1] = 0x70;
					bs_flag = 0;
				}
				if(second_flag == 1)
				{
					inst->msg.messageData[1] = 0x40;
					memcpy(&inst->msg.messageData[2],&route.dsr_add[0],2);
 					memcpy(&inst->msg.messageData[4],&route.second_add[0],2);
 					dest_flag = 0;
					second_flag = 0;
				}
				else
				{
					memcpy(&inst->msg.messageData[1],&data_buf[0],5);
				}

                setupmacframedata(inst, 6, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_ANC_ERR);
                dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

				dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
				dwt_setrxtimeout(0);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)

				inst->wait4ack = DWT_RESPONSE_EXPECTED;

				dwt_writetxfctrl(inst->psduLength, 0, 1);

				dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

				inst->newrangepolltime = portGetTickCnt();

                inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
                inst->previousState = TA_TX_ERR ;
                inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)

            }
            break;
        case TA_TX_RAN_START :
            {
            	uint8 anc_len = 0;

            	memset(section,0,2);

        		inst->msg.destAddr[0] = result.tag_add[result.tag_cnt];
        		inst->msg.destAddr[1] = result.tag_add[result.tag_cnt+1];
        		test_data = inst->msg.destAddr[0] + inst->msg.destAddr[1]*256;

        		memcpy(&inst->msg.messageData[1],&tag_pos,8);
				memcpy(&inst->msg.messageData[9],&tag_pos_time,4);

        		setupmacframedata(inst, 13, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_RAN_START);
                dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

				//set the delayed rx on time (the response message will be sent after this delay)
				dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
				//dwt_setrxtimeout((uint16)inst->fwtoTime_sy);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)
				dwt_setrxtimeout(3000);
				//response is expected
				inst->wait4ack = DWT_RESPONSE_EXPECTED;

				dwt_writetxfctrl(inst->psduLength, 0, 1);

				dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

				inst->newrangepolltime = portGetTickCnt();

                inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
                inst->previousState = TA_TX_RAN_START ;
                inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)

            }
            break;
        case TA_TX_RAN_START_ACK :
            {
            	uint8 len = 0;
            	uint j = 0;
            	ran_tag_flag = 1;

            	if(rfid_result[0] == 0)
            	{
            		memcpy(&inst->msg.messageData[1],&rfid_result[0],1);
            		len = 2;
            	}
            	else
            	{
            		memcpy(&inst->msg.messageData[1],&rfid_result[0],rfid_result[0]*4+1);
            		len = rfid_result[0]*4+2;
				}

                setupmacframedata(inst, len, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_RAN_START_ACK);
                test_data = rfid_data[10];
                test_data = inst->msg.messageData[5];
                dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

				//set the delayed rx on time (the response message will be sent after this delay)
				dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
				dwt_setrxtimeout(0);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)

				//response is expected
				inst->wait4ack = DWT_RESPONSE_EXPECTED;

				dwt_writetxfctrl(inst->psduLength, 0, 1);

				dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

				inst->newrangepolltime = portGetTickCnt();

                inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
                inst->previousState = TA_TX_RAN_START_ACK ;
                inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)
                memset(rfid_result,0,100);
            }
            break;

        case TA_TX_SENSOR :
            {
            	uint8 len = 0;
            	uint32 pha = 0;

				inst->msg.destAddr[0] = sync_anc[0];
				inst->msg.destAddr[1] = sync_anc[1];
				memset(rfid_result,0,100);
        		memcpy(&inst->msg.messageData[1],&pha,4);
        		memcpy(&inst->msg.messageData[5],&rfid_result[0],1);
        		memcpy(&inst->msg.messageData[6],&rfid_result[1],(rfid_result[0]*4));


        		len = rfid_result[0]*4 + 6;
                setupmacframedata(inst, len, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_SENSOR);
                dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

				//set the delayed rx on time (the response message will be sent after this delay)
				dwt_setrxaftertxdelay(0);  //units are 1.0256us - wait for wait4respTIM before RX on (delay RX)
				dwt_setrxtimeout(0);  //units are us - wait for 7ms after RX on (but as using delayed RX this timeout should happen at response time + 7ms)

				//response is expected
				inst->wait4ack = DWT_RESPONSE_EXPECTED;

				dwt_writetxfctrl(inst->psduLength, 0, 1);

				dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

                inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
                inst->previousState = TA_TX_SENSOR ;
                inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set above)
    			memset(rfid_result,0,100);

            }
            break;

        case TA_TXPOLL_WAIT_SEND :
            {
            	//destaddress(inst);

//            	inst->msg.destAddr[0] = 0x02;
//            	inst->msg.destAddr[1] = 0x80;
            	inst->pollNum &= 0x1;

                int psduLength = 0;
                //NOTE the anchor address is set after receiving the ranging initialisation message
                //inst->goToSleep = 1; //go to Sleep after this poll
//
//              inst->msg.seqNum = inst->frameSN++;
//              inst->msg.messageData[FCODE] = RTLS_DEMO_MSG_TAG_POLL; //message function code (specifies if message is a poll, response or other...)
    			ranging_dest(inst);
    			test_data = inst->msg.destAddr[0] + (inst->msg.destAddr[1]*256);
    			anc_cnt++;
    		    inst->msg.messageData[POLL_RNUM] = inst->rangeNum;
    		    inst->msg.messageData[POLL_PNUM] = inst->pollNum;
    		    setupmacframedata(inst, TAG_POLL_MSG_LEN, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_TAG_POLL);
    		    dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

    			inst->pollNum++;
                //instanceconfigframeheader(inst);
#if (USING_64BIT_ADDR==1)

                psduLength = TAG_POLL_MSG_LEN + FRAME_CRTL_AND_ADDRESS_L + FRAME_CRC;
#else
                psduLength = TAG_POLL_MSG_LEN + FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC;
#endif
                //set the delayed rx on time (the response message will be sent after this delay)
                dwt_setrxaftertxdelay(0);
                dwt_setrxtimeout((uint16)inst->fwtoTime_sy*2);

                dwt_writetxdata(psduLength, (uint8 *)  &inst->msg, 0) ; // write the frame data

                //response is expected
                inst->wait4ack = DWT_RESPONSE_EXPECTED;

                dwt_writetxfctrl(psduLength, 0, 1);
                dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

                inst->newrangepolltime = portGetTickCnt();

                inst->testAppState = TA_TX_WAIT_CONF ;                                               // wait confirmation
                inst->previousState = TA_TXPOLL_WAIT_SEND ;
                inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set below)

            }
            break;

        case TA_TXRESPONSE_WAIT_SEND : //the frame is loaded and sent from the RX callback
            {
            	int psduLength = 0;
        		inst->msg.messageData[RES_R1] = inst->tagSleepCorrection & 0xFF;
        		inst->msg.messageData[RES_R2] = (inst->tagSleepCorrection >> 8) & 0xFF;

        		setupmacframedata(inst, ANCH_RESPONSE_MSG_LEN, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_ANCH_RESP);
//            	inst->msg.seqNum = inst->frameSN++;
//            	inst->msg.messageData[FCODE] = RTLS_DEMO_MSG_ANCH_RESP; //message function code (specifies if message is a poll, response or other...)
            	//instanceconfigframeheader(inst);
            	 //printf("TA_TXRESPONSE\n") ;
#if (USING_64BIT_ADDR==1)

                psduLength = TAG_POLL_MSG_LEN + FRAME_CRTL_AND_ADDRESS_L + FRAME_CRC;
#else
                psduLength = TAG_POLL_MSG_LEN + FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC;
#endif
                //set the delayed rx on time (the response message will be sent after this delay)
                dwt_setrxaftertxdelay(0);
                dwt_setrxtimeout(0);

                dwt_writetxdata(psduLength, (uint8 *)  &inst->msg, 0) ; // write the frame data

                //response is expected
                inst->wait4ack = DWT_RESPONSE_EXPECTED;

                dwt_writetxfctrl(psduLength, 0, 1);
                dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

                inst->testAppState = TA_TX_WAIT_CONF;                                               // wait confirmation
				inst->previousState = TA_TXRESPONSE_WAIT_SEND ;
				inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out (set below)
            }
            break;

        case TA_TXFINAL_WAIT_SEND :
            {
                int psduLength = 0;
                setupmacframedata(inst, 1, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_TAG_FINAL);
                dwt_writetxdata(inst->psduLength, (uint8 *)  &inst->msg, 0) ;	// write the frame data

                //turn on the receiver to receive the report... as it is coming after the final
                inst->wait4ack = DWT_RESPONSE_EXPECTED;
                // Embbed into Final message:40-bit respRxTime
                // Write Response RX time field of Final message
//                inst->msg.seqNum = inst->frameSN++;
//                memcpy(&(inst->msg.messageData[RRXT]), (uint8 *)&inst->anchorRespRxTime, 5);

//                inst->msg.messageData[FCODE] = RTLS_DEMO_MSG_TAG_FINAL; //message function code (specifies if message is a poll, response or other...)

                //instanceconfigframeheader(inst);
#if (USING_64BIT_ADDR==1)
                psduLength = TAG_FINAL_MSG_LEN + FRAME_CRTL_AND_ADDRESS_L + FRAME_CRC;
#else
                psduLength = TAG_FINAL_MSG_LEN + FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC;
#endif
                dwt_writetxfctrl(inst->psduLength, 0, 1);
                dwt_writetxdata(psduLength, (uint8 *)  &inst->msg, 0) ; // write the frame data
                dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

                dwt_setrxaftertxdelay(0);
               // dwt_setrxtimeout((uint16)inst->fwtoTime_sy*2);
                dwt_setrxtimeout((uint16)inst->fwtoTime_sy*10);

				inst->testAppState = TA_TX_WAIT_CONF;                                               // wait confirmation
				inst->previousState = TA_TXFINAL_WAIT_SEND;
				inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //will use RX FWTO to time out  (set below)
				//inst->responseTimeouts = 0; //reset response timeout count
				inst->timeofTx = portGetTickCnt();


            }
            break;

        case TA_TXREPORT_WAIT_SEND : //the frame is loaded and sent from the RX callback
            {

                int psduLength = 0;
                //NOTE the anchor address is set after receiving the ranging initialisation message

//                inst->msg.seqNum = inst->frameSN++;
//                inst->msg.messageData[FCODE] = RTLS_DEMO_MSG_ANCH_REPROT; //message function code (specifies if message is a poll, response or other...)

                memcpy(&(inst->msg.messageData[1]), (uint8 *)&poll_rx_time, 5);
                memcpy(&(inst->msg.messageData[6]), (uint8 *)&poll_rx_time, 5);
                memcpy(&(inst->msg.messageData[11]), (uint8 *)&poll_rx_time, 5);

                setupmacframedata(inst, 17, FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC, RTLS_DEMO_MSG_ANCH_TOFR);
                //instanceconfigframeheader(inst);
#if (USING_64BIT_ADDR==1)

                psduLength = TAG_POLL_MSG_LEN + FRAME_CRTL_AND_ADDRESS_L + FRAME_CRC;
#else
                psduLength = 16 + FRAME_CRTL_AND_ADDRESS_S + FRAME_CRC;
#endif
                //set the delayed rx on time (the response message will be sent after this delay)
                dwt_setrxaftertxdelay(0);

                dwt_writetxdata(psduLength, (uint8 *)  &inst->msg, 0) ; // write the frame data

                //response is expected
                inst->wait4ack = DWT_RESPONSE_EXPECTED;

                dwt_writetxfctrl(psduLength, 0, 1);
                dwt_starttx(DWT_START_TX_IMMEDIATE | inst->wait4ack);

                inst->testAppState = TA_TX_WAIT_CONF;                                               // wait confirmation
				inst->previousState = TA_TXREPORT_WAIT_SEND ;
				inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT_TO; //will use RX FWTO to time out (set below)

                inst->newRange = 1;
            }
            break;
        case TA_TX_WAIT_CONF :
           //printf("TA_TX_WAIT_CONF %d m%d states %08x %08x\n", inst->previousState, message, dwt_read32bitreg(0x19), dwt_read32bitreg(0x0f)) ;

                {
                	event_data_t* dw_event = instance_getevent(11); //get and clear this event

                //NOTE: Can get the ACK before the TX confirm event for the frame requesting the ACK
                //this happens because if polling the ISR the RX event will be processed 1st and then the TX event
                //thus the reception of the ACK will be processed before the TX confirmation of the frame that requested it.
                if(dw_event->type != DWT_SIG_TX_DONE) //wait for TX done confirmation
                {
                    if(dw_event->type == DWT_SIG_RX_TIMEOUT) //got RX timeout - i.e. did not get the response (e.g. ACK)
                    {
                        //printf("RX timeout in TA_TX_WAIT_CONF (%d)\n", inst->previousState);
                        //we need to wait for SIG_TX_DONE and then process the timeout and re-send the frame if needed
                        inst->gotTO = 1;
                    }
                    if(dw_event->type == SIG_RX_ACK)
                    {
                    	inst->wait4ack = 0 ; //clear the flag as the ACK has been received
                    	//printf("RX ACK in TA_TX_WAIT_CONF... wait for TX confirm before changing state (%d)\n", inst->previousState);
                    }

                    inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT;
                        break;

                }

                inst->done = INST_NOT_DONE_YET;
/*
                if(inst->previousState == TA_TXFINAL_WAIT_SEND)
                {
                    inst->testAppState = TA_TXE_WAIT ;
                    inst->nextState = TA_TXPOLL_WAIT_SEND ;
                    break;
                }*/

                if (inst->gotTO) //timeout
                {
                    //printf("got TO in TA_TX_WAIT_CONF\n");
                    inst_processrxtimeout(inst);
                    inst->gotTO = 0;
                    inst->wait4ack = 0 ; //clear this
                    break;
                }
                else
                {
                	if(inst->previousState == TA_TX_RAN_START)
                	{
                		owr_poll_tx_time = dw_event->timeStamp;

                	}
                	else if(inst->previousState == TA_TX_RAN_START_ACK)
                	{
                		owr_response_tx_time = dw_event->timeStamp;

                	}
                	if(inst->previousState == TA_TXPOLL_WAIT_SEND)
                	{
                		inst->txu.txTimeStamp = dw_event->timeStamp;
                		poll_tx_time = dw_event->timeStamp;
                	}
                	else if(inst->previousState == TA_TXRESPONSE_WAIT_SEND)
                	{
                		response_tx_time = dw_event->timeStamp;
                	}
                	else if(inst->previousState == TA_TXFINAL_WAIT_SEND)
                	{
                		final_tx_time = dw_event->timeStamp;
                	}
                	else if(inst->previousState == TA_TX_SYNC)
					{
						sync_tx_time = dw_event->timeStamp;
					}
                	else if(inst->previousState == TA_TX_ORAN)
					{
        		        if(Timer4_Counter >= 1000)
        				{
        		        	rfid_read();
        		        	Timer4_Counter = 0;
        				}
					}

               		inst->txu.txTimeStamp = dw_event->timeStamp;
                    inst->testAppState = TA_RXE_WAIT ;                      // After sending, tag expects response/report, anchor waits to receive a final/new poll
                    //fall into the next case (turn on the RX)
					message = 0;
                }

            }

            //break ; // end case TA_TX_WAIT_CONF


        case TA_RXE_WAIT :
        // printf("TA_RXE_WAIT") ;
        {
            if(inst->wait4ack == 0) //if this is set the RX will turn on automatically after TX
            {
                //turn RX on
                //instancerxon(inst, 0, 0) ;   // turn RX on, with/without delay
            	dwt_rxenable(0) ;  // turn RX on, without delay
            }
            else
            {
                inst->wait4ack = 0 ; //clear the flag, the next time we want to turn the RX on it might not be auto
            }

            if (inst->mode != LISTENER)
            {
            	if (inst->previousState != TA_TXREPORT_WAIT_SEND) //we are going to use anchor timeout and re-send the report
                //we are going to use anchor/tag timeout
            		inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT; //using RX FWTO
            }

            inst->testAppState = TA_RX_WAIT_DATA;   // let this state handle it

            // end case TA_RXE_WAIT, don't break, but fall through into the TA_RX_WAIT_DATA state to process it immediately.
            if(message == 0) break;
        }

        case TA_RX_WAIT_DATA :                                                                     // Wait RX data
           //printf("TA_RX_WAIT_DATA %d", message) ;

            switch (message)
            {

				case SIG_RX_ACK :
				{
					//event_data_t* dw_event = instance_getevent(14); //get and clear this event
					instance_getevent(14); //get and clear this event
					//else we did not expect this ACK turn the RX on again
					inst->testAppState = TA_RXE_WAIT ;              // wait for next frame
					inst->done = INST_NOT_DONE_YET;
				}
				break;

                //if we have received a DWT_SIG_RX_OKAY event - this means that the message is IEEE data type - need to check frame control to know which addressing mode is used
                case DWT_SIG_RX_OKAY :
                {
                    event_data_t* dw_event = instance_getevent(15); //get and clear this event
                    uint8  srcAddr[8] = {0,0,0,0,0,0,0,0};
					uint8  dstAddr[8] = {0,0,0,0,0,0,0,0};
                    int fcode = 0;
                    int fn_code = 0;
                    uint8 *messageData;
					dwt_forcetrxoff();
					inst->stoptimer = 0; //clear the flag, as we have received a message

                    // 16 or 64 bit addresses
                    switch(dw_event->msgu.frame[1]&0xCC)
                    {
                        case 0xCC: //
                            memcpy(&srcAddr[0], &(dw_event->msgu.rxmsg_ll.sourceAddr[0]), ADDR_BYTE_SIZE_L);
							memcpy(&dstAddr[0], &(dw_event->msgu.rxmsg_ll.destAddr[0]), ADDR_BYTE_SIZE_L);
                            fn_code = dw_event->msgu.rxmsg_ll.messageData[FCODE];
                            messageData = &dw_event->msgu.rxmsg_ll.messageData[0];
                            break;
                        case 0xC8: //
                            memcpy(&srcAddr[0], &(dw_event->msgu.rxmsg_sl.sourceAddr[0]), ADDR_BYTE_SIZE_L);
							memcpy(&dstAddr[0], &(dw_event->msgu.rxmsg_sl.destAddr[0]), ADDR_BYTE_SIZE_S);
                            fn_code = dw_event->msgu.rxmsg_sl.messageData[FCODE];
                            messageData = &dw_event->msgu.rxmsg_sl.messageData[0];
                            break;
                        case 0x8C: //
                            memcpy(&srcAddr[0], &(dw_event->msgu.rxmsg_ls.sourceAddr[0]), ADDR_BYTE_SIZE_S);
							memcpy(&dstAddr[0], &(dw_event->msgu.rxmsg_ls.destAddr[0]), ADDR_BYTE_SIZE_L);
                            fn_code = dw_event->msgu.rxmsg_ls.messageData[FCODE];
                            messageData = &dw_event->msgu.rxmsg_ls.messageData[0];
                            break;
                        case 0x88: //
                            memcpy(&srcAddr[0], &(dw_event->msgu.rxmsg_ss.sourceAddr[0]), ADDR_BYTE_SIZE_S);
							memcpy(&dstAddr[0], &(dw_event->msgu.rxmsg_ss.destAddr[0]), ADDR_BYTE_SIZE_S);
                            fn_code = dw_event->msgu.rxmsg_ss.messageData[FCODE];
                            messageData = &dw_event->msgu.rxmsg_ss.messageData[0];
                            break;
                    }

                    {
                    	fcode = fn_code;

                        switch(fcode)
                        {
							case RTLS_DEMO_MSG_ROUTE:
							{
								uint16 route_len, anc_len, len  = 0;

								memset(data_buf,0,1024);

								len = messageData[4]*2 + 40; // change point
								memcpy(&data_buf[0],&messageData[1],len);
								memcpy(&route.route_dsr[0],&data_buf[1],2);
								memcpy(&route.route_len[0],&data_buf[3],1);
								route_len = route.route_len[0];
								route_len = route_len*2;
								memcpy(&route.route_add[0],&data_buf[4],route_len);

								if(shortadd == (route.route_dsr[0] + route.route_dsr[1]*256))
								{
									route_ack_flag = 1;

									memcpy(&route.src_add[0],&data_buf[4+route_len],2);
									memcpy(&route.dsr_add[0],&data_buf[6+route_len],2);
									memcpy(&route.second_add[0],&data_buf[8+route_len],2);

									anc_distance = data_buf[10+route_len];

									memcpy(&anc.list_len,&data_buf[11+route_len],1);
									anc_len = anc.list_len;
									anc_len = anc_len*2;
									memcpy(&anc.anc_add[0],&data_buf[12+route_len],anc_len);

									inst->testAppState = TA_TXE_WAIT;
									inst->nextState = TA_TXPOLL_WAIT_SEND;
									//inst->nextState = TA_TX_ROUTE_ACK;

								}
								else
								{
									inst->testAppState = TA_TXE_WAIT;
									inst->nextState = TA_TX_ROUTE;
								}
							}
							break;


							case RTLS_DEMO_MSG_ROUTE_ACK:
							{
								uint8 len = 0;

								memset(data_buf,0,1024);
								len = ((messageData[5]*6) + 5);
								memcpy(&data_buf[0],&messageData[1],len);

								if(bs_anc == 1)
								{
									send_usbmessage(data_buf, len);
									usb_run();
									memset(data_buf,0,1024);
									inst->testAppState = TA_RXE_WAIT;
								}
								else
								{
									inst->testAppState = TA_TXE_WAIT;
									inst->nextState = TA_TX_ROUTE_ACK;
								}
							}
							break;

							case RTLS_DEMO_MSG_RAN_MSG:
							{
								uint8 len = 0;
								memset(tag_pos,0,6);
								memset(tag_pos_time,0,4);
								memset(data_buf,0,1024);

								memcpy(&result.tag_list_len[0],&messageData[1],1);

								len = result.tag_list_len[0];
								len = len*8;

								memcpy(&data_buf[0],&messageData[1],len+1);

								memcpy(&result.tag_add[0],&data_buf[1],len);
								memcpy(&tag_pos[0],&messageData[4],8);
								memcpy(&tag_pos_time[0],&messageData[12],4);
								route.src_add[0] = srcAddr[0];
								route.src_add[1] = srcAddr[1];

								inst->msg.destAddr[0] = srcAddr[0];
								inst->msg.destAddr[1] = srcAddr[1];
								test_data = srcAddr[0];
								memset(result.one_anc_data,0,256);
								memset(section,0,2);
								result.data_len = 0;
								result.tag_suc_cnt = 0;
								result.tag_fail_cnt = 0;
								result.tag_cnt = 0;
								memset(result.result_total,0,1024);
								result_cnt = 0;

								test_data = route.src_add[0] + route.src_add[1]*256;
								if(srcAddr[1] == 0x70) bs_flag = 1;
								if(anc.list_len == 0 || route.src_add[1] == 0 || route.dsr_add[1] == 0)
								{
									dwt_setrxtimeout(0);
									inst->testAppState = TA_RXE_WAIT;
								}
								else
								{
									inst->testAppState = TA_TXE_WAIT;
									inst->nextState = TA_TX_RAN_MSG_ACK;
								}
							}
							break;
							case RTLS_DEMO_MSG_RAN_MSG_ACK:
							{
								dest_flag = 0;
								second_flag = 0;
								dwt_setrxtimeout(0);
								inst->testAppState = TA_RXE_WAIT;
							}
							break;

							case RTLS_DEMO_MSG_SYNC:
							{
								uint8 len = 0;
								uint64 aRxT, aTxT ;
								uint64 anc_txpoll = 0;
								uint64 anc_rxrespone = 0;
								uint64 pollRespRTD  = 0;
								uint16 tag_flag = 0;
								uint8 route_distance = 0;
								if(shortadd <= 0x8000)
								{
									if(ran_tag_flag == 1)
									{
										sync_anc[0] = srcAddr[0];
										sync_anc[1] = srcAddr[1];

										len = messageData[1]*2;
										memcpy(&anc_txpoll,&messageData[2+len],5);
										memcpy(&anc_rxrespone,&messageData[7+len],5);
										route_distance = messageData[12+len];
										aRxT = (anc_rxrespone - anc_txpoll) & MASK_40BIT;
										aTxT = (owr_response_tx_time - owr_poll_rx_time) & MASK_40BIT;
										pollRespRTD = (aRxT - aTxT) & MASK_40BIT;

										inst->tof = ((pollRespRTD) & MASK_40BIT);

										reportTOF_s(inst);

										if((uint16)inst_idist >= route_distance)
										{
											dwt_setrxtimeout(0);
											inst->testAppState = TA_RXE_WAIT;
										}
										else
										{
											inst->testAppState = TA_TXE_WAIT;
											inst->nextState = TA_TX_ORAN;
										}
									}
									else
									{
										dwt_setrxtimeout(0);
										inst->testAppState = TA_RXE_WAIT;
									}
									/*

									sync_anc[0] = srcAddr[0];
									sync_anc[1] = srcAddr[1];

									inst->testAppState = TA_TXE_WAIT;
									inst->nextState = TA_TX_ORAN;
									*/
								}
								else
								{
									memcpy(&anc.list_len,&messageData[1],1);
									memcpy(&anc.owr_anc_add[0],&messageData[2],(anc.list_len*2));
									memset(section,0,2);

									for(int k = 0;k<anc.list_len;k++)
									{
										if(shortadd == (anc.owr_anc_add[k*2] + anc.owr_anc_add[(k*2)+1]*256))
										{
											result.sync_anc[0] = srcAddr[0];
											result.sync_anc[1] = srcAddr[1];

											section[0] = 1;
											section[1] = k;
											sync_rx_time = dw_event->timeStamp ;
										}
									}
										inst->testAppState = TA_RXE_WAIT;
								}
								memset(anc.owr_anc_add,0,2);

							}
							break;

							case RTLS_DEMO_MSG_ONE_RAN:
							{
								uint64 ranging_time = 0;
								uint8 len = 0;
								if(section[0] == 1)
								{
									//lps22hb_xl();

									/*
									baro_data_ss[0] = ((pressure_hpa >> 24) & 0xff);
									baro_data_ss[1] = ((pressure_hpa >> 16) & 0xff);
									baro_data_ss[2] = ((pressure_hpa >> 8) & 0xff);
									baro_data_ss[3] = (pressure_hpa & 0xff);
	*/
									result.tag_add[0] = srcAddr[0];
									result.tag_add[1] = srcAddr[1];
									one_ran_rx_time = dw_event->timeStamp;
									inst->testAppState = TA_TXE_WAIT;
									inst->nextState = TA_TX_ORAN_RESULT;
								}
								else
								{

									if(inst->previousState == TA_TX_SYNC)
									{
										//lps22hb_xl();
	/*
										baro_data_ss[0] = ((pressure_hpa >> 24) & 0xff);
										baro_data_ss[1] = ((pressure_hpa >> 16) & 0xff);
										baro_data_ss[2] = ((pressure_hpa >> 8) & 0xff);
										baro_data_ss[3] = (pressure_hpa & 0xff);
	*/
										pt_tag_rx_time = dw_event->timeStamp;
										memcpy(&result.result_total[((result.tag_suc_cnt)*9)+(result_cnt*6)+1],&result.tag_add[(result.tag_cnt-1)*2],2); //pt data

										memcpy(&result.result_total[((result.tag_suc_cnt)*9)+(result_cnt*6)+4],&shortadd,2);
										//memcpy(&result.result_total[((result.tag_suc_cnt)*9)+(result_cnt*12)+6],&sync_tx_time,5);
										//memcpy(&result.result_total[((result.tag_suc_cnt)*9)+(result_cnt*12)+11],&pt_tag_rx_time,5);
										if(sync_tx_time > pt_tag_rx_time)
										{
											ranging_time = (max_timestamp - sync_tx_time) + 1 + pt_tag_rx_time;
											memcpy(&result.result_total[((result.tag_suc_cnt)*9)+(result_cnt*6)+6],&ranging_time,4);
										}
										else
										{
											ranging_time = pt_tag_rx_time - sync_tx_time;
											memcpy(&result.result_total[((result.tag_suc_cnt)*9)+(result_cnt*6)+6],&ranging_time,4);
										}
										memcpy(&result.result_total[((result.tag_suc_cnt)*9)+(result_cnt*6)+10],&pressure_hpa,4);
										result.tag_suc_cnt++;
										//result.tag_suc_cnt = 1;
										result.result_total[0] = result.tag_suc_cnt;
										timer_flag = 1;
									}

									dwt_setrxtimeout(0);
										inst->testAppState = TA_RXE_WAIT;
								}
							}
							break;

							case RTLS_DEMO_MSG_ONE_RAN_RESULT:
							{
								uint64 anc_result_time = 0;
								uint64 anc_baro = 0;
								timer_flag = 0;
								Timer2_Counter = 0;
								//memset(data_buf,0,1024);

								memcpy(&anc_result_time,&messageData[4],4);
								memcpy(&anc_baro,&messageData[8],4);
								//memcpy(&sync_rx_time,&messageData[4],5);
								//memcpy(&one_ran_rx_time,&messageData[9],5);

								memcpy(&result.result_total[(((result.tag_suc_cnt-1)*9)+14)+(result_cnt*10)],&srcAddr,2); //anchor data
								memcpy(&result.result_total[(((result.tag_suc_cnt-1)*9)+14)+(result_cnt*10)+2],&anc_result_time,4);
								memcpy(&result.result_total[(((result.tag_suc_cnt-1)*9)+14)+(result_cnt*10)+6],&anc_baro,4);
								//memcpy(&result.result_total[(((result.tag_suc_cnt-1)*9)+10)+(result_cnt*6)+2],&sync_rx_time,5);
								//memcpy(&result.result_total[(((result.tag_suc_cnt-1)*9)+10)+(result_cnt*6)+7],&one_ran_rx_time,5);

								test_data = srcAddr[0] + srcAddr[1]*256;
								result_cnt++;
								one_anc_cnt++;
								if(one_anc_cnt >= anc.list_len)//if(anc.list_len <= (one_anc_cnt+1))
								{
									if(result.tag_cnt >= result.tag_list_len[0])
									{
										result.data_len = (((result.tag_suc_cnt-1)*9)+14)+(result_cnt*10);
										//memcpy(&result.result_total[((result.tag_suc_cnt-1)*15)+(result_cnt*12)+3],&one_anc_cnt,1);
										result.result_total[((result.tag_suc_cnt-1)*9)+((result_cnt-one_anc_cnt)*10)+3] = one_anc_cnt+1;
										/*
										inst->testAppState = TA_TXE_WAIT;
										inst->nextState = TA_TX_UP;
										*/
										inst->testAppState = TA_RXE_WAIT;

									}
								}
								else
								{
									timer_flag = 1;
									inst->testAppState = TA_RXE_WAIT;
								}
							}
							break;

							case RTLS_DEMO_MSG_SENSOR:
							{
								uint16 len = 0;

								memset(anc_rec_rfid,0,100);
								anc_rec_rfid[0] = 0;
								memcpy(&tag_baro,&messageData[1],4);
								memcpy(&ble_state,&messageData[5],2);

								if(bs_anc == 1)
								{


									result.data_len = result.data_len + 6;
									len = result.data_len;
									memcpy(&data_buf[1],&result.result_total[0],3);
									memcpy(&data_buf[4],&tag_baro,4);
									memcpy(&data_buf[8],&ble_state,2);
									memcpy(&data_buf[10],&result.result_total[3],(result.data_len-3));


									data_buf[0] = 0x31;
									len += 1;

									if(data_buf[2] == 2)
									{
										if(anc_rec_rfid[0] != 0)
										{

											test_data = srcAddr[0] + srcAddr[1]*256;

											test_data = anc_rec_rfid[0];
										}
									}
									if(data_buf[3] != 0x00)
									{
										send_usbmessage(data_buf,1);
										usb_run();
										inst->testAppState = TA_RXE_WAIT;
										memset(result.result_total,0,1024);
										memset(data_buf,0,1024);
									}
									else
									{
										send_usbmessage(data_buf,len);
										usb_run();
										inst->testAppState = TA_RXE_WAIT;
										memset(result.result_total,0,1024);
										memset(data_buf,0,1024);
									}
									memset(result.one_anc_data,0,256);
									memset(section,0,2);
									result.data_len = 0;
									result.tag_suc_cnt = 0;
									result.tag_fail_cnt = 0;
									result.tag_cnt = 0;
									memset(result.result_total,0,1024);
									memset(&ble_state[0],0,5);
									result_cnt = 0;
								}
								else
								{
									inst->testAppState = TA_TXE_WAIT;
									inst->nextState = TA_TX_UP;
								}

							}
							break;

							case RTLS_DEMO_MSG_UP:
							{
								uint16 len = 0;
								len = (messageData[1] + messageData[2]*256);

								if(bs_anc == 1)
								{
									memcpy(&result.result_total[0],&messageData[3],len);
									data_buf[0] = 0x31;
									memcpy(&data_buf[1],&result.result_total[0],len);
									len += 1;

									if(data_buf[3] != 0x00)
									{
										send_usbmessage(data_buf,1);
										usb_run();
										inst->testAppState = TA_RXE_WAIT;
										memset(result.result_total,0,1024);
										memset(data_buf,0,1024);
									}
									else
									{
										if(data_buf[8] == 0)
										{
											if(((data_buf[14]+data_buf[15]*256) <= 0x8000) || ((data_buf[14]+data_buf[15]*256) >= 0x8010))
											{
														inst->testAppState = TA_RXE_WAIT;
														memset(result.result_total,0,1024);
														memset(data_buf,0,1024);
											}
											else
											{
														send_usbmessage(data_buf,len);
														usb_run();
														inst->testAppState = TA_RXE_WAIT;
														memset(result.result_total,0,1024);
														memset(data_buf,0,1024);
											}
										}
										else {
											send_usbmessage(data_buf,len);
											usb_run();
											inst->testAppState = TA_RXE_WAIT;
											memset(result.result_total,0,1024);
											memset(data_buf,0,1024);
										}
									}
								}
								else
								{
									{
										result.data_len = len;

										memcpy(&result.result_total[0],&messageData[3],len);

										test_data = messageData[16];

										up_flag = 1;
										inst->testAppState = TA_TXE_WAIT;
										inst->nextState = TA_TX_UP;
									}
								}
							}
							break;

							case RTLS_DEMO_MSG_ANC_ERR:
							{
								uint16 len = 0;

								len = 5;
								memcpy(&data_buf[0],&messageData[1],len);
								if(shortadd == 0x7000)
								{
									send_usbmessage(data_buf,len);
									usb_run();
									inst->testAppState = TA_RXE_WAIT;
								}
								else
								{
									inst->testAppState = TA_TXE_WAIT;
									inst->nextState = TA_TX_ERR;
								}
							}
							break;


							case RTLS_DEMO_MSG_RAN_START:
							{
								dwt_setrxtimeout(0);

								inst->msg.destAddr[0] = srcAddr[0];
								inst->msg.destAddr[1] = srcAddr[1];
								memcpy(&result.tag_Position[0],&messageData[1],8);
								memcpy(&tag_pos_time[0],&messageData[9],4);
								//owr_poll_rx_time = dw_event->timeStamp;
	/*
								send_usbmessage(result.tag_Position, 6);
								usb_run();
	*/
								inst->testAppState = TA_TXE_WAIT;
								inst->nextState = TA_TX_RAN_START_ACK;
							}
							break;

							case RTLS_DEMO_MSG_RAN_START_ACK:
							{
								dwt_setrxtimeout(0);

								owr_response_rx_time = dw_event->timeStamp;
	/*
								memset(anc_rec_rfid,0,100);
								anc_rec_rfid[0] = messageData[1];

								if(anc_rec_rfid[0] == 0)
								{
									memset(&anc_rec_rfid[0],0,5);
								}
								else
								{
									memcpy(&anc_rec_rfid[1],&messageData[2],anc_rec_rfid[0]*4);
									memcpy(&tag_baro,&messageData[anc_rec_rfid[0]*4 + 2],4);

								}
	*/
								inst->testAppState = TA_TXE_WAIT;
								inst->nextState = TA_TX_SYNC;
							}

							break;

                            case RTLS_DEMO_MSG_TAG_POLL:
                            {
								int currentSlotTime = 0;
								int expectedSlotTime = 0;


								inst->newrangepolltime = dw_event->uTimeStamp;
								inst->rangeNum = messageData[POLL_RNUM];
								inst->pollNum = messageData[POLL_PNUM];

								inst->tagSleepCorrection = 0;

								poll_rx_time = dw_event->timeStamp ; //Poll's Rx time

								inst->testAppState = TA_TXRESPONSE_WAIT_SEND ; // send our response


								inst->msg.destAddr[0] = srcAddr[0];
								inst->msg.destAddr[1] = srcAddr[1];
//                              inst->anchorRespRxTime = dw_event->timeStamp ; //Response's Rx time
//                              poll_rx_time = dw_event->timeStamp ;
//								inst->msg.destAddr[0] = srcAddr[0];
//								inst->msg.destAddr[1] = srcAddr[1];
//
//								inst->canPrintInfo = 0;
//								inst->testAppState = TA_TXRESPONSE_WAIT_SEND;                                               // wait confirmation

                            }
                            break; //RTLS_DEMO_MSG_TAG_POLL

                            case RTLS_DEMO_MSG_ANCH_RESP:
                            {
                            	inst->tagSleepRnd = 0; // once we have initial response from Anchor #0 the slot correction acts and we don't need this anymore
                                inst->anchorRespRxTime = dw_event->timeStamp ; //Response's Rx time
//                              response_rx_time = dw_event->timeStamp ;
                                inst->testAppState = TA_TXFINAL_WAIT_SEND ; // send our response / the final

                                inst->canPrintInfo = 2;

                                //copy previously calculated ToF
                                //memcpy(&inst->tof, &(messageData[TOFR]), 5);

								inst->msg.destAddr[0] = srcAddr[0];
								inst->msg.destAddr[1] = srcAddr[1];
                            }
                            break; //RTLS_DEMO_MSG_ANCH_RESP

							case RTLS_DEMO_MSG_ANCH_TOFR:
							{
								uint64 tRxT, tTxT, aRxT, aTxT ;
								uint64 tagFinalTxTime  = 0;
								uint64 tagFinalRxTime  = 0;
								uint64 tagPollRxTime  = 0;
								uint64 anchorRespTxTime  = 0;
								uint64 pollRespRTD  = 0;
								uint64 respFinalRTD  = 0;
								uint64 test_time = 0;

								dwt_setrxtimeout(0);

								//printf("FinalRx Timestamp: %4.15e\n", convertdevicetimetosecu(dw_event.timeStamp));
								inst->delayedReplyTime = 0 ;

								// times measured at Tag extracted from the message buffer
								// extract 40bit times
								memcpy(&tagPollRxTime, &(messageData[1]), 5);
								memcpy(&anchorRespTxTime, &(messageData[6]), 5);
								memcpy(&tagFinalRxTime, &(messageData[11]), 5);

								// poll response round trip delay time is calculated as
								// (anchorRespRxTime - tagPollTxTime) - (anchorRespTxTime - tagPollRxTime)
								aRxT = (inst->anchorRespRxTime - poll_tx_time) & MASK_40BIT;
								//aTxT = (inst->txu.anchorRespTxTime - inst->tagPollRxTime) & MASK_40BIT;
								aTxT = (anchorRespTxTime - tagPollRxTime) & MASK_40BIT;
								pollRespRTD = (aRxT - aTxT) & MASK_40BIT;
								test_time = (tagPollRxTime - poll_tx_time)& MASK_40BIT;

								// response final round trip delay time is calculated as
								// (tagFinalRxTime - anchorRespTxTime) - (tagFinalTxTime - anchorRespRxTime)
								//tRxT = (tagFinalRxTime - inst->txu.anchorRespTxTime) & MASK_40BIT;
								tRxT = (tagFinalRxTime - anchorRespTxTime) & MASK_40BIT;
								tTxT = (final_tx_time - inst->anchorRespRxTime) & MASK_40BIT;
								respFinalRTD = (tRxT - tTxT) & MASK_40BIT;
								inst->tof = ((pollRespRTD + respFinalRTD) & MASK_40BIT);

								reportTOF(inst);

								result.anc_data[((repot_cnt)*6)] = srcAddr[0];
								result.anc_data[((repot_cnt)*6)+1] = srcAddr[1];
								result.anc_data[((repot_cnt)*6)+2] = tof_distance & 0xff; //distance
								result.anc_data[((repot_cnt)*6)+3] = (tof_distance & 0xff00) >> 8;
								result.anc_data[((repot_cnt)*6)+4] = (tof_distance & 0xff0000) >> 16;
								result.anc_data[((repot_cnt)*6)+5] = (tof_distance & 0xff000000) >> 24;


								repot_cnt++;

								if(anc_cnt >= anc.list_len)
								{
									if(bs_anc == 1)
									{
										uint8 len = 0;

										memset(data_buf,0,1024);

										data_buf[0] = 0x21;
										data_buf[1] = 0x77;
					            		memcpy(&data_buf[2],&shortadd,2);
					            		memcpy(&data_buf[4],&repot_cnt,1);
					            		len = repot_cnt * 6;
					            		memcpy(&data_buf[5],&result.anc_data[0],len);
					            		len = len + 6;

										send_usbmessage(data_buf, len);
										usb_run();
										inst->testAppState = TA_RXE_WAIT;
/*
										inst->testAppState = TA_RXE_WAIT;
										inst->nextState = TA_TX_ROUTE_ACK ; // send next poll
									*/
										anc_cnt = 0;
									}
									else
									{
										inst->testAppState = TA_TXE_WAIT;
										inst->nextState = TA_TX_ROUTE_ACK ; // send next poll
										anc_cnt = 0;
									}
								}
								else
								{
									inst->testAppState = TA_TXE_WAIT;
									inst->nextState = TA_TXPOLL_WAIT_SEND ; // send next poll
								}

							}
							break; //RTLS_DEMO_MSG_ANCH_TOFR

                            case RTLS_DEMO_MSG_TAG_FINAL:
                            {
                            	uint64 tagFinalRxTime  = 0;
								tagFinalRxTime = dw_event->timeStamp ;
								final_rx_time = tagFinalRxTime;
//                                final_rx_time = dw_event->timeStamp ;
//                                inst->delayedReplyTime = 0 ;

                                // times measured at Tag extracted from the message buffer
                                // extract 40bit times

								inst->msg.destAddr[0] = srcAddr[0];
								inst->msg.destAddr[1] = srcAddr[1];

//								if(reportTOF(inst) == 0)
//								{
//									inst->newRange = 1;
//								}

                                inst->testAppState = TA_TXREPORT_WAIT_SEND ;          // wait for next frame

                            }
                            break; //RTLS_DEMO_MSG_TAG_FINAL

//                            case RTLS_DEMO_MSG_ANCH_REPROT:
//                            {
//                            	uint64 tRxT, tTxT, aRxT, aTxT ;
//                            	uint64 pollRespRTD  = 0;
//                            	uint64 respFinalRTD  = 0;
//
//                            	memcpy(&poll_rx_time, &(messageData[1]), 5);
//                            	memcpy(&response_tx_time, &(messageData[6]), 5);
//                            	memcpy(&final_rx_time, &(messageData[11]), 5);
//
//                            	aRxT = (response_rx_time - poll_tx_time) & MASK_40BIT;
//                            	aTxT = (response_tx_time - poll_rx_time) & MASK_40BIT;
//                            	pollRespRTD = (aRxT - aTxT) & MASK_40BIT;
//
//                            	// response final round trip delay time is calculated as
//								// (tagfinal_rx_time - anchorRespTxTime) - (tagfinal_tx_time - anchorRespRxTime)
//								tRxT = (final_rx_time - response_tx_time) & MASK_40BIT;
//								tTxT = (final_tx_time - response_rx_time) & MASK_40BIT;
//								respFinalRTD = (tRxT - tTxT) & MASK_40BIT;
//
//								inst->tof = ((pollRespRTD + respFinalRTD) & MASK_40BIT);
//								if(reportTOF(inst) == 0)
//								{
//									inst->newRange = 1;
//								}
//
//									inst->testAppState = TA_TXE_WAIT ;
//									inst->nextState = TA_TXPOLL_WAIT_SEND ; // send next poll
//									pollcnt+=1;
//
//                            }
//
//                            break;

                            default:
                            {
                                inst->testAppState = TA_RXE_WAIT ;              // wait for next frame
                                dwt_setrxaftertxdelay(0);

                            }
                            break;
                        } //end switch (fcode)
						if(dw_event->msgu.frame[0] & 0x20)
						{
							//as we only pass the received frame with the ACK request bit set after the ACK has been sent
							instance_getevent(16); //get and clear the ACK sent event
						}


                    } //end else

                    if((inst->instToSleep == 0) && (inst->mode == LISTENER) /*|| (inst->mode == ANCHOR)*/)//update received data, and go back to receiving frames
                    {

                        inst->testAppState = TA_RXE_WAIT ;              // wait for next frame

                        dwt_setrxaftertxdelay(0);
                    }

                }
                break ; //end of DWT_SIG_RX_OKAY

                case DWT_SIG_RX_TIMEOUT :
                    instance_getevent(17); //get and clear this event
                    //printf("PD_DATA_TIMEOUT %d\n", inst->previousState) ;
                    inst_processrxtimeout(inst);
                    message = 0; //clear the message as we have processed the event
                break ;

                case DWT_SIG_TX_AA_DONE: //ignore this event - just process the rx frame that was received before the ACK response
                case 0:
                default :
                {
                    //if(DWT_SIG_TX_AA_DONE == message) printf("Got SIG_TX_AA_DONE in RX wait - ignore\n");
                    if(inst->done == INST_NOT_DONE_YET) inst->done = INST_DONE_WAIT_FOR_NEXT_EVENT;
                }
                break;

            }
            break ; // end case TA_RX_WAIT_DATA
            default:
                //printf("\nERROR - invalid state %d - what is going on??\n", inst->testAppState) ;
            break;
    } // end switch on testAppState

    return inst->done;
} // end testapprun()

// -------------------------------------------------------------------------------------------------------------------
#if NUM_INST != 1
#error These functions assume one instance only
#else


// -------------------------------------------------------------------------------------------------------------------
// function to initialise instance structures
//
// Returns 0 on success and -1 on error
int instance_init_s(int mode)
{
    instance_data_t* inst = instance_get_local_structure_ptr(0);

    inst->mode =  mode;                                // assume anchor,
    inst->testAppState = TA_INIT ;

    // if using auto CRC check (DWT_INT_RFCG and DWT_INT_RFCE) are used instead of DWT_INT_RDFR flag
    // other errors which need to be checked (as they disable receiver) are
    //dwt_setinterrupt(DWT_INT_TFRS | DWT_INT_RFCG | (DWT_INT_SFDT | DWT_INT_RFTO /*| DWT_INT_RXPTO*/), 1);
    dwt_setinterrupt(DWT_INT_TFRS | DWT_INT_RFCG | (DWT_INT_ARFE | DWT_INT_RFSL | DWT_INT_SFDT | DWT_INT_RPHE | DWT_INT_RFCE | DWT_INT_RFTO /*| DWT_INT_RXPTO*/), 1);

    //this is platform dependent - only program if DW EVK/EVB
    dwt_setleds(3) ; //configure the GPIOs which control the LEDs on EVBs

    dwt_setcallbacks(instance_txcallback, instance_rxgoodcallback, instance_rxtimeoutcallback, instance_rxerrorcallback);

    inst->anchorListIndex = 0 ;

    return 0 ;
}

extern uint8 dwnsSFDlen[];

// Pre-compute frame lengths, timeouts and delays needed in ranging process.
// /!\ This function assumes that there is no user payload in the frame.
void instance_init_timings(void)
{
    instance_data_t* inst = instance_get_local_structure_ptr(0);
    uint32 pre_len;
    int sfd_len;
    static const int data_len_bytes[FRAME_TYPE_NB] = {
        BLINK_FRAME_LEN_BYTES, RNG_INIT_FRAME_LEN_BYTES, POLL_FRAME_LEN_BYTES,
        RESP_FRAME_LEN_BYTES, FINAL_FRAME_LEN_BYTES};
    int i;
    // Margin used for timeouts computation.
    const int margin_sy = 10 + CUBEMX_DELAY; //For ST's HAL/Cube Mx need bigger margin/longer timout as "immediate" response comes later

    // All internal computations are done in tens of picoseconds before
    // conversion into microseconds in order to ensure that we keep the needed
    // precision while not having to use 64 bits variables.

    // Compute frame lengths.
    // First step is preamble plus SFD length.
    sfd_len = dwnsSFDlen[inst->configData.dataRate];
    switch (inst->configData.txPreambLength)
    {
    case DWT_PLEN_4096:
        pre_len = 4096;
        break;
    case DWT_PLEN_2048:
        pre_len = 2048;
        break;
    case DWT_PLEN_1536:
        pre_len = 1536;
        break;
    case DWT_PLEN_1024:
        pre_len = 1024;
        break;
    case DWT_PLEN_512:
        pre_len = 512;
        break;
    case DWT_PLEN_256:
        pre_len = 256;
        break;
    case DWT_PLEN_128:
        pre_len = 128;
        break;
    case DWT_PLEN_64:
    default:
        pre_len = 64;
        break;
    }
    pre_len += sfd_len;
    // Convert preamble length from symbols to time. Length of symbol is defined
    // in IEEE 802.15.4 standard.
    if (inst->configData.prf == DWT_PRF_16M)
        pre_len *= 99359;
    else
        pre_len *= 101763;
    // Second step is data length for all frame types.
    for (i = 0; i < FRAME_TYPE_NB; i++)
    {
        // Compute the number of symbols for the given length.
        inst->frameLengths_us[i] = data_len_bytes[i] * 8
                         + CEIL_DIV(data_len_bytes[i] * 8, 330) * 48;
        // Convert from symbols to time and add PHY header length.
        if(inst->configData.dataRate == DWT_BR_110K)
        {
            inst->frameLengths_us[i] *= 820513;
            inst->frameLengths_us[i] += 17230800;
        }
        else if (inst->configData.dataRate == DWT_BR_850K)
        {
            inst->frameLengths_us[i] *= 102564;
            inst->frameLengths_us[i] += 2153900;
        }
        else
        {
            inst->frameLengths_us[i] *= 12821;
            inst->frameLengths_us[i] += 2153900;
        }
        // Last step: add preamble length and convert to microseconds.
        inst->frameLengths_us[i] += pre_len;
        inst->frameLengths_us[i] = CEIL_DIV(inst->frameLengths_us[i], 100000);
    }
    // Final frame wait timeout time.
    inst->fwtoTime_sy = US_TO_SY_INT(inst->frameLengths_us[FINAL])
                        + RX_START_UP_SY + margin_sy;
    // Ranging init frame wait timeout time.
    inst->fwtoTimeB_sy = US_TO_SY_INT(inst->frameLengths_us[RNG_INIT])
                         + RX_START_UP_SY + margin_sy;
    // Delay between blink transmission and ranging init reception.
    inst->rnginitW4Rdelay_sy =
        US_TO_SY_INT((RNG_INIT_REPLY_DLY_MS * 1000) - inst->frameLengths_us[BLINK])
        - RX_START_UP_SY;
    // Delay between anchor's response transmission and final reception.
    inst->txToRxDelayAnc_sy = US_TO_SY_INT(TAG_TURN_AROUND_TIME_US) - RX_START_UP_SY - CUBEMX_DELAY;

    // No need to init txToRxDelayTag_sy here as it will be set upon reception
    // of ranging init message.

    // Delay between blink reception and ranging init message transmission.
    inst->rnginitReplyDelay = convertmicrosectodevicetimeu(RNG_INIT_REPLY_DLY_MS * 1000);
    // Delay between poll reception and response transmission. Computed from
    // poll reception timestamp to response transmission timestamp so you have
    // to add poll frame length to delay that must be respected between frames.
#if (IMMEDIATE_RESPONSE == 0)
    inst->responseReplyDelay = convertmicrosectodevicetimeu(ANC_TURN_AROUND_TIME_US + inst->frameLengths_us[POLL]);
#else
    inst->responseReplyDelay = 0 ;
#endif

    // Smart Power is automatically applied by DW chip for frame of which length
    // is < 1 ms. Let the application know if it will be used depending on the
    // length of the longest frame.
    if (inst->frameLengths_us[FINAL] <= 1000)
        inst->smartPowerEn = 1;
    else
        inst->smartPowerEn = 0;
}

uint64 instance_get_addr(void) //get own address
{
    instance_data_t* inst = instance_get_local_structure_ptr(0);
    uint64 x = (uint64) inst->eui64[0];
    x |= (uint64) inst->eui64[1] << 8;
    x |= (uint64) inst->eui64[2] << 16;
    x |= (uint64) inst->eui64[3] << 24;
    x |= (uint64) inst->eui64[4] << 32;
    x |= (uint64) inst->eui64[5] << 40;
    x |= (uint64) inst->eui64[6] << 48;
    x |= (uint64) inst->eui64[7] << 56;


    return (x);
}

uint64 instance_get_tagaddr(void) //get own address
{
    instance_data_t* inst = instance_get_local_structure_ptr(0);
    uint64 x = (uint64) inst->tagList[0][0];
    x |= (uint64) inst->tagList[0][1] << 8;
    x |= (uint64) inst->tagList[0][2] << 16;
    x |= (uint64) inst->tagList[0][3] << 24;
    x |= (uint64) inst->tagList[0][4] << 32;
    x |= (uint64) inst->tagList[0][5] << 40;
    x |= (uint64) inst->tagList[0][6] << 48;
    x |= (uint64) inst->tagList[0][7] << 56;


    return (x);
}

uint64 instance_get_anchaddr(void) //get anchor address (that sent the ToF)
{
    instance_data_t* inst = instance_get_local_structure_ptr(0);
    uint64 x = (uint64) inst->relpyAddress[0];
    x |= (uint64) inst->relpyAddress[1] << 8;
    x |= (uint64) inst->relpyAddress[2] << 16;
    x |= (uint64) inst->relpyAddress[3] << 24;
    x |= (uint64) inst->relpyAddress[4] << 32;
    x |= (uint64) inst->relpyAddress[5] << 40;
    x |= (uint64) inst->relpyAddress[6] << 48;
    x |= (uint64) inst->relpyAddress[7] << 56;
    return (x);
}

void instance_readaccumulatordata(void)
{
#if DECA_SUPPORT_SOUNDING==1
    instance_data_t* inst = instance_get_local_structure_ptr(0);
    uint16 len = 992 ; //default (16M prf)

    if (inst->configData.prf == DWT_PRF_64M)  // Figure out length to read
        len = 1016 ;

    inst->buff.accumLength = len ;                                       // remember Length, then read the accumulator data

    len = len*4+1 ;   // extra 1 as first byte is dummy due to internal memory access delay

    dwt_readaccdata((uint8*)&(inst->buff.accumData->dummy), len, 0);
#endif  // support_sounding
}

#endif


/* ==========================================================

Notes:

Previously code handled multiple instances in a single console application

Now have changed it to do a single instance only. With minimal code changes...(i.e. kept [instance] index but it is always 0.

Windows application should call instance_init() once and then in the "main loop" call instance_run().

*/
