/*
 ******************************************************************************
 * @file    acceler.h
 * @author  MEMS Software Solution Team
 * @date    02-September-2018
 * @brief   This file contains all the functions prototypes for the
 *          acceler.c driver.
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; COPYRIGHT(c) 2018 STMicroelectronics</center></h2>
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *   1. Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright notice,
 *      this list of conditions and the following disclaimer in the documentation
 *      and/or other materials provided with the distribution.
 *   3. Neither the name of STMicroelectronics nor the names of its contributors
 *      may be used to endorse or promote products derived from this software
 *      without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MMA8453Q_DRIVER__H
#define __MMA8453Q_DRIVER__H

#ifdef __cplusplus
  extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include <stdint.h>
#include <compiler.h>
/** @addtogroup MMA8453Q
 * @{
 */

#ifndef __AMEMS_SHARED__TYPES
#define __AMEMS_SHARED__TYPES

/** @defgroup ST_MEMS_common_types
  * @{
  */


typedef struct {
   uint8_t bit0       : 1;
   uint8_t bit1       : 1;
   uint8_t bit2       : 1;
   uint8_t bit3       : 1;
   uint8_t bit4       : 1;
   uint8_t bit5       : 1;
   uint8_t bit6       : 1;
   uint8_t bit7       : 1;
} a_bitwise_t;

#define ACCEL_PROPERTY_DISABLE                (0)
#define ACCEL_PROPERTY_ENABLE                 (1)

#endif /*__AMEMS_SHARED__TYPES*/

/**
  * @}
  */


/** @defgroup MMA8453Q_interface
  * @{
  */

typedef int32_t (*mma8453q_write_ptr)(void *, uint8_t, uint8_t*, uint16_t);
typedef int32_t (*mma8453q_read_ptr) (void *, uint8_t, uint8_t*, uint16_t);

typedef struct {
  /** Component mandatory fields **/
  mma8453q_write_ptr  write_reg;
  mma8453q_read_ptr   read_reg;
  /** Customizable optional pointer **/
  void *handle;
} mma8453q_ctx_t;

/**
  * @}
  */


/** @defgroup MMA8453Q_Infos
  * @{
  */
  /** I2C Device Address 8 bit format: if SA0=0 -> 0x39 if SA0=1 -> 0x3B **/
#define MMA8453Q_I2C_ADD_H   0x3B
#define MMA8453Q_I2C_ADD_L   0x39

/** Device Identification (Who am I) **/
#define MMA8453Q_ID            0x3A

/**
  * @}
  */

/**
  * @}
  */

#define MMA8453Q_STATUS           0x00
typedef struct {
  uint8_t xdr              : 1;
  uint8_t ydr              : 1;
  uint8_t zdr              : 1;
  uint8_t xyzdr            : 1;
  uint8_t x_overwrite      : 1;
  uint8_t y_overwrite      : 1;
  uint8_t z_overwrite      : 1;
  uint8_t xyz_overwrite    : 1;
} mma8453q_status_t;

#define MMA8453Q_OUT_X_MSB        0x01
#define MMA8453Q_OUT_X_LSB        0x02
#define MMA8453Q_OUT_Y_MSB        0x03
#define MMA8453Q_OUT_Y_LSB        0x04
#define MMA8453Q_OUT_Z_MSB        0x05
#define MMA8453Q_OUT_Z_LSB        0x06

#define MMA8453Q_SYSMOD           0x0B
typedef struct {
  uint8_t system_mode      : 2; /* SYSMOD0 + SYSMOD1 -> system_mode */
  uint8_t not_used_01      : 6;
} mma8453q_sysmod_t;

#define MMA8453Q_INT_SOURCE       0x0C
typedef struct {
  uint8_t dr_int_stat      : 1;
  uint8_t not_used_01      : 1;
  uint8_t ff_mt_int_stat   : 1;
  uint8_t pulse_int_stat   : 1;
  uint8_t lnd_prt_int_stat : 1;
  uint8_t trans_int_stat   : 1;
  uint8_t not_used_02      : 1;
  uint8_t auto_sw_int_stat : 1;
} mma8453q_int_source_t;

#define MMA8453Q_WHO_AM_I         0x0D

#define MMA8453Q_XYZ_DATA_CFG     0x0E
typedef struct {
  uint8_t fs               : 2; /* FS0 + FS1 -> fs */
  uint8_t not_used_01      : 6;
} mma8453_xyz_data_cfg_t;

#define MMA8453Q_HP_FILTER_CUTOFF 0x0F
typedef struct {
  uint8_t sel              : 2; /* SEL0 + SEL1 -> sel */
  uint8_t not_used_01      : 2;
  uint8_t pulse_lps_en     : 1;
  uint8_t pulse_hpf_byp    : 1;
  uint8_t not_used_02      : 2;
} mma8453_hp_filter_cutoff_t;

#define MMA8453Q_PL_STATUS        0x10
typedef struct {
  uint8_t bafro            : 1;
  uint8_t lapo             : 2; /* LAPO0 + LAPO1 -> lapo */
  uint8_t not_used_01      : 3;
  uint8_t lo               : 1;
  uint8_t newlp            : 1;
} mma8453q_pl_status_t;

#define MMA8453Q_PL_CFG           0x11
typedef struct {
  uint8_t not_used_01      : 6;
  uint8_t pl_en            : 1;
  uint8_t dbcntm           : 1;
} mma8453q_pl_cfg_t;

#define MMA8453Q_PL_COUNT         0x12

#define MMA8453Q_PL_BF_ZCOMP      0x13
typedef struct {
  uint8_t zlock            : 3; /* ZLOCK0 + ZLOCK1 + ZLOCK2 -> zlock */
  uint8_t not_used_01      : 3;
  uint8_t bkfr             : 2; /* BKFR0 + BKFR1 -> bkfr */
} mma8453q_pl_bf_zcomp_t;

#define MMA8453Q_PL_THS_REG       0x14
typedef struct {
  uint8_t hys              : 3; /* HYS0 + HYS1 + HYS2 -> hys */
  uint8_t pl_ths           : 5; /* PL_THS0 + ... + PL_THS4 -> pl_ths */
} mma8453q_pl_ths_reg_t;

#define MMA8453Q_FF_MT_CFG        0x15
typedef struct {
  uint8_t not_used_01      : 3;
  uint8_t xefe             : 1;
  uint8_t yefe             : 1;
  uint8_t zefe             : 1;
  uint8_t oae              : 1;
  uint8_t ele              : 1;
} mma8453q_ff_mt_cfg_t;

#define MMA8453Q_FF_MT_SRC        0x16
typedef struct {
  uint8_t xhp              : 1;
  uint8_t xhe              : 1;
  uint8_t yhp              : 1;
  uint8_t yhe              : 1;
  uint8_t zhp              : 1;
  uint8_t zhe              : 1;
  uint8_t not_used_01      : 1;
  uint8_t ea               : 1;
} mma8453q_ff_mt_src_t;

#define MMA8453Q_FF_MT_THS        0x17
typedef struct {
  uint8_t ths              : 7;  /* THS0 + ... + THS6 -> ths */
  uint8_t dbcntm           : 1;
} mma8453q_ff_mt_ths_t;

#define MMA8453Q_FF_MT_COUNT      0x18

#define MMA8453Q_TRANSIENT_CFG    0x1D
typedef struct {
  uint8_t hpf_byp          : 1;
  uint8_t xtefe            : 1;
  uint8_t ytefe            : 1;
  uint8_t ztefe            : 1;
  uint8_t ele              : 1;
  uint8_t not_used_01      : 3;
} mma8453q_transient_cfg_t;

#define MMA8453Q_TRANSIENT_SRC    0x1E
typedef struct {
  uint8_t x_trans_pol      : 1;
  uint8_t xtranse          : 1;
  uint8_t y_tans_pol       : 1;
  uint8_t ytranse          : 1;
  uint8_t z_trans_pol      : 1;
  uint8_t ztranse          : 1;
  uint8_t ea               : 1;
  uint8_t not_used_01      : 1;
} mma8453q_transient_src_t;

#define MMA8453Q_TRANSIENT_THS    0x1F
typedef struct {
  uint8_t ths              : 7;  /* THS0 + ... + THS6 -> ths */
  uint8_t dbcntm           : 1;
} mma8453q_transient_ths_t;

#define MMA8453Q_TRANSIENT_COUNT  0x20

#define MMA8453Q_PULSE_CFG        0x21
typedef struct {
  uint8_t xspefe           : 1;
  uint8_t xdpefe           : 1;
  uint8_t yspefe           : 1;
  uint8_t ydpefe           : 1;
  uint8_t zspefe           : 1;
  uint8_t zdpefe           : 1;
  uint8_t ele              : 1;
  uint8_t dpa              : 1;
} mma8453q_pulse_cfg_t;

#define MMA8453Q_PULSE_SRC        0x22
typedef struct {
  uint8_t polx             : 1;
  uint8_t poly             : 1;
  uint8_t polz             : 1;
  uint8_t dpe              : 1;
  uint8_t axx              : 1;
  uint8_t axy              : 1;
  uint8_t axz              : 1;
  uint8_t ea               : 1;
} mma8453q_pulse_src_t;

#define MMA8453Q_PULSE_THSX       0x23
#define MMA8453Q_PULSE_THSY       0x24
#define MMA8453Q_PULSE_THSZ       0x25
#define MMA8453Q_PULSE_TMLT       0x26
#define MMA8453Q_PULSE_LTCY       0x27
#define MMA8453Q_PULSE_WIND       0x28
#define MMA8453Q_ASLP_COUNT       0x29

#define MMA8453Q_CTRL_REG1        0x2A
typedef struct {
  uint8_t active           : 1;
  uint8_t f_read           : 1;
  uint8_t lnoise           : 1;
  uint8_t dr               : 3; /* DR0 + DR1 + DR2 -> dr */
  uint8_t aslp_rate        : 2; /* ASLP_RATE0 + ASLP_RATE1 -> aslp_rate */
} mma8453q_ctrl_reg1_t;

#define MMA8453Q_CTRL_REG2        0x2B
typedef struct {
  uint8_t mods             : 2; /* MODS0 + MODS1 -> mods */
  uint8_t slpe             : 1;
  uint8_t smods            : 2; /* SMODS0 + SMODS1 -> smods */
  uint8_t not_used_01      : 1;
  uint8_t rst              : 1;
  uint8_t st               : 1;
} mma8453q_ctrl_reg2_t;

#define MMA8453Q_CTRL_REG3        0x2C
typedef struct {
  uint8_t pp_od            : 1;
  uint8_t ipol             : 1;
  uint8_t not_used_01      : 1;
  uint8_t wake_ff_mt       : 1;
  uint8_t wake_pulse       : 1;
  uint8_t wake_lndprt      : 1;
  uint8_t wake_trans       : 1;
  uint8_t not_used_02      : 1;
} mma8453q_ctrl_reg3_t;

#define MMA8453Q_CTRL_REG4        0x2D
typedef struct {
  uint8_t int_en_drdy      : 1;
  uint8_t not_used_01      : 1;
  uint8_t int_en_ff_mt     : 1;
  uint8_t int_en_pulse     : 1;
  uint8_t int_en_lndprt    : 1;
  uint8_t int_en_trans     : 1;
  uint8_t not_used_02      : 1;
  uint8_t int_en_aslp      : 1;
} mma8453q_ctrl_reg4_t;

#define MMA8453Q_CTRL_REG5        0x2E
typedef struct {
  uint8_t int_cfg_drdy     : 1;
  uint8_t not_used_01      : 1;
  uint8_t int_cfg_ff_mt    : 1;
  uint8_t int_cfg_pulse    : 1;
  uint8_t int_cfg_lndprt   : 1;
  uint8_t int_cfg_trans    : 1;
  uint8_t not_used_02      : 1;
  uint8_t int_cfg_aslp     : 1;
} mma8453q_ctrl_reg5_t;

#define MMA8453Q_OFF_X            0x2F
#define MMA8453Q_OFF_Y            0x30
#define MMA8453Q_OFF_Z            0x31


typedef union{
  mma8453q_status_t            status;
  mma8453q_sysmod_t            sysmod;
  mma8453q_int_source_t        int_source;
  mma8453_xyz_data_cfg_t       xyz_data_cfg;
  mma8453_hp_filter_cutoff_t   hp_filter_cutoff;
  mma8453q_pl_status_t         pl_status;
  mma8453q_pl_cfg_t            pl_cfg;
  mma8453q_pl_bf_zcomp_t       pl_bf_zcomp;
  mma8453q_pl_ths_reg_t        pl_ths_reg;
  mma8453q_ff_mt_cfg_t         ff_mt_cfg;
  mma8453q_ff_mt_src_t         ff_mt_src;
  mma8453q_ff_mt_ths_t         ff_mt_ths;
  mma8453q_transient_cfg_t     transient_cfg;
  mma8453q_transient_src_t     transient_src;
  mma8453q_transient_ths_t     transient_ths;
  mma8453q_pulse_cfg_t         pulse_cfg;
  mma8453q_pulse_src_t         pulse_src;
  mma8453q_ctrl_reg1_t         ctrl_reg1;
  mma8453q_ctrl_reg2_t         ctrl_reg2;
  mma8453q_ctrl_reg3_t         ctrl_reg3;
  mma8453q_ctrl_reg4_t         ctrl_reg4;
  mma8453q_ctrl_reg5_t         ctrl_reg5;
  a_bitwise_t                    bitwise;
  uint8_t                      byte;
} mma8453q_reg_t;

int32_t mma8453q_read_reg(mma8453q_ctx_t *ctx, uint8_t reg, uint8_t* data,
                         uint16_t len);
int32_t mma8453q_write_reg(mma8453q_ctx_t *ctx, uint8_t reg, uint8_t* data,
                          uint16_t len);

int32_t mma8453q_Xaxis_new_dr_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Yaxis_new_dr_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Zaxis_new_dr_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_XYZaxis_new_dr_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_Xaxis_new_ow_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Yaxis_new_ow_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Zaxis_new_ow_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_XYZaxis_new_ow_get(mma8453q_ctx_t *ctx, uint8_t *val);


int32_t mma8453q_axis_get(mma8453q_ctx_t *ctx, uint32_t *buff);

int32_t mma8453q_x_msb_get(mma8453q_ctx_t *ctx, uint8_t *buff);
int32_t mma8453q_x_lsb_get(mma8453q_ctx_t *ctx, uint8_t *buff);
int32_t mma8453q_y_msb_get(mma8453q_ctx_t *ctx, uint8_t *buff);
int32_t mma8453q_y_lsb_get(mma8453q_ctx_t *ctx, uint8_t *buff);
int32_t mma8453q_z_msb_get(mma8453q_ctx_t *ctx, uint8_t *buff);
int32_t mma8453q_z_lsb_get(mma8453q_ctx_t *ctx, uint8_t *buff);

typedef enum {
  MMA8453Q_SYSMOD_STANDBY  = 0,
  MMA8453Q_SYSMOD_WAKE     = 1,
  MMA8453Q_SYSMOD_SLEEP    = 2,
} mma8453q_system_mode_t;
int32_t mma8453q_system_mode_get(mma8453q_ctx_t *ctx, mma8453q_system_mode_t *val);

int32_t mma8453q_data_ready_int_stat_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_freefall_motion_int_stat_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_pulse_int_stat_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_landscape_portrait_int_stat_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_transient_int_stat_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_auto_sleep_wake_int_stat_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_device_id_get(mma8453q_ctx_t *ctx, uint8_t *buff);

typedef enum {
  MMA8453Q_FULL_SCALE_RANGE_2  = 0,
  MMA8453Q_FULL_SCALE_RANGE_4  = 1,
  MMA8453Q_FULL_SCALE_RANGE_8  = 2,
} mma8453q_fs_range_t;
int32_t mma8453q_xyz_data_full_scale_set(mma8453q_ctx_t *ctx, mma8453q_fs_range_t val);
int32_t mma8453q_xyz_data_full_scale_get(mma8453q_ctx_t *ctx, mma8453q_fs_range_t *val);

typedef enum {
  MMA8453Q_HPF_CUT_OFF_FREQ_SEL_1  = 0,
  MMA8453Q_HPF_CUT_OFF_FREQ_SEL_2  = 1,
  MMA8453Q_HPF_CUT_OFF_FREQ_SEL_3  = 2,
  MMA8453Q_HPF_CUT_OFF_FREQ_SEL_4  = 3,
} mma8453q_hpf_co_freq_sel_t;
int32_t mma8453q_high_pass_filter_sel_set(mma8453q_ctx_t *ctx, mma8453q_hpf_co_freq_sel_t val);
int32_t mma8453q_high_pass_filter_sel_get(mma8453q_ctx_t *ctx, mma8453q_hpf_co_freq_sel_t *val);
int32_t mma8453q_low_pass_filter_enable_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_low_pass_filter_enable_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_high_pass_filter_bypass_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_high_pass_filter_bypass_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_pl_back_front_orient_get(mma8453q_ctx_t *ctx, uint8_t *val);
typedef enum {
  MMA8453Q_LANDSCAPE_LEFT   = 3,
  MMA8453Q_LANDSCAPE_RIGHT  = 2,
  MMA8453Q_PORTRAIT_DOWN    = 1,
  MMA8453Q_PORTRAIT_UP      = 0,
} mma8453q_lapo_t;
int32_t mma8453q_landscape_portrait_orient_get(mma8453q_ctx_t *ctx, mma8453q_lapo_t *val);
int32_t mma8453q_Z_tilt_angle_lockout_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_landscape_portrait_stat_change_flag_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_landscape_portrait_detection_enable_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_landscape_portrait_detection_enable_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_LAPO_Debounce_counter_mode_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_LAPO_Debounce_counter_mode_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_LAPO_Debounce_counter_value_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_LAPO_Debounce_counter_value_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_Z_lock_angle_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_back_front_trip_angle_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_transition_angle_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_portrait_landscape_fixed_threshold_angle_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t motion_detection_flag_set(mma8453q_ctx_t *ctx, uint32_t val, uint32_t threshold_set);

int32_t mma8453q_X_event_flag_enable_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_X_event_flag_enable_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Y_event_flag_enable_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_Y_event_flag_enable_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Z_event_flag_enable_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_Z_event_flag_enable_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_motion_freefall_detect_flag_sel_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_motion_freefall_detect_flag_sel_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_event_latch_enable_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_event_latch_enable_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_X_motion_polarity_flag_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_X_motion_flag_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Y_motion_polarity_flag_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Y_motion_flag_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Z_motion_polarity_flag_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Z_motion_flag_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_event_active_flag_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_freefall_motion_threshold_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_freefall_motion_threshold_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_FF_MT_Debounce_counter_mode_sel_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_FF_MT_Debounce_counter_mode_sel_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_FF_MT_debounce_count_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_FF_MT_debounce_count_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_transient_bypass_high_pass_filter_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_transient_bypass_high_pass_filter_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_transient_XTEFE_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_transient_XTEFE_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_transient_YTEFE_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_transient_YTEFE_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_transient_ZTEFE_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_transient_ZTEFE_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_transient_ELE_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_transient_ELE_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_X_transient_polarity_interrupt_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_X_transient_event_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Y_transient_polarity_interrupt_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Y_transient_event_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Z_transient_polarity_interrupt_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Z_transient_event_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_event_active_flag_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_transient_threshold_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_transient_threshold_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_TRANS_Debounce_counter_mode_sel_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_TRANS_Debounce_counter_mode_sel_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_transient_count_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_transient_count_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_Spulse_Xaxis_event_flag_enable_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_Spulse_Xaxis_event_flag_enable_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Dpulse_Xaxis_event_flag_enable_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_Dpulse_Xaxis_event_flag_enable_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Spulse_Yaxis_event_flag_enable_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_Spulse_Yaxis_event_flag_enable_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Dpulse_Yaxis_event_flag_enable_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_Dpulse_Yaxis_event_flag_enable_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Spulse_Zaxis_event_flag_enable_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_Spulse_Zaxis_event_flag_enable_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Dpulse_Zaxis_event_flag_enable_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_Dpulse_Zaxis_event_flag_enable_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Pulse_event_flag_PULSE_SRC_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_Pulse_event_flag_PULSE_SRC_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Double_pulse_abort_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_Double_pulse_abort_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_pulse_polarity_Xaxis_event_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_pulse_polarity_Xaxis_event_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_pulse_polarity_Yaxis_event_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_pulse_polarity_Yaxis_event_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_pulse_polarity_Zaxis_event_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_pulse_polarity_Zaxis_event_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Dpulse_first_event_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_Dpulse_first_event_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_pulse_Xaxis_event_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_pulse_Xaxis_event_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_pulse_Yaxis_event_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_pulse_Yaxis_event_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_pulse_Zaxis_event_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_pulse_Zaxis_event_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_pulse_event_active_flag_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_pulse_event_active_flag_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_pulse_ths_x_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_pulse_ths_x_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_pulse_ths_y_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_pulse_ths_y_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_pulse_ths_z_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_pulse_ths_z_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_pulse_time_limit_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_pulse_time_limit_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_latency_time_limit_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_latency_time_limit_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_auto_wake_sleep_duration_value_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_auto_wake_sleep_duration_value_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_full_scale_sel_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_full_scale_sel_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_fast_read_mode_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_fast_read_mode_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_reduced_noise_reduced_max_range_mode_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_reduced_noise_reduced_max_range_mode_get(mma8453q_ctx_t *ctx, uint8_t *val);
typedef enum {
  MMA8453Q_DATA_RATE_800   = 0,
  MMA8453Q_DATA_RATE_400   = 1,
  MMA8453Q_DATA_RATE_200   = 2,
  MMA8453Q_DATA_RATE_100   = 3,
  MMA8453Q_DATA_RATE_50    = 4,
  MMA8453Q_DATA_RATE_12_5  = 5,
  MMA8453Q_DATA_RATE_6_25  = 6,
  MMA8453Q_DATA_RATE_1_56  = 7,
} mma8453q_data_rate_t;
int32_t mma8453q_data_rate_sel_set(mma8453q_ctx_t *ctx, mma8453q_data_rate_t val);
int32_t mma8453q_data_rate_sel_get(mma8453q_ctx_t *ctx, mma8453q_data_rate_t *val);
typedef enum {
  MMA8453Q_SAMPLE_FREQ_50     = 0,
  MMA8453Q_SAMPLE_FREQ_12_5   = 1,
  MMA8453Q_SAMPLE_FREQ_6_25   = 2,
  MMA8453Q_SAMPLE_FREQ_1_56   = 3,
} mma8453q_sample_freq_t;
int32_t mma8453q_auto_wake_sample_freq_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_auto_wake_sample_freq_get(mma8453q_ctx_t *ctx, uint8_t *val);

typedef enum {
  MMA8453Q_NORMAL                = 0,
  MMA8453Q_LOW_NOISE_LOW_POWER   = 1,
  MMA8453Q_HIGH_RESOLUTION       = 2,
  MMA8453Q_LOW_POWER             = 3,
} mma8453q_mods_t;
int32_t mma8453q_active_mode_power_sel_set(mma8453q_ctx_t *ctx, mma8453q_mods_t val);
int32_t mma8453q_active_mode_power_sel_get(mma8453q_ctx_t *ctx, mma8453q_mods_t *val);
int32_t mma8453q_auto_sleep_enable_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_auto_sleep_enable_get(mma8453q_ctx_t *ctx, uint8_t *val);
typedef enum {
  MMA8453Q_S_NORMAL              = 0,
  MMA8453Q_S_LOW_NOISE_LOW_POWER = 1,
  MMA8453Q_S_HIGH_RESOLUTION     = 2,
  MMA8453Q_S_LOW_POWER           = 3,
} mma8453q_smods_t;
int32_t mma8453q_sleep_mode_power_sel_set(mma8453q_ctx_t *ctx, mma8453q_smods_t val);
int32_t mma8453q_sleep_mode_power_sel_get(mma8453q_ctx_t *ctx, mma8453q_smods_t *val);
int32_t mma8453q_software_reset_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_software_reset_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_self_test_enable_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_self_test_enable_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_PP_OD_sel_int_pad_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_PP_OD_sel_int_pad_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_int_polarity_active_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_int_polarity_active_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_FF_MT_wake_up_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_FF_MT_wake_up_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_pulse_function_wake_up_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_pulse_function_wake_up_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_orientation_wake_up_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_orientation_wake_up_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_transient_wake_up_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_transient_wake_up_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_data_ready_int_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_data_ready_int_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_FF_MT_int_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_FF_MT_int_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_pulse_int_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_pulse_int_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_orientation_int_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_orientation_int_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_transient_int_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_transient_int_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_auto_sleep_wake_int_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_auto_sleep_wake_int_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_data_ready_int_configuration_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_data_ready_int_configuration_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_FF_MT_int_configuration_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_FF_MT_int_configuration_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_pulse_int_configuration_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_pulse_int_configuration_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_orientation_int_configuration_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_orientation_int_configuration_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_transient_int_configuration_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_transient_int_configuration_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_auto_sleep_wake_int_configuration_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_auto_sleep_wake_int_configuration_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_Xaxis_off_set_value_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_Xaxis_off_set_value_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Yaxis_off_set_value_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_Yaxis_off_set_value_get(mma8453q_ctx_t *ctx, uint8_t *val);
int32_t mma8453q_Zaxis_off_set_value_set(mma8453q_ctx_t *ctx, uint8_t val);
int32_t mma8453q_Zaxis_off_set_value_get(mma8453q_ctx_t *ctx, uint8_t *val);

int32_t mma8453q_init(mma8453q_ctx_t* ctx);

int wirtetoaccel(uint8_t *pData, uint16_t Size, uint8_t DevAddress);
int readtoaccel(uint8_t *pData, uint16_t Size, uint8_t DevAddress);
/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /*__MMA8453Q_DRAIVER__H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
