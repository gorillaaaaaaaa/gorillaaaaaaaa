/*! ----------------------------------------------------------------------------
 *  @file    dw_main.c
 *  @brief   main loop for the DecaRanging application
 *
 * @attention
 *
 * Copyright 2016 (c) DecaWave Ltd, Dublin, Ireland.
 *
 * All rights reserved.
 *
 * @author DecaWave
 */
/* Includes */
#include "compiler.h"
#include "port.h"

#include "instance.h"

#include "deca_types.h"
#include "deca_spi.h"
#include "deca_regs.h"
#include "stdio.h"
#include "LPS22HB.h"

extern int32_t lps22hb_xl(void);
extern void usb_run(void);
extern int usb_init(void);
extern void usb_printconfig(int, uint8*, int);
extern void send_usbmessage(uint8*, int);

//extern ADC_HandleTypeDef hadc1;
GPIO_InitTypeDef GPIO_InitStruct;

extern lps22hb_ctx_t dev_ctx;
extern lps22hb_ctx_t baro_ctx;

static uint32 axis[3];
uint8 baro_data_ss[4];

static uint8_t baro_rst;
							// "1234567890123456" - 16 bytes long LCD


							// "1234567890123456" - 16 bytes long LCD
#define SOFTWARE_VER_STRING    "Version 3.11 MX " //

#define SWS1_TXSPECT_MODE	0x80  //Continuous TX spectrum mode
#define SWS1_ANC_MODE 		0x08  //anchor mode
#define SWS1_SHF_MODE		0x10  //short frame mode (6.81M) (switch S1-5)
#define SWS1_64M_MODE		0x20  //64M PRF mode (switch S1-6)
#define SWS1_CH5_MODE		0x40  //channel 5 mode (switch S1-7)

int dr_mode = 0;
int instance_mode = ANCHOR;


extern uint8 timer_flag;

uint8 s1switch = 0;
int chan, tagaddr, ancaddr, prf;

#define LCD_BUFF_LEN (100)
uint8 dataseq[LCD_BUFF_LEN];
uint8 dataseq1[LCD_BUFF_LEN];

static double battery_power, mcu_power, r1_value, r2_value, setting_power;
static double check_battery=0, percent=0, pre_percent=200;

uint16 anchoraddress = 0;
uint16 tagaddress = 0;

static float pressure_hPa;
extern axis1bit32_t data_raw_pressure;
static axis1bit32_t data_raw_temperature;



int ranging = 0;

//Configuration for DecaRanging Modes (8 default use cases selectable by the switch S1 on EVK)
instanceConfig_t chConfig[8] ={
                    //mode 1 - S1: 7 off, 6 off, 5 off
                    {
                        2,              // channel
						3,              // preambleCode
                        DWT_PRF_16M,    // prf
                        DWT_BR_110K,    // datarate
                        DWT_PLEN_1024,  // preambleLength
                        DWT_PAC32,      // pacSize
                        1,       // non-standard SFD
                        (1025 + 64 - 32) //SFD timeout
                    },
                    //mode 2
                    {
                        2,              // channel
                        3,             // preambleCode
                        DWT_PRF_16M,    // prf
                        DWT_BR_6M8,    // datarate
                        DWT_PLEN_128,   // preambleLength
                        DWT_PAC8,       // pacSize
                        0,       // non-standard SFD
                        (129 + 8 - 8) //SFD timeout
                    },
                    //mode 3
                    {
                        2,              // channel
                        9,             // preambleCode
                        DWT_PRF_64M,    // prf
                        DWT_BR_110K,    // datarate
                        DWT_PLEN_1024,  // preambleLength
                        DWT_PAC32,      // pacSize
                        1,       // non-standard SFD
                        (1025 + 64 - 32) //SFD timeout
                    },
                    //mode 4
                    {
                        2,              // channel
                        9,             // preambleCode
                        DWT_PRF_64M,    // prf
                        DWT_BR_6M8,    // datarate
                        DWT_PLEN_128,   // preambleLength
                        DWT_PAC8,       // pacSize
                        0,       // non-standard SFD
                        (129 + 8 - 8) //SFD timeout
                    },
                    //mode 5
                    {
                        5,              // channel
                        3,             // preambleCode
                        DWT_PRF_16M,    // prf
                        DWT_BR_110K,    // datarate
                        DWT_PLEN_1024,  // preambleLength
                        DWT_PAC32,      // pacSize
                        1,       // non-standard SFD
                        (1025 + 64 - 32) //SFD timeout
                    },
                    //mode 6
                    {
                        5,              // channel
                        3,             // preambleCode
                        DWT_PRF_16M,    // prf
                        DWT_BR_6M8,    // datarate
                        DWT_PLEN_128,   // preambleLength
                        DWT_PAC8,       // pacSize
                        0,       // non-standard SFD
                        (129 + 8 - 8) //SFD timeout
                    },
                    //mode 7
                    {
                        5,              // channel
                        9,             // preambleCode
                        DWT_PRF_64M,    // prf
                        DWT_BR_110K,    // datarate
                        DWT_PLEN_1024,  // preambleLength
                        DWT_PAC32,      // pacSize
                        1,       // non-standard SFD
                        (1025 + 64 - 32) //SFD timeout
                    },
                    //mode 8
                    {
                        5,              // channel
                        9,             // preambleCode
                        DWT_PRF_64M,    // prf
                        DWT_BR_6M8,    // datarate
                        DWT_PLEN_128,   // preambleLength
                        DWT_PAC8,       // pacSize
                        0,       // non-standard SFD
                        (129 + 8 - 8) //SFD timeout
                    }
};


uint32 inittestapplication(uint8 s1switch);

void addressconfigure(uint8 s1switch)
{
    instanceAddressConfig_t ipc ;

    // instance_anchaddr = (((s1switch & SWS1_A1A_MODE) << 2) + (s1switch & SWS1_A2A_MODE) + ((s1switch & SWS1_A3A_MODE) >> 2)) >> 4;
    //if(instance_anchaddr > 3)
    //{
    //	ipc.anchorAddress = GATEWAY_ANCHOR_ADDR | 0x4 ; //listener
    //}
    //else
    //{
    //	ipc.anchorAddress = GATEWAY_ANCHOR_ADDR | instance_anchaddr;
    //}

    ipc.anchorAddress = 0x8000;
    ipc.tagAddress = 0x0000;
    anchoraddress = 0x8000;
    //instancesetaddresses(&ipc);
}

int decarangingmode(uint8 s1switch)
{
    int mode = 0;

    if(s1switch & SWS1_SHF_MODE)
    {
        mode = 1;
    }

    if(s1switch & SWS1_64M_MODE)
    {
        mode = mode + 2;
    }
    if(s1switch & SWS1_CH5_MODE)
    {
        mode = mode + 4;
    }

    return mode;
}

uint32 inittestapplication(uint8 s1switch)
{
    uint32 devID ;
    int result;

    port_set_dw1000_slowrate();  //max SPI before PLLs configured is ~4M

    //this is called here to wake up the device (i.e. if it was in sleep mode before the restart)
    devID = instancereaddeviceid() ;
    if(DWT_DEVICE_ID != devID) //if the read of device ID fails, the DW1000 could be asleep
    {
        port_wakeup_dw1000();

        devID = instancereaddeviceid() ;
        // SPI not working or Unsupported Device ID
        if(DWT_DEVICE_ID != devID)
            return(-1) ;
        //clear the sleep bit - so that after the hard reset below the DW does not go into sleep
        dwt_softreset();
    }

    //reset the DW1000 by driving the RSTn line low
    reset_DW1000();

    result = instance_init() ;
    if (0 > result) return(-1) ; // Some failure has occurred

    //port_set_dw1000_fastrate();
    devID = instancereaddeviceid() ;

    if (DWT_DEVICE_ID != devID)   // Means it is NOT DW1000 device
    {
        // SPI not working or Unsupported Device ID
        return(-1) ;
    }

    if(s1switch & SWS1_ANC_MODE)
    {
        instance_mode = ANCHOR;

        led_on(LED_PC0);

    }
    else
    {
        instance_mode = TAG;
        led_on(LED_PC1);
    }

    instance_mode = TAG;
    instance_init_s(instance_mode);
    dr_mode = decarangingmode(s1switch);
    dr_mode = 0;
    chan = chConfig[dr_mode].channelNumber ;
    prf = (chConfig[dr_mode].pulseRepFreq == DWT_PRF_16M)? 16 : 64 ;

    instance_config(&chConfig[dr_mode]) ;                  // Set operating channel etc

    instancesettagsleepdelay(POLL_SLEEP_DELAY, BLINK_SLEEP_DELAY); //set the Tag sleep time

    instance_init_timings();

    return devID;
}

void initLCD(void)
{
    uint8 initseq[9] = { 0x39, 0x14, 0x55, 0x6D, 0x78, 0x38 /*0x3C*/, 0x0C, 0x01, 0x06 };
    uint8 command = 0x0;
    int j = 100000;

    //writetoLCD( 9, 0,  initseq); //init seq
    while(j--);

    command = 0x2 ;  //return cursor home
   // writetoLCD( 1, 0,  &command);
    command = 0x1 ;  //clear screen
    //writetoLCD( 1, 0,  &command);
}

void setLCDline1(uint8 s1switch)
{
	uint8 command = 0x2 ;  //return cursor home
    //writetoLCD( 1, 0,  &command);

	sprintf((char*)&dataseq[0], "DecaRanging  %02x", s1switch);
	//writetoLCD( 40, 1, dataseq); //send some data

	sprintf((char*)&dataseq1[0], "                 ");
	//writetoLCD( 16, 1, dataseq1); //send some data
}

/*
 * @fn configure_continuous_txspectrum_mode
 * @brief   test application for production to check the TX power in various modes
**/
void configure_continuous_txspectrum_mode(uint8 s1switch)
{
    uint8 command = 0x2 ;  //return cursor home
    //writetoLCD( 1, 0,  &command);
	sprintf((char*)&dataseq[0], "Conti TX %s:%d:%d ", (s1switch & SWS1_SHF_MODE) ? "S" : "L", chan, prf);
	//writetoLCD( 40, 1, dataseq); //send some data
	memcpy(dataseq, (const uint8 *) "Spectrum Test   ", 16);
	//writetoLCD( 16, 1, dataseq); //send some data

	//configure DW1000 into Continuous TX mode
	instance_starttxtest(0x1000);
	//measure the power
	//Spectrum Analyser set:
	//FREQ to be channel default e.g. 3.9936 GHz for channel 2
	//SPAN to 1GHz
	//SWEEP TIME 1s
	//RBW and VBW 1MHz
	//measure channel power

	//user has to reset the board to exit mode
	while(1)
	{
		Sleep(2);
	}

}
volatile unsigned int Timer2_Counter=0;
volatile unsigned int Timer3_Counter=0;
volatile unsigned int Timer4_Counter=0;
/*
 * @fn      baro_write()
 * @brief   barometer - SPI communication write
**/


/*
 * @fn      acceler_write()
 * @brief   accelerometer - I2C communication write
**/

int32_t acceler_write(void *handle, uint8_t Reg, uint8_t *Bufp,
                              uint16_t len)
{
	wirtetoaccel(Bufp,len,Reg);

  return 0;
}

/*
 * @fn      acceler_read()
 * @brief   accelerometer - I2C communication read
**/

int32_t acceler_read(void *handle, uint8_t Reg, uint8_t *Bufp,
                             uint16_t len)
{
	readtoaccel(Bufp, len,Reg);

    return 0;
}

int getPot(void)
{
    //return HAL_ADC_GetValue(&hadc1);
}

double battery_check(double battery){
	double temp;

	float max_charge=(battery_power-0.05), min_charge=3.25;

	if(battery>max_charge){
		temp=100;
	}else if(battery<min_charge){
		temp=0;
	}else{
		temp=100.0*((battery-min_charge)/(max_charge-min_charge));
	}
	if(temp<=pre_percent){
		pre_percent=temp;
	}else{
		temp=pre_percent;
	}
	return temp;
}

/*
 * @fn      main()
 * @brief   main entry point
**/
#pragma GCC optimize ("O0")
int dw_main(void)
{
    int i = 0;
	battery_power = 4.15;
	mcu_power = 3.0;
	r1_value = 910;
	r2_value = 390;
	setting_power = (r1_value/(r1_value+r2_value)) * battery_power;
    double range_result = 0;
    double avg_result = 0;
    int count = 0;
    int canSleep;

    uint8 basss[3];

    led_off(LED_ALL); //turn off all the LEDs

    peripherals_init();

    //spi_peripheral_init();

    Sleep(1000); //wait for LCD to power on

    initLCD();

    memset(dataseq, 0x0, sizeof(dataseq));
    memcpy(dataseq, (const uint8 *) "DECAWAVE        ", 16);
   // writetoLCD( 40, 1, dataseq); //send some data
    memcpy(dataseq, (const uint8 *) SOFTWARE_VER_STRING, 16); // Also set at line #26 (Should make this from single value !!!)
   // writetoLCD( 16, 1, dataseq); //send some data

    Sleep(1000);

    port_DisableEXT_IRQ(); 	//disable DW1000 IRQ until we configure the application

#ifdef USB_SUPPORT
    // enable the USB functionality
    usb_init();
    Sleep(1000);
#endif

    s1switch = port_is_boot1_on(0) << 1 // is_switch_on(TA_SW1_2) << 2
    		| port_is_switch_on(TA_SW1_3) << 2
    		| port_is_switch_on(TA_SW1_4) << 3
    		| port_is_switch_on(TA_SW1_5) << 4
		    | port_is_switch_on(TA_SW1_6) << 5
    		| port_is_switch_on(TA_SW1_7) << 6
    		| port_is_switch_on(TA_SW1_8) << 7;


        uint8 dataseq[LCD_BUFF_LEN];
        uint8 command = 0x0;

        command = 0x2 ;  //return cursor home
        //writetoLCD( 1, 0,  &command);
        memset(dataseq, ' ', LCD_BUFF_LEN);
        memcpy(dataseq, (const uint8 *) "DECAWAVE   RANGE", 16);
        //writetoLCD( 16, 1, dataseq); //send some data

        led_off(LED_ALL);

#ifdef USB_SUPPORT //this is set in the port.h file
        usb_printconfig(16, (uint8 *)SOFTWARE_VER_STRING, s1switch);
#endif

        if(inittestapplication(s1switch) == (uint32)-1)
        {
            led_on(LED_ALL); //to display error....
            dataseq[0] = 0x2 ;  //return cursor home
            //writetoLCD( 1, 0,  &dataseq[0]);
            memset(dataseq, ' ', LCD_BUFF_LEN);
            memcpy(dataseq, (const uint8 *) "ERROR   ", 12);
            //writetoLCD( 40, 1, dataseq); //send some data
            memcpy(dataseq, (const uint8 *) "  INIT FAIL ", 12);
            //writetoLCD( 40, 1, dataseq); //send some data
            return 0; //error
        }
/*
        //test EVB1000 - used in EVK1000 production
        if((s1switch & SWS1_TXSPECT_MODE) == SWS1_TXSPECT_MODE) //to test TX power
        {
        	//this function does not return!
        	configure_continuous_txspectrum_mode(s1switch);
        }
*/
        //sleep for 5 seconds displaying "Decawave"

        i=10;

        while(i--)
        {
            if (i & 1) led_off(LED_ALL);
            else    led_on(LED_ALL);

            Sleep(200);
        }
        i = 0;

        led_off(LED_ALL);

        command = 0x2 ;  //return cursor home
        //writetoLCD( 1, 0,  &command);

        memset(dataseq, ' ', LCD_BUFF_LEN);
        memset(dataseq1, ' ', LCD_BUFF_LEN);

        addressconfigure(0);
        setup_WakeupIRQ();
        HAL_PWR_EnableWakeUpPin(PWR_WAKEUP_PIN1);
        port_EnableEXT_IRQ();

//      dev_ctx.write_reg = baro_write;
//      dev_ctx.read_reg = baro_read;

        //lps22hb_pressure_raw_get(&baro_ctx, &basss);

        //check1 = 1;
        //check2 = 2;
        // main loop
    while(1)
    {
    	instance_run();
		if(check1==1||check2==2){
			lps22hb_reset_set(&dev_ctx, BARO_PROPERTY_ENABLE);
			Sleep(2);
			do {
				lps22hb_reset_get(&dev_ctx, &baro_rst);
			} while (baro_rst);
			Sleep(2);
			lps22hb_low_power_set(&dev_ctx, BARO_PROPERTY_ENABLE);

			dwt_write16bitoffsetreg(AON_ID, AON_CFG0_OFFSET, 0x0005);
			dwt_write16bitoffsetreg(AON_ID, AON_CTRL_OFFSET, 0x0004);

			HAL_PWR_EnterSTANDBYMode();

		}

		if(instancenewrange()){
			int n = 0;
			range_result = instance_get_idist();
			check_battery = ((double)getPot())*(battery_power/((setting_power/mcu_power)*4096)); //ADC 21312asd
			percent = battery_check(check_battery);
			//barometer !!~!!#
			lps22hb_pressure_raw_get(&dev_ctx, data_raw_pressure.u8bit);
			pressure_hPa = LPS22HB_FROM_LSB_TO_hPa( data_raw_pressure.i32bit);
			lps22hb_temperature_raw_get(&dev_ctx,data_raw_temperature.u8bit);
			temperature = LPS22HB_FROM_LSB_TO_degC( data_raw_temperature.i32bit);



			n = sprintf((char*)&dataseq[0], "%2.2fm\r\npressure = %2.2f, temperature = %2.2f\r\nx=%d g,y=%d g,z=%d g\r\n%2.2f, %2.2f\r\n\r\n", range_result, pressure_hPa, temperature, axis[0], axis[1], axis[2], check_battery, percent);
			send_usbmessage(&dataseq[0], n);
			usb_run();
			count+=1;
		}
    }


    return 0;
}
