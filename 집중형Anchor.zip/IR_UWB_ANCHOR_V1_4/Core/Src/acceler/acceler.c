/*
 ******************************************************************************
 * @file    acceler.c
 * @date    29-November-2018
 * @brief   MMA8453Q driver file
 ******************************************************************************/

#include "acceler.h"
#include "port.h"

extern I2C_HandleTypeDef hi2c1;

static uint8_t acceler_whoamI, acceler_rst, full_scale, check_int,check_int_cfg, bypass_hpf,check_lpf, lp_mod,noise,count_mode, check_fs;

/*
 * Function: I2C_Read()
 */
int wirtetoaccel(uint8_t *pData, uint16_t Size, uint8_t DevAddress){

	while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);

	HAL_I2C_Mem_Write(&hi2c1, MMA8453Q_I2C_ADD_L, (uint16_t)DevAddress, 1, &pData[0], Size, 1000);
	//HAL_I2C_Master_Transmit(&hi2c1, MMA8453Q_I2C_ADD_L, &pData[0], Size, 1000);

	return 0;
}

/*
 * Function: I2C_Write()
 */
int readtoaccel(uint8_t *pData, uint16_t Size, uint8_t DevAddress){

	while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);

	HAL_I2C_Mem_Read(&hi2c1, MMA8453Q_I2C_ADD_L, (uint16_t)DevAddress, 1, &pData[0], Size, 1000);
	//HAL_I2C_Master_Transmit(&hi2c1, MMA8453Q_I2C_ADD_L, &DevAddress, Size, 1000);
	//HAL_I2C_Master_Receive(&hi2c1, MMA8453Q_I2C_ADD_L, &pData[0], Size, 1000);

	return 0;
}

/*
 * 	@brief  barometer device register init
 *
 * 	@param  mma8453q_ctx_t *acceler_ctx: read / write interface definitions
*/

int32_t mma8453q_init(mma8453q_ctx_t *acceler_ctx){

	mma8453q_device_id_get(acceler_ctx,&acceler_whoamI); //ID Check
	while(acceler_whoamI!=MMA8453Q_ID){

	    mma8453q_device_id_get(acceler_ctx,&acceler_whoamI);
	}

	mma8453q_software_reset_set(acceler_ctx, ACCEL_PROPERTY_ENABLE); //reset ���� ����
	Sleep(2);

	motion_detection_flag_set(acceler_ctx, ACCEL_PROPERTY_ENABLE, 40); //motion detection�� flag �� ���� ����

	mma8453q_FF_MT_int_set(acceler_ctx,ACCEL_PROPERTY_ENABLE); //motion interrupt �㰡
	Sleep(2);

	mma8453q_FF_MT_int_configuration_set(acceler_ctx, ACCEL_PROPERTY_ENABLE); //motion interrupt pin int1�� ����
	while(check_int!=ACCEL_PROPERTY_ENABLE){

		mma8453q_FF_MT_int_configuration_get(acceler_ctx,&check_int);
	}
	Sleep(2);

	/*mma8453q_xyz_data_full_scale_set(acceler_ctx, MMA8453Q_FULL_SCALE_RANGE_2);
	Sleep(2);;*/

	mma8453q_low_pass_filter_enable_set(acceler_ctx,ACCEL_PROPERTY_ENABLE); //LPF ��� �㰡
	Sleep(2);

	mma8453q_active_mode_power_sel_set(acceler_ctx,MMA8453Q_LOW_POWER); //���� ��� LOW_POWER ����
	Sleep(2);

	mma8453q_full_scale_sel_set(acceler_ctx,ACCEL_PROPERTY_ENABLE); //Accelerometer Active ����
	Sleep(2);

	return 0;
}

/*
 * 	@brief  barometer axis get
 *
 * 	@param  mma8453q_ctx_t *acceler_ctx: read / write interface definitions
 * 	@param  uint32_t *buff: buffer that x, y, z axis data read
*/

int32_t mma8453q_axis_get(mma8453q_ctx_t *ctx, uint32_t *buff)
{
  int32_t x_axis=0, y_axis=0, z_axis=0, temp=0;
  mma8453q_x_msb_get(ctx,&temp); 	//x axis 8bit msb ������
  x_axis=temp<<8;					//8bit ���� shift
  mma8453q_x_lsb_get(ctx,&temp); 	//x axis 8bit lsb ������
  x_axis|=temp;

  mma8453q_y_msb_get(ctx,&temp);	//y axis 8bit msb ������
  y_axis=temp<<8;					//8bit ���� shift
  mma8453q_y_lsb_get(ctx,&temp);	//y axis 8bit lsb ������
  y_axis|=temp;

  mma8453q_z_msb_get(ctx,&temp);	//z axis 8bit msb ������
  z_axis=temp<<8;					//8bit ���� shift
  mma8453q_z_lsb_get(ctx,&temp);	//z axis 8bit lsb ������
  z_axis|=temp;

  x_axis=x_axis>>6;					//x axis 6bit ���� shift
  y_axis=y_axis>>6;					//y axis 6bit ���� shift
  z_axis=z_axis>>6;					//z axis 6bit ���� shift

  buff[0]=x_axis;
  buff[1]=y_axis;
  buff[2]=z_axis;

  return 0;
}

/*
 * 	@brief  motion detection flag set & register set
 *
 * 	@param  mma8453q_ctx_t *acceler_ctx: read / write interface definitions
 * 			uint32_t val: change the values of flag & register
 * 			uint32_t threshold_set : change values of motion threshold
*/

int32_t motion_detection_flag_set(mma8453q_ctx_t *ctx, uint32_t val, uint32_t threshold_set)
{
	int32_t ele_check=0, oae_check=0, xflag_check=0, yflag_check=0, zflag_check=0, threshold=0;
	int32_t check=0, test=0;

	mma8453q_freefall_motion_threshold_set(ctx,threshold_set); 	//motion detect �Ӱ谪 ����
	Sleep(2);

	mma8453q_FF_MT_Debounce_counter_mode_sel_set(ctx,val); 		//counter �ʱ�ȭ ��� ����
	Sleep(2);

	mma8453q_motion_freefall_detect_flag_sel_set(ctx,val); 		// freefall or motion flag ����
	Sleep(2);

	mma8453q_X_event_flag_enable_set(ctx,val); 					// x axis event flag ����
	Sleep(2);

	mma8453q_Y_event_flag_enable_set(ctx,val);					// y axis event flag ����
	Sleep(2);

	mma8453q_Z_event_flag_enable_set(ctx,val);					// z axis event flag ����
	Sleep(2);

	return 0;
}

/**
  * @brief  Read generic device register
  *
  * @param  mma8453q_ctx_t* ctx: read / write interface definitions
  * @param  uint8_t reg: register to read
  * @param  uint8_t* data: pointer to buffer that store the data read
  * @param  uint16_t len: number of consecutive register to read
  *
  */

int32_t mma8453q_read_reg(mma8453q_ctx_t* ctx, uint8_t reg, uint8_t* data,
                         uint16_t len)
{
  return ctx->read_reg(ctx->handle, reg, data, len);
}

/**
  * @brief  Write generic device register
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t reg: register to write
  * @param  uint8_t* data: pointer to data to write in register reg
  * @param  uint16_t len: number of consecutive register to write
  *
*/

int32_t mma8453q_write_reg(mma8453q_ctx_t* ctx, uint8_t reg, uint8_t* data,
                          uint16_t len)
{
  return ctx->write_reg(ctx->handle, reg, data, len);
}

/**
  * @}
  */

/**
  * @addtogroup  common
  * @brief   This section group common usefull functions
  * @{
  */

/**
  * @brief  device_id: [get]  WHO AM I
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *buff: buffer that stores data read
  *
  */
int32_t mma8453q_device_id_get(mma8453q_ctx_t *ctx, uint8_t *buff)
{
  return mma8453q_read_reg(ctx, (uint8_t)MMA8453Q_WHO_AM_I, (uint8_t*) buff, 1);
}

/**
  * @brief  x_msb: [get]  x axis MSB(0~7bit).
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *buff: buffer that stores data read
  *
  */
int32_t mma8453q_x_msb_get(mma8453q_ctx_t *ctx, uint8_t *buff)
{
  return mma8453q_read_reg(ctx, MMA8453Q_OUT_X_MSB, (uint8_t*) buff, 1);
}

/**
  * @brief  x_lsb: [get]  x axis LSB (6~7bit).
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *buff: buffer that stores data read
  *
  */
int32_t mma8453q_x_lsb_get(mma8453q_ctx_t *ctx, uint8_t *buff)
{
  return mma8453q_read_reg(ctx, MMA8453Q_OUT_X_LSB, (uint8_t*) buff, 1);
}

/**
  * @brief  y_msb: [get]  y axis MSB(0~7bit).
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *buff: buffer that stores data read
  *
  */
int32_t mma8453q_y_msb_get(mma8453q_ctx_t *ctx, uint8_t *buff)
{
  return mma8453q_read_reg(ctx, MMA8453Q_OUT_Y_MSB, (uint8_t*) buff, 1);
}

/**
  * @brief  y_lsb: [get]  y axis LSB(6~7bit).
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *buff: buffer that stores data read
  *
  */
int32_t mma8453q_y_lsb_get(mma8453q_ctx_t *ctx, uint8_t *buff)
{
  return mma8453q_read_reg(ctx, MMA8453Q_OUT_Y_LSB, (uint8_t*) buff, 1);
}

/**
  * @brief  z_msb: [get]  z axis MSB(0~7bit).
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *buff: buffer that stores data read
  *
  */
int32_t mma8453q_z_msb_get(mma8453q_ctx_t *ctx, uint8_t *buff)
{
  return mma8453q_read_reg(ctx, MMA8453Q_OUT_Z_MSB, (uint8_t*) buff, 1);
}

/**
  * @brief  z_lsb: [get]  z axis LSB(6~7bit).
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *buff: buffer that stores data read
  *
  */
int32_t mma8453q_z_lsb_get(mma8453q_ctx_t *ctx, uint8_t *buff)
{
  return mma8453q_read_reg(ctx, MMA8453Q_OUT_Z_LSB, (uint8_t*) buff, 1);
}

/**
  * @brief  software_reset: [set]  Software reset. Restore the default values
  *                       in user registers.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t val: change the values of swreset in reg CTRL_REG2
  *
  */
int32_t mma8453q_software_reset_set(mma8453q_ctx_t *ctx, uint8_t val)
{
  mma8453q_reg_t reg;
  int32_t mm_error;

  mm_error = mma8453q_read_reg(ctx, MMA8453Q_CTRL_REG2, &(reg.byte), 1);
  reg.ctrl_reg2.rst = val;
  mm_error = mma8453q_write_reg(ctx, MMA8453Q_CTRL_REG2, &(reg.byte), 1);

  return mm_error;
}

/**
  * @brief  software_reset: [get]  Software reset. Restore the default values
  *                       in user registers.
  *
  * @param  lps22hb_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t: change the values of swreset in reg CTRL_REG2
  *
  */
int32_t mma8453q_software_reset_get(mma8453q_ctx_t *ctx, uint8_t *val)
{
  mma8453q_reg_t reg;
  int32_t mm_error;

  mm_error = mma8453q_read_reg(ctx, MMA8453Q_CTRL_REG2, &(reg.byte), 1);
  *val = reg.ctrl_reg2.rst;

  return mm_error;
}

/**
  * @brief  data_rate: [set]  Output data rate selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  mma8453q_data_rate_t: change the values of dr in reg CTRL_REG1
  *
  */
int32_t mma8453q_data_rate_set(mma8453q_ctx_t *ctx, mma8453q_data_rate_t val)
{
  mma8453q_reg_t reg;
  int32_t mm_error;

  mm_error = mma8453q_read_reg(ctx, MMA8453Q_CTRL_REG1, &(reg.byte), 1);
  reg.ctrl_reg1.dr = val;
  mm_error = mma8453q_write_reg(ctx, MMA8453Q_CTRL_REG1, &(reg.byte), 1);

  return mm_error;
}

/**
  * @brief  full_scale_sel: [set]  Full-scale selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t val: change the values of active in reg CTRL_REG1
  *
  */
int32_t mma8453q_full_scale_sel_set(mma8453q_ctx_t *ctx, uint8_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_CTRL_REG1, &(reg.byte), 1);
	reg.ctrl_reg1.active = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_CTRL_REG1, &(reg.byte), 1);

	return mm_error;
}

/**
  * @brief  full_scale_sel: [get]  Full-scale selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t* val: change the values of active in reg CTRL_REG1
  *
  */
int32_t mma8453q_full_scale_sel_get(mma8453q_ctx_t *ctx, uint8_t* val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_CTRL_REG1, &(reg.byte), 1);
	*val = reg.ctrl_reg1.active;

	return mm_error;
}

/**
  * @brief  event_latch_enable: [set]  event latch selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t val: change the values of ele in reg FF_MT_CFG
  *
  */
int32_t mma8453q_event_latch_enable_set(mma8453q_ctx_t *ctx, uint8_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_CFG, &(reg.byte), 1);
	reg.ff_mt_cfg.ele = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_FF_MT_CFG, &(reg.byte), 1);

	return mm_error;
}

/**
  * @brief  event_latch_enable: [get]  event latch selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of ele in reg FF_MT_CFG
  *
  */
int32_t mma8453q_event_latch_enable_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_CFG, &(reg.byte), 1);
	*val = reg.ff_mt_cfg.ele;

	return mm_error;

}

/**
  * @brief  motion_freefall_detect_flag_sel: [set]  motion detect flag selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t val: change the values of oae in reg FF_MT_CFG
  *
  */
int32_t mma8453q_motion_freefall_detect_flag_sel_set(mma8453q_ctx_t *ctx, uint8_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_CFG, &(reg.byte), 1);
	reg.ff_mt_cfg.oae = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_FF_MT_CFG, &(reg.byte), 1);

	return mm_error;
}

/**
  * @brief  motion_freefall_detect_flag_sel: [get]  motion detect flag selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of oae in reg FF_MT_CFG
  *
  */
int32_t mma8453q_motion_freefall_detect_flag_sel_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_CFG, &(reg.byte), 1);
	*val = reg.ff_mt_cfg.oae;

	return mm_error;
}

/**
  * @brief  X_event_flag_enable: [set]  x axis event flag selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t val: change the values of xefe in reg FF_MT_CFG
  *
  */
int32_t mma8453q_X_event_flag_enable_set(mma8453q_ctx_t *ctx, uint8_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_CFG, &(reg.byte), 1);
	reg.ff_mt_cfg.xefe = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_FF_MT_CFG, &(reg.byte), 1);

	return mm_error;
}

/**
  * @brief  X_event_flag_enable: [get]  x axis event flag selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of xefe in reg FF_MT_CFG
  *
  */
int32_t mma8453q_X_event_flag_enable_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_CFG, &(reg.byte), 1);
	*val = reg.ff_mt_cfg.xefe;

	return mm_error;
}

/**
  * @brief  Y_event_flag_enable: [set]  y axis event flag selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t val: change the values of yefe in reg FF_MT_CFG
  *
  */
int32_t mma8453q_Y_event_flag_enable_set(mma8453q_ctx_t *ctx, uint8_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_CFG, &(reg.byte), 1);
	reg.ff_mt_cfg.yefe = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_FF_MT_CFG, &(reg.byte), 1);

	return mm_error;
}

/**
  * @brief  Y_event_flag_enable: [get]  y axis event flag selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of yefe in reg FF_MT_CFG
  *
  */
int32_t mma8453q_Y_event_flag_enable_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_CFG, &(reg.byte), 1);
	*val = reg.ff_mt_cfg.yefe;

	return mm_error;
}

/**
  * @brief  Z_event_flag_enable: [set]  z axis event flag selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t val: change the values of zefe in reg FF_MT_CFG
  *
  */
int32_t mma8453q_Z_event_flag_enable_set(mma8453q_ctx_t *ctx, uint8_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_CFG, &(reg.byte), 1);
	reg.ff_mt_cfg.zefe = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_FF_MT_CFG, &(reg.byte), 1);

	return mm_error;
}

/**
  * @brief  Z_event_flag_enable: [get]  z axis event flag selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of zefe in reg FF_MT_CFG
  *
  */
int32_t mma8453q_Z_event_flag_enable_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_CFG, &(reg.byte), 1);
	*val = reg.ff_mt_cfg.zefe;

	return mm_error;
}

/**
  * @brief  freefall_motion_threshold: [set]  motion threshold selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t val: change the values of ths in reg FF_MT_THS
  *
  */
int32_t mma8453q_freefall_motion_threshold_set(mma8453q_ctx_t *ctx, uint8_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_THS, &(reg.byte), 1);
	reg.ff_mt_ths.ths = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_FF_MT_THS, &(reg.byte), 1);

	return mm_error;
}

/**
  * @brief  freefall_motion_threshold: [set]  motion threshold selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of ths in reg FF_MT_THS
  *
  */
int32_t mma8453q_freefall_motion_threshold_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_THS, &(reg.byte), 1);
	*val = reg.ff_mt_ths.ths;

	return mm_error;
}

/**
  * @brief  X_motion_flag: [get]  X motion flag event detect.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of xhe in reg FF_MT_SRC
  *
  */
int32_t mma8453q_X_motion_flag_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_SRC, &(reg.byte), 1);
	*val = reg.ff_mt_src.xhe;

	return mm_error;
}

/**
  * @brief  Y_motion_flag: [get]  Y motion flag event detect.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of yhe in reg FF_MT_SRC
  *
  */
int32_t mma8453q_Y_motion_flag_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_SRC, &(reg.byte), 1);
	*val = reg.ff_mt_src.yhe;

	return mm_error;
}

/**
  * @brief  Z_motion_flag: [get]  Z motion flag event detect.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of zhe in reg FF_MT_SRC
  *
  */
int32_t mma8453q_Z_motion_flag_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_SRC, &(reg.byte), 1);
	*val = reg.ff_mt_src.zhe;

	return mm_error;
}

/**
  * @brief  event_active_flag: [get]  event active flag - one or more detect.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of ea in reg FF_MT_SRC
  *
  */
int32_t mma8453q_event_active_flag_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_SRC, &(reg.byte), 1);
	*val = reg.ff_mt_src.ea;

	return mm_error;
}

/**
  * @brief  FF_MT_int: [set]  Freefall motion interrupt enable selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t val: change the values of int_en_ff_mt in reg CTRL_REG4
  *
  */
int32_t mma8453q_FF_MT_int_set(mma8453q_ctx_t *ctx, uint8_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_CTRL_REG4, &(reg.byte), 1);
	reg.ctrl_reg4.int_en_ff_mt = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_CTRL_REG4, &(reg.byte), 1);
	return mm_error;
}

/**
  * @brief  FF_MT_int: [set]  Freefall motion interrupt enable selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of int_en_ff_mt in reg CTRL_REG4
  *
  */
int32_t mma8453q_FF_MT_int_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_CTRL_REG4, &(reg.byte), 1);
	*val = reg.ctrl_reg4.int_en_ff_mt;

	return mm_error;
}

/**
  * @brief  FF_MT_int_configuration: [set]  Freefall motion interrupt Pin selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t val: change the values of int_cfg_ff_mt in reg CTRL_REG5
  *
  */
int32_t mma8453q_FF_MT_int_configuration_set(mma8453q_ctx_t *ctx, uint8_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_CTRL_REG5, &(reg.byte), 1);
	reg.ctrl_reg5.int_cfg_ff_mt = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_CTRL_REG5, &(reg.byte), 1);
	return mm_error;
}

/**
  * @brief  FF_MT_int_configuration: [get]  Freefall motion interrupt Pin selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of int_cfg_ff_mt in reg CTRL_REG5
  *
  */
int32_t mma8453q_FF_MT_int_configuration_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_CTRL_REG5, &(reg.byte), 1);
	*val = reg.ctrl_reg5.int_cfg_ff_mt;
	return mm_error;
}

/**
  * @brief  high_pass_filter_bypass: [set]  high-pass filter bypass selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t val: change the values of pulse_hf_byp in reg HP_FILTER_CUTOFF
  *
  */
int32_t mma8453q_high_pass_filter_bypass_set(mma8453q_ctx_t *ctx, uint8_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_HP_FILTER_CUTOFF, &(reg.byte), 1);
	reg.hp_filter_cutoff.pulse_hpf_byp = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_HP_FILTER_CUTOFF, &(reg.byte), 1);
	return mm_error;
}

/**
  * @brief  high_pass_filter_bypass: [get]  high-pass filter bypass selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of pulse_hf_byp in reg HP_FILTER_CUTOFF
  *
  */
int32_t mma8453q_high_pass_filter_bypass_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_HP_FILTER_CUTOFF, &(reg.byte), 1);
	*val = reg.hp_filter_cutoff.pulse_hpf_byp;
	return mm_error;
}

/**
  * @brief  high_pass_filter_sel: [set]  HPF cutoff frequency selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  mma8453q_hpf_co_freq_sel_t val: change the values of sel in reg HP_FILTER_CUTOFF
  *
  */
int32_t mma8453q_high_pass_filter_sel_set(mma8453q_ctx_t *ctx, mma8453q_hpf_co_freq_sel_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_HP_FILTER_CUTOFF, &(reg.byte), 1);
	reg.hp_filter_cutoff.sel = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_HP_FILTER_CUTOFF, &(reg.byte), 1);
	return mm_error;
}

/**
  * @brief  high_pass_filter_sel: [get]  HPF cutoff frequency selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  mma8453q_hpf_co_freq_sel_t *val: change the values of sel in reg HP_FILTER_CUTOFF
  *
  */
int32_t mma8453q_high_pass_filter_sel_get(mma8453q_ctx_t *ctx, mma8453q_hpf_co_freq_sel_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_HP_FILTER_CUTOFF, &(reg.byte), 1);
	*val = reg.hp_filter_cutoff.sel;
	return mm_error;
}

/**
  * @brief  low_pass_filter_enable: [set]  LPF enable selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t val: change the values of pulse_lps_en in reg HP_FILTER_CUTOFF
  *
  */
int32_t mma8453q_low_pass_filter_enable_set(mma8453q_ctx_t *ctx, uint8_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_HP_FILTER_CUTOFF, &(reg.byte), 1);
	reg.hp_filter_cutoff.pulse_lps_en = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_HP_FILTER_CUTOFF, &(reg.byte), 1);
	return mm_error;
}

/**
  * @brief  low_pass_filter_enable: [get]  LPF enable selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of pulse_lps_en in reg HP_FILTER_CUTOFF
  *
  */
int32_t mma8453q_low_pass_filter_enable_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_HP_FILTER_CUTOFF, &(reg.byte), 1);
	*val = reg.hp_filter_cutoff.pulse_lps_en;
	return mm_error;
}

/**
  * @brief  active_mode_power_sel: [set]  Active mode power scheme selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  mma8453q_mods_t val: change the values of mods in reg CTRL_REG2
  *
  */
int32_t mma8453q_active_mode_power_sel_set(mma8453q_ctx_t *ctx, mma8453q_mods_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_CTRL_REG2, &(reg.byte), 1);
	reg.ctrl_reg2.mods = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_CTRL_REG2, &(reg.byte), 1);
	return mm_error;
}

/**
  * @brief  active_mode_power_sel: [get]  Active mode power scheme selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  mma8453q_mods_t *val: change the values of mods in reg CTRL_REG2
  *
  */
int32_t mma8453q_active_mode_power_sel_get(mma8453q_ctx_t *ctx, mma8453q_mods_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_CTRL_REG2, &(reg.byte), 1);
	*val = reg.ctrl_reg2.mods;
	return mm_error;
}

/**
  * @brief  reduced_noise_reduced_max_range_mod: [set]  noise reduced mode selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t val: change the values of lnoise in reg CTRL_REG1
  *
  */
int32_t mma8453q_reduced_noise_reduced_max_range_mode_set(mma8453q_ctx_t *ctx, uint8_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_CTRL_REG1, &(reg.byte), 1);
	reg.ctrl_reg1.lnoise = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_CTRL_REG1, &(reg.byte), 1);
	return mm_error;
}

/**
  * @brief  reduced_noise_reduced_max_range_mod: [get]  noise reduced mode selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of lnoise in reg CTRL_REG1
  *
  */
int32_t mma8453q_reduced_noise_reduced_max_range_mode_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_CTRL_REG1, &(reg.byte), 1);
	*val = reg.ctrl_reg1.lnoise;

	return mm_error;
}

/**
  * @brief  FF_MT_Debounce_counter_mode_sel: [set]  Freefall motion debounce counter mode selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t val: change the values of dbcntm in reg FF_MT_THS
  *
  */
int32_t mma8453q_FF_MT_Debounce_counter_mode_sel_set(mma8453q_ctx_t *ctx, uint8_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_THS, &(reg.byte), 1);
	reg.ff_mt_ths.dbcntm = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_FF_MT_THS, &(reg.byte), 1);
	return mm_error;
}

/**
  * @brief  FF_MT_Debounce_counter_mode_sel: [get]  Freefall motion debounce counter mode selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  uint8_t *val: change the values of dbcntm in reg FF_MT_THS
  *
  */
int32_t mma8453q_FF_MT_Debounce_counter_mode_sel_get(mma8453q_ctx_t *ctx, uint8_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_FF_MT_THS, &(reg.byte), 1);
	*val = reg.ff_mt_ths.dbcntm;

	return mm_error;
}

/**
  * @brief  xyz_data_full_scale: [set]  full scale range selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  mma8453q_fs_range_t val: change the values of fs in reg xyz_data_cfg
  *
  */
int32_t mma8453q_xyz_data_full_scale_set(mma8453q_ctx_t *ctx, mma8453q_fs_range_t val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_XYZ_DATA_CFG, &(reg.byte), 1);
	reg.xyz_data_cfg.fs = val;
	mm_error = mma8453q_write_reg(ctx, MMA8453Q_XYZ_DATA_CFG, &(reg.byte), 1);
	return mm_error;
}

/**
  * @brief  xyz_data_full_scale: [get]  full scale range selection.
  *
  * @param  mma8453q_ctx_t *ctx: read / write interface definitions
  * @param  mma8453q_fs_range_t *val: change the values of fs in reg xyz_data_cfg
  *
  */
int32_t mma8453q_xyz_data_full_scale_get(mma8453q_ctx_t *ctx, mma8453q_fs_range_t *val){
	mma8453q_reg_t reg;
	int32_t mm_error;

	mm_error = mma8453q_read_reg(ctx, MMA8453Q_XYZ_DATA_CFG, &(reg.byte), 1);
	*val = reg.xyz_data_cfg.fs;

	return mm_error;
}
